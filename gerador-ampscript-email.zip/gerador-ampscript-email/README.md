# Gerador AMPscript para e-mail HTML

Abra `index.html` direto no navegador (Chrome/Edge). Não precisa de servidor nem instalação.
Para testar, use `exemplos/email-teste.html`, que reúne casos de borda.

## Estrutura

```
index.html
css/style.css
js/core/                 lógica (não mexe na tela)
  htmlUtils.js           escape, fim de linha, validação estrutural (só avisa)
  fileReader.js          upload e caminho/URL; detecta UTF-8 ou Windows-1252
  variableDetector.js    encontra %%Nome%% ignorando %%[ ]%% e %%= =%% existentes
  imageDetector.js       encontra <img src>, separa prefixo_ID.ext e a posição exata do prefixo
  transforms.js          registro de tratamentos (Nenhum, ProperCase...)
  ampscriptBuilder.js    gera %%=...=%% e o bloco SET @Var = AttributeValue("Campo")
  replacementEngine.js   aplica substituições por posição, sem reserializar o HTML
  processor.js           orquestra: regras, pendências e avisos
js/ui/                   interface
  inputPanel.js  summaryPanel.js  variablesPanel.js  imagesPanel.js  codePanel.js  clipboard.js
js/app.js                estado e ligação entre módulos
```

## Como a integridade é garantida

O HTML nunca vira DOM. Cada substituição é um intervalo (início, fim, novo texto) no texto
original; o resultado é montado copiando literalmente o que está entre os intervalos.
Intervalos sobrepostos são rejeitados e aparecem como aviso.

## Adicionar um tratamento

Em `js/core/transforms.js`, inclua na lista:

```js
{ id: 'uppercase', label: 'Uppercase', build: function (ref) { return 'Uppercase(' + ref + ')'; } }
```

Ele aparece automaticamente no seletor de cada variável.
