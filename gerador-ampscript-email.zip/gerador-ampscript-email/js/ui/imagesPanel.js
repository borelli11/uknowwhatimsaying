/**
 * imagesPanel.js
 * Campo de novo prefixo e listagem das imagens (atual → novo).
 */
(function (ns) {
  'use strict';

  const rows = new Map(); // index -> { tr, check, next, status }
  let handlers = null;

  function init(h) {
    handlers = h;
    const prefix = document.getElementById('prefixInput');
    prefix.addEventListener('input', function () { handlers.onPrefix(prefix.value); });

    const all = document.getElementById('imagesToggleAll');
    all.addEventListener('change', function () { handlers.onToggleAll(all.checked); });
  }

  function statusText(img) {
    if (img.status === 'ok') return '';
    return img.reasons.join('; ');
  }

  function render(state) {
    const body = document.getElementById('imagesBody');
    body.textContent = '';
    rows.clear();
    document.getElementById('prefixInput').value = state.imagePrefix;

    const items = state.analysis.images.items;
    if (!items.length) {
      const tr = document.createElement('tr');
      tr.className = 'empty-row';
      const c = document.createElement('td');
      c.colSpan = 4;
      c.textContent = 'Nenhuma tag <img> encontrada neste HTML.';
      tr.appendChild(c);
      body.appendChild(tr);
      return;
    }

    items.forEach(function (img) {
      const tr = document.createElement('tr');
      tr.className = 'st-' + img.status;

      const c0 = document.createElement('td');
      const check = document.createElement('input');
      check.type = 'checkbox';
      check.checked = !!state.imageInclude[img.index];
      check.disabled = img.status === 'unrecognized';
      check.setAttribute('aria-label', 'Alterar imagem ' + (img.index + 1));
      check.addEventListener('change', function () { handlers.onInclude(img.index, check.checked); });
      c0.appendChild(check);

      const c1 = document.createElement('td');
      const file = document.createElement('div');
      file.className = 'img-file';
      file.textContent = (img.index + 1) + '. ' + (img.fileName || '(sem nome de arquivo)');
      const url = document.createElement('div');
      url.className = 'img-url';
      url.textContent = img.src === null ? 'sem src' : img.src;
      c1.appendChild(file);
      c1.appendChild(url);
      if (img.inComment) {
        const b = document.createElement('span');
        b.className = 'badge badge-info';
        b.textContent = 'dentro de comentário HTML';
        c1.appendChild(b);
      }

      const c2 = document.createElement('td');
      c2.className = 'img-file';
      c2.textContent = img.id || '—';

      const c3 = document.createElement('td');
      const next = document.createElement('div');
      next.className = 'img-file img-new';
      const status = document.createElement('div');
      status.className = 'row-msg';
      c3.appendChild(next);
      c3.appendChild(status);

      tr.appendChild(c0);
      tr.appendChild(c1);
      tr.appendChild(c2);
      tr.appendChild(c3);
      body.appendChild(tr);
      rows.set(img.index, { tr: tr, check: check, next: next, status: status });
    });
  }

  function update(result) {
    const prefixInput = document.getElementById('prefixInput');
    const hint = document.getElementById('prefixHint');
    prefixInput.classList.toggle('invalid', result.prefixState === 'invalid');
    if (result.prefixState === 'invalid') {
      hint.textContent = 'Use apenas letras sem acento, números e hífen.';
      hint.classList.add('error');
    } else if (result.prefixState === 'empty') {
      hint.textContent = 'Informe o prefixo ou desmarque as imagens que não devem mudar.';
      hint.classList.add('error');
    } else {
      hint.textContent = 'Substitui o texto antes do primeiro "_" no nome do arquivo.';
      hint.classList.remove('error');
    }

    result.images.forEach(function (img) {
      const r = rows.get(img.index);
      if (!r) return;
      r.check.checked = img.include;
      r.next.classList.remove('changed');
      if (img.status === 'unrecognized') {
        r.next.textContent = 'Não alterada';
      } else if (!img.include) {
        r.next.textContent = 'Não alterada (desmarcada)';
      } else if (img.newFileName) {
        r.next.textContent = img.willChange ? img.fileName + ' → ' + img.newFileName : img.fileName + ' (prefixo já é o mesmo)';
        r.next.classList.toggle('changed', img.willChange);
      } else {
        r.next.textContent = img.fileName + ' → aguardando prefixo';
      }
      r.status.textContent = statusText(img);
    });

    const selectable = result.images.filter(function (i) { return i.selectable; });
    const all = document.getElementById('imagesToggleAll');
    const checked = selectable.filter(function (i) { return i.include; }).length;
    all.disabled = selectable.length === 0;
    all.checked = selectable.length > 0 && checked === selectable.length;
    all.indeterminate = checked > 0 && checked < selectable.length;
  }

  ns.ImagesPanel = { init, render, update };
})(window.EmailAmp = window.EmailAmp || {});
