/**
 * variablesPanel.js
 * Tabela: Variável encontrada | Campo da DE | Tratamento | Resultado.
 * As linhas são criadas uma vez por arquivo; a cada alteração só os resultados são atualizados,
 * para não perder o foco do campo que o usuário está digitando.
 */
(function (ns) {
  'use strict';

  const KEEP = ns.Processor.KEEP;
  const rows = new Map(); // nome -> { tr, input, select, expr, inline, msg }

  function td(label) {
    const c = document.createElement('td');
    if (label) c.dataset.label = label;
    return c;
  }

  function badge(text, cls) {
    const b = document.createElement('span');
    b.className = 'badge' + (cls ? ' ' + cls : '');
    b.textContent = text;
    return b;
  }

  function render(state, onChange) {
    const body = document.getElementById('varsBody');
    body.textContent = '';
    rows.clear();

    const groups = state.analysis.vars.groups;
    if (!groups.length) {
      const tr = document.createElement('tr');
      tr.className = 'empty-row';
      const c = td();
      c.colSpan = 4;
      c.textContent = 'Nenhuma variável no formato %%Nome%% foi encontrada neste HTML.';
      tr.appendChild(c);
      body.appendChild(tr);
      return;
    }

    groups.forEach(function (g) {
      const cfg = state.varConfig[g.name];
      const tr = document.createElement('tr');

      // Variável encontrada
      const c1 = td('Variável encontrada');
      const name = document.createElement('div');
      name.className = 'var-name';
      name.textContent = '%%' + g.name + '%%';
      c1.appendChild(name);
      const badges = document.createElement('div');
      badges.className = 'badges';
      if (g.occurrences.length > 1) badges.appendChild(badge(g.occurrences.length + ' ocorrências', 'badge-info'));
      if (ns.Processor.isSystem(g.name)) badges.appendChild(badge('string do Marketing Cloud'));
      if (badges.childNodes.length) c1.appendChild(badges);

      // Campo da DE
      const c2 = td('Campo da DE');
      const input = document.createElement('input');
      input.type = 'text';
      input.value = cfg.field;
      input.placeholder = g.name;
      input.spellcheck = false;
      input.autocomplete = 'off';
      input.setAttribute('aria-label', 'Campo da DE para %%' + g.name + '%%');
      input.disabled = cfg.treatment === KEEP;
      input.addEventListener('input', function () { onChange(g.name, { field: input.value }); });
      c2.appendChild(input);

      // Tratamento
      const c3 = td('Tratamento');
      const select = document.createElement('select');
      select.setAttribute('aria-label', 'Tratamento para %%' + g.name + '%%');
      ns.Transforms.list.forEach(function (t) {
        const o = document.createElement('option');
        o.value = t.id;
        o.textContent = t.label;
        select.appendChild(o);
      });
      const keep = document.createElement('option');
      keep.value = KEEP;
      keep.textContent = 'Manter %%' + g.name + '%% sem alterar';
      select.appendChild(keep);
      select.value = cfg.treatment;
      select.addEventListener('change', function () {
        input.disabled = select.value === KEEP;
        onChange(g.name, { treatment: select.value });
        if (!input.disabled && !input.value) input.focus();
      });
      c3.appendChild(select);

      // Resultado
      const c4 = td('Resultado');
      const expr = document.createElement('div');
      expr.className = 'result-expr';
      const inline = document.createElement('div');
      inline.className = 'result-inline';
      const msg = document.createElement('div');
      msg.className = 'row-msg';
      c4.appendChild(expr);
      c4.appendChild(inline);
      c4.appendChild(msg);

      tr.appendChild(c1);
      tr.appendChild(c2);
      tr.appendChild(c3);
      tr.appendChild(c4);
      body.appendChild(tr);
      rows.set(g.name, { tr: tr, expr: expr, inline: inline, msg: msg });
    });
  }

  function update(result) {
    result.vars.forEach(function (v) {
      const r = rows.get(v.name);
      if (!r) return;
      r.tr.className = 'st-' + v.status;
      if (v.status === 'ok') {
        r.expr.textContent = '%%' + v.name + '%% → ' + v.expression;
        r.inline.textContent = 'insere: ' + v.inline;
      } else if (v.status === 'keep') {
        r.expr.textContent = '%%' + v.name + '%%';
        r.inline.textContent = '';
      } else {
        r.expr.textContent = 'Sem substituição';
        r.inline.textContent = '';
      }
      r.msg.textContent = v.message;
    });

    const blockMsg = document.getElementById('blockMessage');
    const preview = document.getElementById('blockPreview');
    blockMsg.textContent = result.block.text ? result.block.message : 'O bloco aparece aqui quando houver variáveis configuradas.';
    blockMsg.classList.toggle('error', result.block.text !== '' && result.block.mode !== 'none' && !result.block.inserted);
    preview.hidden = !result.block.text;
    preview.textContent = result.block.text;
  }

  ns.VariablesPanel = { render, update };
})(window.EmailAmp = window.EmailAmp || {});
