/**
 * summaryPanel.js
 * Contadores (variáveis/imagens), status de pendências e lista de avisos.
 */
(function (ns) {
  'use strict';

  function el(id) { return document.getElementById(id); }

  function span(cls, text) {
    const s = document.createElement('span');
    if (cls) s.className = cls;
    s.textContent = text;
    return s;
  }

  function update(result, state) {
    const st = result.stats;

    el('statVars').textContent = st.vars;
    const vd = el('statVarsDetail');
    vd.textContent = '';
    if (st.vars) {
      vd.appendChild(span('n-ok', st.varsConfigured + ' configurada' + (st.varsConfigured === 1 ? '' : 's')));
      if (st.varsPending) {
        vd.appendChild(document.createTextNode(' · '));
        vd.appendChild(span('n-pending', st.varsPending + ' pendente' + (st.varsPending === 1 ? '' : 's')));
      }
    }

    el('statImages').textContent = st.images;
    const idt = el('statImagesDetail');
    idt.textContent = '';
    if (st.images) {
      idt.appendChild(span('n-ok', st.imagesChanging + ' a renomear'));
      if (st.imagesWithWarning) {
        idt.appendChild(document.createTextNode(' · '));
        idt.appendChild(span('n-pending', st.imagesWithWarning + ' com aviso'));
      }
    }

    const box = el('statusBox');
    const title = el('statusTitle');
    const list = el('pendingList');
    list.textContent = '';

    if (state.manualOutput !== null) {
      box.dataset.state = 'manual';
      title.textContent = state.manualStale
        ? 'Código editado manualmente — configurações alteradas depois da edição'
        : 'Código editado manualmente';
    } else if (result.complete) {
      box.dataset.state = 'done';
      title.textContent = 'Pronto: todas as substituições estão definidas';
    } else {
      box.dataset.state = 'pending';
      title.textContent = result.pending.length + (result.pending.length === 1 ? ' pendência' : ' pendências') + ' antes de concluir';
      result.pending.forEach(function (p) {
        const li = document.createElement('li');
        li.textContent = p;
        list.appendChild(li);
      });
    }

    const all = (state.source.warnings || []).concat(result.warnings);
    const panel = el('warningsPanel');
    const wl = el('warningsList');
    wl.textContent = '';
    panel.hidden = all.length === 0;
    all.forEach(function (w) {
      const li = document.createElement('li');
      li.className = w.level;
      li.textContent = w.message;
      wl.appendChild(li);
    });
    el('warningsTitle').textContent = 'Avisos (' + all.length + ')';
  }

  ns.SummaryPanel = { update };
})(window.EmailAmp = window.EmailAmp || {});
