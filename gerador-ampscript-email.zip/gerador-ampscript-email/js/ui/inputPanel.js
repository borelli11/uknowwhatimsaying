/**
 * inputPanel.js
 * Entrada do arquivo: upload, arrastar e soltar e caminho/URL. Também expõe o toast.
 */
(function (ns) {
  'use strict';

  let toastTimer = null;

  function toast(message, isError) {
    const el = document.getElementById('toast');
    el.textContent = message;
    el.classList.toggle('error', !!isError);
    el.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { el.classList.remove('show'); }, isError ? 6000 : 2200);
  }

  function isHtmlFile(file) {
    return /\.html?$/i.test(file.name) || file.type === 'text/html';
  }

  function init(onLoaded) {
    const drop = document.getElementById('dropZone');
    const fileInput = document.getElementById('fileInput');
    const pathInput = document.getElementById('pathInput');
    const pathBtn = document.getElementById('pathLoadBtn');

    function handleFile(file) {
      if (!file) return;
      if (!isHtmlFile(file) && !window.confirm('"' + file.name + '" não parece ser um arquivo HTML. Carregar mesmo assim?')) return;
      ns.FileLoader.readFile(file)
        .then(onLoaded)
        .catch(function (err) { toast('Erro ao ler o arquivo: ' + err.message, true); });
    }

    fileInput.addEventListener('change', function () {
      handleFile(fileInput.files[0]);
      fileInput.value = '';
    });

    drop.addEventListener('keydown', function (e) {
      if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); fileInput.click(); }
    });

    ['dragenter', 'dragover'].forEach(function (type) {
      drop.addEventListener(type, function (e) { e.preventDefault(); drop.classList.add('dragging'); });
    });
    ['dragleave', 'drop'].forEach(function (type) {
      drop.addEventListener(type, function (e) { e.preventDefault(); drop.classList.remove('dragging'); });
    });
    drop.addEventListener('drop', function (e) {
      const files = e.dataTransfer && e.dataTransfer.files;
      if (!files || !files.length) return;
      if (files.length > 1) toast('Mais de um arquivo solto — apenas o primeiro foi carregado.');
      handleFile(files[0]);
    });

    // Evita que soltar o arquivo fora da área abra o HTML no navegador
    window.addEventListener('dragover', function (e) { e.preventDefault(); });
    window.addEventListener('drop', function (e) { e.preventDefault(); });

    function loadPath() {
      pathBtn.disabled = true;
      ns.FileLoader.readFromPath(pathInput.value)
        .then(onLoaded)
        .catch(function (err) { toast(err.message, true); })
        .finally(function () { pathBtn.disabled = false; });
    }
    pathBtn.addEventListener('click', loadPath);
    pathInput.addEventListener('keydown', function (e) { if (e.key === 'Enter') loadPath(); });
  }

  function setFileInfo(source) {
    const el = document.getElementById('fileInfo');
    const kb = (new Blob([source.text]).size / 1024).toFixed(1);
    el.textContent = source.name + ' · ' + kb + ' KB · ' + source.encoding;
    el.classList.add('loaded');
  }

  ns.InputPanel = { init, setFileInfo, toast };
})(window.EmailAmp = window.EmailAmp || {});
