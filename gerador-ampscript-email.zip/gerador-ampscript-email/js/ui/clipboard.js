/**
 * clipboard.js
 * Cópia para a área de transferência. Usa a API moderna e recorre a execCommand
 * quando a página é aberta direto do disco ou o navegador bloqueia a API.
 */
(function (ns) {
  'use strict';

  function fallbackCopy(text) {
    const ta = document.createElement('textarea');
    ta.value = text;
    ta.setAttribute('readonly', '');
    ta.style.position = 'fixed';
    ta.style.top = '-1000px';
    document.body.appendChild(ta);
    ta.select();
    let ok = false;
    try { ok = document.execCommand('copy'); } catch (e) { ok = false; }
    document.body.removeChild(ta);
    return ok;
  }

  function copy(text) {
    if (navigator.clipboard && window.isSecureContext) {
      return navigator.clipboard.writeText(text).then(
        function () { return true; },
        function () { return fallbackCopy(text); }
      );
    }
    return Promise.resolve(fallbackCopy(text));
  }

  ns.Clipboard = { copy };
})(window.EmailAmp = window.EmailAmp || {});
