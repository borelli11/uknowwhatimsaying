/**
 * codePanel.js
 * Preview do código original e final (com destaque das alterações), abas no celular,
 * expansão em tela cheia, edição manual com confirmação e cópia.
 */
(function (ns) {
  'use strict';

  const esc = ns.HtmlUtils.escapeHtml;
  let api = null;          // { getState, onManualCommit, onDiscardManual }
  let editing = false;
  let lastOriginalText = null;

  function el(id) { return document.getElementById(id); }

  function renderSegments(segments) {
    let html = '';
    for (let i = 0; i < segments.length; i++) {
      const s = segments[i];
      html += s.kind
        ? '<mark class="hl hl-' + s.kind + '">' + esc(s.text) + '</mark>'
        : esc(s.text);
    }
    return html;
  }

  function currentFinalText() {
    const state = api.getState();
    if (editing) return el('finalEditor').value;
    if (!state.source) return '';
    return state.manualOutput !== null ? state.manualOutput : state.lastResult.output;
  }

  /* ---------- Expandir ---------- */
  function setExpanded(panel, on) {
    panel.classList.toggle('expanded', on);
    const btn = panel.querySelector('[data-expand]');
    if (btn) btn.textContent = on ? 'Recolher' : 'Expandir';
    document.body.classList.toggle('no-scroll', !!document.querySelector('.code-panel.expanded'));
  }

  /* ---------- Edição ---------- */
  function startEdit() {
    const state = api.getState();
    if (!state.source) return;
    if (!window.confirm('Você deseja editar o código?')) return;
    editing = true;
    const editor = el('finalEditor');
    editor.value = currentFinalTextRaw(state);
    el('finalCode').hidden = true;
    editor.hidden = false;
    el('editActions').hidden = false;
    el('editBtn').disabled = true;
    editor.focus();
    editor.setSelectionRange(0, 0);
    editor.scrollTop = 0;
  }

  function currentFinalTextRaw(state) {
    return state.manualOutput !== null ? state.manualOutput : state.lastResult.output;
  }

  function stopEdit() {
    editing = false;
    el('finalEditor').hidden = true;
    el('finalCode').hidden = false;
    el('editActions').hidden = true;
    el('editBtn').disabled = false;
  }

  function commitEdit() {
    const state = api.getState();
    let text = el('finalEditor').value;
    // Textareas normalizam quebras de linha para LF; restaura CRLF se o arquivo original usa CRLF.
    if (state.analysis.eol === '\r\n') text = text.replace(/\r?\n/g, '\r\n');
    const unchanged = text === currentFinalTextRaw(state);
    stopEdit();
    if (unchanged) {
      ns.InputPanel.toast('Nenhuma alteração feita no código.');
      return;
    }
    api.onManualCommit(text);
    ns.InputPanel.toast('Edição concluída.');
  }

  function cancelEdit() {
    const state = api.getState();
    const changed = el('finalEditor').value !== currentFinalTextRaw(state).replace(/\r\n/g, '\n');
    if (changed && !window.confirm('Descartar as alterações feitas nesta edição?')) return;
    stopEdit();
  }

  /* ---------- Copiar ---------- */
  function copyCode() {
    const state = api.getState();
    if (!state.source) { ns.InputPanel.toast('Carregue um arquivo HTML primeiro.', true); return; }
    const r = state.lastResult;
    if (state.manualOutput === null && !editing && !r.complete) {
      const msg = 'Existem pendências:\n- ' + r.pending.join('\n- ') + '\n\nCopiar o código mesmo assim?';
      if (!window.confirm(msg)) return;
    }
    ns.Clipboard.copy(currentFinalText()).then(function (ok) {
      ns.InputPanel.toast(ok ? 'Código copiado.' : 'Não foi possível copiar. Selecione o código e use Ctrl+C.', !ok);
    });
  }

  function init(a) {
    api = a;

    document.querySelectorAll('[data-expand]').forEach(function (btn) {
      btn.addEventListener('click', function () {
        const panel = el(btn.dataset.expand);
        setExpanded(panel, !panel.classList.contains('expanded'));
      });
    });
    document.addEventListener('keydown', function (e) {
      if (e.key !== 'Escape') return;
      document.querySelectorAll('.code-panel.expanded').forEach(function (p) { setExpanded(p, false); });
    });

    document.querySelectorAll('.tab').forEach(function (tab) {
      tab.addEventListener('click', function () {
        el('codeGrid').dataset.active = tab.dataset.tab;
        document.querySelectorAll('.tab').forEach(function (t) {
          t.setAttribute('aria-selected', String(t === tab));
        });
      });
    });

    el('editBtn').addEventListener('click', startEdit);
    el('commitEditBtn').addEventListener('click', commitEdit);
    el('cancelEditBtn').addEventListener('click', cancelEdit);
    el('copyBtn').addEventListener('click', copyCode);
    el('discardManualBtn').addEventListener('click', function () {
      if (!window.confirm('Descartar a edição manual e gerar o código novamente a partir das configurações?')) return;
      api.onDiscardManual();
    });
  }

  /** Chamado ao carregar um novo arquivo. */
  function reset() {
    if (editing) stopEdit();
    document.querySelectorAll('.code-panel.expanded').forEach(function (p) { setExpanded(p, false); });
    lastOriginalText = null;
  }

  function update(result, state) {
    // Original muda só quando os destaques mudam
    const originalHtml = renderSegments(result.originalSegments);
    if (originalHtml !== lastOriginalText) {
      const pre = el('originalCode');
      const top = pre.scrollTop, left = pre.scrollLeft;
      pre.innerHTML = originalHtml;
      pre.scrollTop = top; pre.scrollLeft = left;
      lastOriginalText = originalHtml;
    }

    const finalPre = el('finalCode');
    const top = finalPre.scrollTop, left = finalPre.scrollLeft;
    if (state.manualOutput !== null) {
      finalPre.textContent = state.manualOutput;
    } else {
      finalPre.innerHTML = renderSegments(result.finalSegments);
    }
    finalPre.scrollTop = top; finalPre.scrollLeft = left;

    const banner = el('manualBanner');
    banner.hidden = state.manualOutput === null;
    banner.classList.toggle('stale', state.manualStale);
    el('manualBannerText').textContent = state.manualStale
      ? 'As configurações mudaram depois da edição manual. O código abaixo não inclui essas mudanças.'
      : 'Código editado manualmente. Avisos e pendências se referem à geração automática.';
  }

  function isEditing() { return editing; }

  ns.CodePanel = { init, update, reset, isEditing };
})(window.EmailAmp = window.EmailAmp || {});
