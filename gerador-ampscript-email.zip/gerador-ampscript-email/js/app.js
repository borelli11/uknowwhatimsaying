/**
 * app.js
 * Estado central e ligação entre os módulos. Toda regra de negócio fica em js/core;
 * aqui só se atualiza o estado e se pede para a interface redesenhar.
 */
(function (ns) {
  'use strict';

  const state = {
    source: null,          // { text, name, encoding, warnings }
    analysis: null,        // resultado de Processor.analyze
    varConfig: {},         // nome -> { field, treatment }
    imageInclude: {},      // índice -> boolean
    imagePrefix: '',
    blockMode: 'after-body',
    manualOutput: null,    // string quando o código final foi editado manualmente
    manualStale: false,    // configurações mudaram depois da edição manual
    lastResult: null
  };

  let codeTimer = null;

  function refresh(immediate) {
    if (!state.source) return;
    const result = ns.Processor.build(state);
    state.lastResult = result;
    ns.VariablesPanel.update(result);
    ns.ImagesPanel.update(result);
    ns.SummaryPanel.update(result, state);

    clearTimeout(codeTimer);
    if (immediate) {
      ns.CodePanel.update(result, state);
    } else {
      // Evita redesenhar HTMLs grandes a cada tecla
      codeTimer = setTimeout(function () { ns.CodePanel.update(state.lastResult, state); }, 150);
    }
  }

  function configChanged() {
    if (state.manualOutput !== null) state.manualStale = true;
    refresh(false);
  }

  function loadSource(source) {
    if (state.manualOutput !== null || ns.CodePanel.isEditing()) {
      if (!window.confirm('O código final atual tem edição manual que será perdida. Carregar o novo arquivo?')) return;
    }
    ns.CodePanel.reset();

    state.source = source;
    state.analysis = ns.Processor.analyze(source.text);
    state.varConfig = {};
    state.analysis.vars.groups.forEach(function (g) {
      state.varConfig[g.name] = ns.Processor.defaultVarConfig(g);
    });
    state.imageInclude = {};
    state.analysis.images.items.forEach(function (img) {
      state.imageInclude[img.index] = ns.Processor.defaultImageInclude(img);
    });
    // O prefixo é específico de cada campanha: não reaproveitar o do arquivo anterior
    state.imagePrefix = '';
    state.manualOutput = null;
    state.manualStale = false;

    ns.InputPanel.setFileInfo(source);
    ns.VariablesPanel.render(state, function (name, patch) {
      Object.assign(state.varConfig[name], patch);
      configChanged();
    });
    ns.ImagesPanel.render(state);
    refresh(true);
    ns.InputPanel.toast('Arquivo carregado: ' + state.analysis.vars.groups.length + ' variável(is), ' + state.analysis.images.items.length + ' imagem(ns).');
  }

  function start() {
    ns.InputPanel.init(loadSource);

    ns.ImagesPanel.init({
      onPrefix: function (value) { state.imagePrefix = value; configChanged(); },
      onInclude: function (index, on) { state.imageInclude[index] = on; configChanged(); },
      onToggleAll: function (on) {
        if (!state.analysis) return;
        state.analysis.images.items.forEach(function (img) {
          if (img.status !== 'unrecognized') state.imageInclude[img.index] = on;
        });
        configChanged();
      }
    });

    const blockMode = document.getElementById('blockMode');
    blockMode.value = state.blockMode;
    blockMode.addEventListener('change', function () {
      state.blockMode = blockMode.value;
      configChanged();
    });

    ns.CodePanel.init({
      getState: function () { return state; },
      onManualCommit: function (text) {
        state.manualOutput = text;
        state.manualStale = false;
        refresh(true);
      },
      onDiscardManual: function () {
        state.manualOutput = null;
        state.manualStale = false;
        refresh(true);
      }
    });
  }

  document.addEventListener('DOMContentLoaded', start);
})(window.EmailAmp = window.EmailAmp || {});
