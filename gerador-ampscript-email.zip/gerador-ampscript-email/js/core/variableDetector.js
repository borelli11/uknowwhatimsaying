/**
 * variableDetector.js
 * Identifica variáveis no formato %%Nome%%.
 *
 * O HTML é percorrido da esquerda para a direita reconhecendo três tipos de token:
 *   %%[ ... ]%%   bloco AMPscript existente   -> ignorado
 *   %%= ... =%%   AMPscript inline existente  -> ignorado
 *   %%Nome%%      variável                    -> registrada
 * Assim, delimitadores de AMPscript já presentes nunca são confundidos com variáveis.
 */
(function (ns) {
  'use strict';

  // Nome: letras (inclusive acentuadas), números, "_", e espaços/hífens internos (nomes de campo como "Primeiro Nome").
  const TOKEN_RE = /%%\[[\s\S]*?\]%%|%%=[\s\S]*?=%%|%%([\p{L}\p{N}_](?:[\p{L}\p{N}_ \-]{0,98}[\p{L}\p{N}_])?)%%/gu;

  function detect(text) {
    const occurrences = [];
    const ampRanges = [];
    const consumed = [];

    TOKEN_RE.lastIndex = 0;
    let m;
    while ((m = TOKEN_RE.exec(text)) !== null) {
      const range = { start: m.index, end: m.index + m[0].length };
      consumed.push(range);
      if (m[1] !== undefined) {
        occurrences.push({ name: m[1], raw: m[0], start: range.start, end: range.end });
      } else {
        ampRanges.push(range);
      }
    }

    // "%%" que sobraram fora de qualquer token reconhecido (ex.: %%Nome.Campo%%, %%Nome sem fechamento)
    let rest = '';
    let pos = 0;
    consumed.forEach(function (r) { rest += text.slice(pos, r.start); pos = r.end; });
    rest += text.slice(pos);
    const strayCount = (rest.match(/%%/g) || []).length;

    // Agrupamento por nome exato (preserva ordem de aparição)
    const map = new Map();
    occurrences.forEach(function (o) {
      if (!map.has(o.name)) map.set(o.name, { name: o.name, occurrences: [] });
      map.get(o.name).occurrences.push(o);
    });
    const groups = Array.from(map.values());

    // Nomes que diferem apenas por maiúsculas/minúsculas
    const byLower = new Map();
    groups.forEach(function (g) {
      const k = g.name.toLowerCase();
      if (!byLower.has(k)) byLower.set(k, []);
      byLower.get(k).push(g.name);
    });
    const caseVariants = Array.from(byLower.values()).filter(function (a) { return a.length > 1; });

    return { occurrences, groups, ampRanges, strayCount, caseVariants };
  }

  ns.VariableDetector = { detect };
})(window.EmailAmp = window.EmailAmp || {});
