/**
 * processor.js
 * Orquestra detecção, regras de substituição e geração.
 *   analyze(text)  -> executado uma vez por arquivo carregado
 *   build(state)   -> executado a cada mudança de configuração (não altera o state)
 */
(function (ns) {
  'use strict';

  const KEEP = '__keep__';
  const PREFIX_RE = /^[A-Za-z0-9-]+$/;

  // Strings de personalização/sistema do Marketing Cloud: por padrão ficam como estão.
  const SYSTEM_STRINGS = new Set([
    'view_email_url', 'ftaf_url', 'unsub_center_url', 'profile_center_url', 'subscription_center_url',
    'double_opt_in_url', 'emailname_', '_emailid', '_subscriberkey', 'subscriberid', 'jobid',
    '_jobsubscriberbatchid', '_datasourcename', '_impressionregionname', '_messagecontext', '_preheader',
    '_replycontactname', '_replycontactemail', 'linkname', 'emailaddr', 'member_busname', 'member_addr',
    'member_city', 'member_state', 'member_postalcode', 'member_country', 'xtmonth', 'xtmonthnumeric',
    'xtday', 'xtdayofweek', 'xtyear', 'xtshortdate', 'xtlongdate'
  ]);

  function isSystem(name) {
    return SYSTEM_STRINGS.has(name.toLowerCase());
  }

  function analyze(text) {
    return {
      vars: ns.VariableDetector.detect(text),
      images: ns.ImageDetector.detect(text),
      htmlWarnings: ns.HtmlUtils.validate(text),
      body: ns.HtmlUtils.findBodyTag(text),
      eol: ns.HtmlUtils.detectEol(text)
    };
  }

  function defaultVarConfig(group) {
    return { field: '', treatment: isSystem(group.name) ? KEEP : 'none' };
  }

  function defaultImageInclude(item) {
    return item.status === 'ok';
  }

  function plural(n, one, many) {
    return n + ' ' + (n === 1 ? one : many);
  }

  function build(state) {
    const text = state.source.text;
    const a = state.analysis;
    const warnings = a.htmlWarnings.slice();
    const edits = [];
    const originalMarks = [];

    /* ---------------- ETAPA 1: variáveis ---------------- */
    const vars = a.vars.groups.map(function (g) {
      const cfg = state.varConfig[g.name];
      const row = {
        name: g.name, count: g.occurrences.length, system: isSystem(g.name),
        status: 'pending', message: '', field: '', varName: '', expression: '', inline: ''
      };
      if (cfg.treatment === KEEP) {
        row.status = 'keep';
        row.message = row.system ? 'String do Marketing Cloud — mantida como está' : 'Mantida como está';
        return row;
      }
      const field = cfg.field.trim();
      if (!field) { row.message = 'Informe o campo da DE'; return row; }
      const fv = ns.Ampscript.validateField(field);
      if (!fv.ok) { row.status = 'error'; row.message = fv.error; return row; }
      const t = ns.Transforms.get(cfg.treatment);
      if (!t) { row.status = 'error'; row.message = 'Tratamento desconhecido'; return row; }
      row.status = 'ok';
      row.field = field;
      row.varName = fv.varName;
      row.expression = t.build('@' + fv.varName);
      row.inline = ns.Ampscript.inline(row.expression);
      if (fv.renamed) row.message = 'Variável criada como @' + fv.varName;
      return row;
    });

    // Uma mesma @variável não pode representar campos diferentes (AMPscript não diferencia maiúsculas)
    const fieldsByVar = new Map();
    vars.forEach(function (v) {
      if (v.status !== 'ok') return;
      const k = v.varName.toLowerCase();
      if (!fieldsByVar.has(k)) fieldsByVar.set(k, new Map());
      fieldsByVar.get(k).set(v.field.toLowerCase(), v.field);
    });
    vars.forEach(function (v) {
      if (v.status !== 'ok') return;
      const fields = fieldsByVar.get(v.varName.toLowerCase());
      if (fields.size > 1) {
        v.status = 'error';
        v.message = '@' + v.varName + ' seria usada para campos diferentes: ' + Array.from(fields.values()).join(', ');
      }
    });

    a.vars.groups.forEach(function (g, i) {
      const v = vars[i];
      g.occurrences.forEach(function (o) {
        const key = 'var:' + g.name;
        if (v.status === 'ok') {
          edits.push({ start: o.start, end: o.end, replacement: v.inline, kind: 'var', key: key });
          originalMarks.push({ start: o.start, end: o.end, kind: 'var', key: key });
        } else {
          const kind = v.status === 'keep' ? 'keep' : 'pending';
          edits.push({ start: o.start, end: o.end, replacement: o.raw, kind: kind, key: key });
          originalMarks.push({ start: o.start, end: o.end, kind: kind, key: key });
        }
      });
      if (g.occurrences.length > 1) {
        warnings.push({ level: 'info', message: '%%' + g.name + '%% aparece ' + g.occurrences.length + ' vezes. Todas as ocorrências recebem a mesma substituição.' });
      }
    });

    a.vars.caseVariants.forEach(function (names) {
      warnings.push({
        level: 'warn',
        message: 'Variáveis com o mesmo nome e grafia diferente: ' + names.map(function (n) { return '%%' + n + '%%'; }).join(', ') +
          '. Confira se se referem ao mesmo campo da DE.'
      });
    });

    if (a.vars.strayCount > 0) {
      warnings.push({
        level: 'warn',
        message: 'Há ' + plural(a.vars.strayCount, 'ocorrência', 'ocorrências') + ' de "%%" que não forma variável reconhecida (ex.: nome com ponto ou sem fechamento). Esses trechos não serão alterados.'
      });
    }

    /* Bloco de declarações (SET @Var = AttributeValue("Campo")) */
    const declMap = new Map();
    vars.forEach(function (v) {
      if (v.status === 'ok' && !declMap.has(v.varName.toLowerCase())) {
        declMap.set(v.varName.toLowerCase(), { field: v.field, varName: v.varName });
      }
    });
    const decls = Array.from(declMap.values());
    const block = { mode: state.blockMode, text: '', inserted: false, message: '' };
    let blockPending = false;

    let insertAt = -1;
    if (decls.length) {
      block.text = ns.Ampscript.declarationBlock(decls, a.eol);
      if (state.blockMode === 'start') {
        insertAt = 0;
        edits.push({ start: 0, end: 0, replacement: block.text + a.eol, kind: 'block', key: 'block' });
        block.inserted = true;
        block.message = 'Inserido no início do arquivo.';
      } else if (state.blockMode === 'after-body') {
        if (a.body.count === 0) {
          blockPending = true;
          block.message = 'Tag <body> não encontrada — o bloco não foi inserido.';
          warnings.push({ level: 'error', message: 'Não foi possível inserir o bloco de declarações: tag <body> não encontrada. Escolha "Não inserir" e declare as variáveis manualmente, ou corrija o HTML.' });
        } else {
          if (a.body.count > 1) {
            warnings.push({ level: 'warn', message: 'O HTML tem ' + a.body.count + ' tags <body>. O bloco foi inserido após a primeira.' });
          }
          insertAt = a.body.end;
          edits.push({ start: a.body.end, end: a.body.end, replacement: a.eol + block.text, kind: 'block', key: 'block' });
          block.inserted = true;
          block.message = 'Inserido logo após a tag <body>.';
        }
      } else {
        block.message = 'Não inserido. As variáveis precisam estar declaradas no HTML.';
      }

      if (insertAt > 0) {
        const early = [];
        a.vars.groups.forEach(function (g, i) {
          if (vars[i].status === 'ok' && g.occurrences.some(function (o) { return o.start < insertAt; })) early.push('%%' + g.name + '%%');
        });
        if (early.length) {
          warnings.push({
            level: 'warn',
            message: early.join(', ') + ' aparece antes da tag <body> (ex.: no <title>). Nesse ponto a variável ainda não foi declarada. ' +
              'Se precisar desse valor ali, escolha inserir o bloco no início do arquivo.'
          });
        }
      }

      decls.forEach(function (d) {
        const already = new RegExp('SET\\s+@' + d.varName + '\\s*=', 'i').test(text);
        if (already && block.inserted) {
          warnings.push({ level: 'warn', message: 'O HTML já contém "SET @' + d.varName + '". Com o bloco inserido, a declaração ficará duplicada.' });
        } else if (!already && state.blockMode === 'none') {
          warnings.push({ level: 'warn', message: '@' + d.varName + ' não está declarada no HTML e o bloco de declarações está desativado. Ela ficará vazia no envio.' });
        }
      });
    }

    /* ---------------- ETAPA 2: imagens ---------------- */
    const prefix = state.imagePrefix;
    const images = a.images.items.map(function (img) {
      return Object.assign({}, img, {
        include: !!state.imageInclude[img.index],
        selectable: img.status === 'ok' || img.status === 'ambiguous',
        newFileName: '',
        willChange: false
      });
    });
    const eligible = images.filter(function (r) { return r.selectable && r.include; });

    let prefixState = 'ok';
    if (eligible.length) {
      if (prefix === '') prefixState = 'empty';
      else if (!PREFIX_RE.test(prefix)) prefixState = 'invalid';
    }

    eligible.forEach(function (r) {
      if (prefixState !== 'ok') return;
      r.newFileName = prefix + r.fileName.slice(r.prefix.length);
      r.willChange = r.prefix !== prefix;
      const key = 'img:' + r.index;
      if (r.willChange) {
        edits.push({ start: r.prefixStart, end: r.prefixEnd, replacement: prefix, kind: 'img', key: key });
      }
      originalMarks.push({ start: r.prefixStart, end: r.prefixEnd, kind: 'img', key: key });
    });

    images.forEach(function (r) {
      const label = r.fileName || r.src || 'sem src';
      if (r.status === 'unrecognized') {
        warnings.push({ level: 'warn', message: 'Imagem ' + (r.index + 1) + ' (' + label + '): ' + r.reasons.join('; ') + '. Não será alterada.' });
      } else if (r.status === 'ambiguous') {
        warnings.push({
          level: 'warn',
          message: 'Imagem ' + (r.index + 1) + ' (' + label + '): ' + r.reasons.join('; ') + '. ' +
            (r.include ? 'Marcada para alteração pelo usuário.' : 'Desmarcada por padrão — marque para alterar mesmo assim.')
        });
      }
    });
    if (prefixState === 'invalid') {
      warnings.push({ level: 'error', message: 'Prefixo inválido. Use apenas letras sem acento, números e hífen (sem espaços, "_", "/" ou "?").' });
    }
    if (a.images.otherRefs > 0) {
      warnings.push({ level: 'info', message: plural(a.images.otherRefs, 'referência', 'referências') + ' de imagem fora de <img src> (background, url() ou VML). Não são alteradas.' });
    }

    /* ---------------- Resultado ---------------- */
    const result = ns.ReplacementEngine.apply(text, edits);
    if (result.conflicts.length) {
      warnings.push({ level: 'error', message: plural(result.conflicts.length, 'substituição conflitante foi ignorada', 'substituições conflitantes foram ignoradas') + ' (trechos sobrepostos).' });
    }

    const pendingVars = vars.filter(function (v) { return v.status === 'pending' || v.status === 'error'; }).length;
    const pending = [];
    if (a.htmlWarnings.some(function (w) { return w.level === 'error'; })) pending.push('HTML vazio ou inválido');
    if (pendingVars) pending.push(plural(pendingVars, 'variável sem associação válida', 'variáveis sem associação válida'));
    if (prefixState === 'empty') pending.push('Prefixo das imagens não informado');
    if (prefixState === 'invalid') pending.push('Prefixo das imagens inválido');
    if (blockPending) pending.push('Bloco de declarações não inserido');
    if (result.conflicts.length) pending.push('Substituições conflitantes');

    const levelOrder = { error: 0, warn: 1, info: 2 };
    warnings.sort(function (x, y) { return levelOrder[x.level] - levelOrder[y.level]; });

    return {
      output: result.output,
      finalSegments: result.segments,
      originalSegments: ns.ReplacementEngine.mark(text, originalMarks),
      vars: vars,
      images: images,
      block: block,
      prefixState: prefixState,
      warnings: warnings,
      pending: pending,
      complete: pending.length === 0,
      stats: {
        vars: vars.length,
        varsConfigured: vars.length - pendingVars,
        varsPending: pendingVars,
        images: images.length,
        imagesChanging: images.filter(function (r) { return r.willChange; }).length,
        imagesWithWarning: images.filter(function (r) { return r.status !== 'ok'; }).length
      }
    };
  }

  ns.Processor = { KEEP, analyze, build, defaultVarConfig, defaultImageInclude, isSystem };
})(window.EmailAmp = window.EmailAmp || {});
