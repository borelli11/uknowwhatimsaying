/**
 * fileReader.js
 * Leitura do HTML de entrada. Mantém o conteúdo exatamente como está no arquivo.
 */
(function (ns) {
  'use strict';

  function decode(buffer) {
    const bytes = new Uint8Array(buffer);
    try {
      return { text: new TextDecoder('utf-8', { fatal: true }).decode(bytes), encoding: 'UTF-8', warnings: [] };
    } catch (e) {
      return {
        text: new TextDecoder('windows-1252').decode(bytes),
        encoding: 'Windows-1252',
        warnings: [{
          level: 'warn',
          message: 'O arquivo não está em UTF-8 e foi lido como Windows-1252 (ANSI). Confira os acentos do código final antes de usar.'
        }]
      };
    }
  }

  /** Upload / arrastar e soltar. */
  function readFile(file) {
    return file.arrayBuffer().then(function (buf) {
      const d = decode(buf);
      return { text: d.text, encoding: d.encoding, warnings: d.warnings, name: file.name };
    });
  }

  const LOCAL_PATH_MSG =
    'O navegador não permite ler um arquivo do computador ou da rede a partir de um caminho digitado (não há backend). ' +
    'Clique na área de upload e cole esse caminho no campo "Nome do arquivo" da janela que abrir.';

  function isLocalPath(p) {
    return /^[a-zA-Z]:[\\/]/.test(p) || p.indexOf('\\\\') === 0 || /^file:/i.test(p);
  }

  /** Caminho/URL: funciona para URLs http(s) com CORS liberado ou caminhos relativos quando a página é servida por http. */
  function readFromPath(path) {
    const p = (path || '').trim();
    if (!p) return Promise.reject(new Error('Informe um caminho ou URL.'));
    const isHttp = /^https?:\/\//i.test(p);
    const servedOverHttp = /^https?:$/.test(window.location.protocol);
    if (!isHttp && (isLocalPath(p) || !servedOverHttp)) {
      return Promise.reject(new Error(LOCAL_PATH_MSG));
    }
    return fetch(p)
      .catch(function () {
        throw new Error('Não foi possível acessar "' + p + '". O servidor pode estar bloqueando o acesso (CORS) ou o endereço está incorreto.');
      })
      .then(function (res) {
        if (!res.ok) throw new Error('O endereço respondeu com erro ' + res.status + '.');
        return res.arrayBuffer();
      })
      .then(function (buf) {
        const d = decode(buf);
        const name = p.split(/[\\/]/).pop().split(/[?#]/)[0] || p;
        return { text: d.text, encoding: d.encoding, warnings: d.warnings, name: name };
      });
  }

  ns.FileLoader = { readFile, readFromPath };
})(window.EmailAmp = window.EmailAmp || {});
