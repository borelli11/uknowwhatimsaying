/**
 * ampscriptBuilder.js
 * Geração de AMPscript:
 *  - inline:     %%=Expressao=%%
 *  - declaração: %%[ SET @Var = AttributeValue("Campo") ]%%
 */
(function (ns) {
  'use strict';

  /** Nome de variável AMPscript seguro: letras sem acento, números e "_". */
  function toVarName(field) {
    let n = field
      .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
      .replace(/[^A-Za-z0-9_]/g, '');
    if (/^[0-9]/.test(n)) n = '_' + n;
    return n;
  }

  function validateField(field) {
    if (/["\r\n]/.test(field)) {
      return { ok: false, error: 'O nome do campo não pode conter aspas ou quebra de linha.' };
    }
    const varName = toVarName(field);
    if (!varName) {
      return { ok: false, error: 'Não foi possível gerar um nome de variável a partir desse campo.' };
    }
    return { ok: true, varName: varName, renamed: varName !== field };
  }

  function inline(expression) {
    return '%%=' + expression + '=%%';
  }

  /**
   * @param {Array<{field:string, varName:string}>} decls
   * @param {string} eol fim de linha do arquivo original
   */
  function declarationBlock(decls, eol) {
    const lines = ['%%['];
    decls.forEach(function (d) {
      lines.push('SET @' + d.varName + ' = AttributeValue("' + d.field + '")');
    });
    lines.push(']%%');
    return lines.join(eol);
  }

  ns.Ampscript = { toVarName, validateField, inline, declarationBlock };
})(window.EmailAmp = window.EmailAmp || {});
