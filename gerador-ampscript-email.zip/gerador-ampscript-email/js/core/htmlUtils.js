/**
 * htmlUtils.js
 * Funções utilitárias sobre o texto HTML. Nunca altera o HTML: apenas lê e avalia.
 */
(function (ns) {
  'use strict';

  function escapeHtml(str) {
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  /** Retorna "\r\n" apenas se o arquivo usa CRLF de forma consistente. */
  function detectEol(text) {
    const crlf = (text.match(/\r\n/g) || []).length;
    const lf = (text.match(/\n/g) || []).length - crlf;
    return crlf > 0 && lf === 0 ? '\r\n' : '\n';
  }

  function count(text, re) {
    return (text.match(re) || []).length;
  }

  /** Lista intervalos [start, end) de todas as ocorrências de uma regex global. */
  function findRanges(text, re) {
    const out = [];
    re.lastIndex = 0;
    let m;
    while ((m = re.exec(text)) !== null) {
      out.push({ start: m.index, end: m.index + m[0].length });
      if (m[0].length === 0) re.lastIndex++;
    }
    return out;
  }

  function isInside(pos, ranges) {
    for (let i = 0; i < ranges.length; i++) {
      if (pos >= ranges[i].start && pos < ranges[i].end) return true;
    }
    return false;
  }

  /** Localiza a tag de abertura <body ...> (respeitando atributos entre aspas). */
  function findBodyTag(text) {
    const re = /<body\b(?:[^>"']|"[^"]*"|'[^']*')*>/gi;
    const all = [];
    let m;
    while ((m = re.exec(text)) !== null) all.push({ start: m.index, end: m.index + m[0].length });
    return { count: all.length, end: all.length ? all[0].end : -1 };
  }

  /**
   * Validação leve: só gera avisos, nunca corrige.
   * @returns {Array<{level:'error'|'warn'|'info', message:string}>}
   */
  function validate(text) {
    const w = [];
    if (!text || !text.trim()) {
      w.push({ level: 'error', message: 'O arquivo está vazio.' });
      return w;
    }
    const hasHtml = /<html\b/i.test(text);
    if (!hasHtml) w.push({ level: 'warn', message: 'HTML incompleto: tag <html> não encontrada.' });
    if (hasHtml && !/<\/html\s*>/i.test(text)) w.push({ level: 'warn', message: 'HTML incompleto: tag </html> não encontrada.' });
    if (!/<body\b/i.test(text)) w.push({ level: 'warn', message: 'HTML incompleto: tag <body> não encontrada.' });

    ['table', 'tr', 'td'].forEach(function (tag) {
      const open = count(text, new RegExp('<' + tag + '\\b', 'gi'));
      const close = count(text, new RegExp('</' + tag + '\\s*>', 'gi'));
      if (open !== close) {
        w.push({ level: 'warn', message: 'Possível tag não fechada: <' + tag + '> abre ' + open + ' e fecha ' + close + ' vez(es).' });
      }
    });

    const blockOpen = count(text, /%%\[/g);
    const blockClose = count(text, /\]%%/g);
    if (blockOpen !== blockClose) {
      w.push({ level: 'warn', message: 'Bloco AMPscript possivelmente não fechado: %%[ aparece ' + blockOpen + ' vez(es) e ]%% aparece ' + blockClose + '.' });
    }
    return w;
  }

  ns.HtmlUtils = { escapeHtml, detectEol, count, findRanges, isInside, findBodyTag, validate };
})(window.EmailAmp = window.EmailAmp || {});
