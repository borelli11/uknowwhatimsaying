/**
 * transforms.js
 * Registro de tratamentos AMPscript aplicáveis a uma variável.
 *
 * Para adicionar um tratamento novo, basta incluir um objeto na lista (ou chamar register):
 *   { id: 'uppercase', label: 'Uppercase', build: function (ref) { return 'Uppercase(' + ref + ')'; } }
 * "ref" é a referência da variável já com @ (ex.: "@PrimeiroNome").
 * O retorno é a expressão que ficará dentro de %%= ... =%%.
 */
(function (ns) {
  'use strict';

  const list = [
    {
      id: 'none',
      label: 'Nenhum',
      // v() exibe o valor de uma variável em AMPscript inline
      build: function (ref) { return 'v(' + ref + ')'; }
    },
    {
      id: 'propercase',
      label: 'ProperCase',
      build: function (ref) { return 'ProperCase(' + ref + ')'; }
    }
  ];

  function get(id) {
    for (let i = 0; i < list.length; i++) if (list[i].id === id) return list[i];
    return null;
  }

  function register(t) {
    if (!t || !t.id || typeof t.build !== 'function') throw new Error('Tratamento inválido');
    if (get(t.id)) throw new Error('Tratamento já registrado: ' + t.id);
    list.push(t);
  }

  ns.Transforms = { list, get, register };
})(window.EmailAmp = window.EmailAmp || {});
