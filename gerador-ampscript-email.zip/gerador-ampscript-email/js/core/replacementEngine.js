/**
 * replacementEngine.js
 * Aplica substituições por posição (início/fim) sobre o texto original.
 *
 * Integridade: o HTML nunca é convertido em DOM e reserializado. O resultado é montado
 * copiando literalmente os trechos entre as substituições. Edições sobrepostas são
 * rejeitadas e reportadas, nunca mescladas por suposição.
 *
 * Edição: { start, end, replacement, kind, key }
 *   - start === end  -> inserção
 *   - replacement igual ao trecho original -> marcação visual sem alteração
 */
(function (ns) {
  'use strict';

  function apply(text, edits) {
    const sorted = edits
      .map(function (e, i) { return Object.assign({ _order: i }, e); })
      .sort(function (a, b) {
        return a.start - b.start || (a.end - a.start) - (b.end - b.start) || a._order - b._order;
      });

    const accepted = [];
    const conflicts = [];
    let lastEnd = 0;
    sorted.forEach(function (e) {
      const invalid = e.start < 0 || e.end > text.length || e.end < e.start;
      if (invalid || e.start < lastEnd) { conflicts.push(e); return; }
      accepted.push(e);
      lastEnd = e.end;
    });

    const segments = [];
    let pos = 0;
    accepted.forEach(function (e) {
      if (e.start > pos) segments.push({ text: text.slice(pos, e.start) });
      segments.push({ text: e.replacement, kind: e.kind, key: e.key });
      pos = e.end;
    });
    if (pos < text.length) segments.push({ text: text.slice(pos) });

    return {
      output: segments.map(function (s) { return s.text; }).join(''),
      segments: segments,
      conflicts: conflicts
    };
  }

  /** Segmentos para destacar trechos do texto original sem alterá-lo. */
  function mark(text, ranges) {
    return apply(text, ranges.map(function (r) {
      return { start: r.start, end: r.end, replacement: text.slice(r.start, r.end), kind: r.kind, key: r.key };
    })).segments;
  }

  ns.ReplacementEngine = { apply, mark };
})(window.EmailAmp = window.EmailAmp || {});
