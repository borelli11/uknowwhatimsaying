/**
 * imageDetector.js
 * Identifica imagens em <img src="..."> e interpreta o nome do arquivo no padrão prefixo_ID.ext.
 * Calcula a posição exata do prefixo dentro do HTML para que somente esse trecho seja substituído.
 */
(function (ns) {
  'use strict';

  const IMG_TAG_RE = /<img\b(?:[^>"']|"[^"]*"|'[^']*')*>/gi;
  const SRC_ATTR_RE = /[\s"'\/]src\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s"'=<>`]+))/i;
  const COMMENT_RE = /<!--[\s\S]*?-->/g;
  const FILE_RE = /^([^_]+)_(.+)\.([A-Za-z0-9]+)$/;
  const EXT_OK_RE = /^(jpe?g|png|gif)$/i;
  const ID_OK_RE = /^\d+$/;

  // Referências de imagem que NÃO são <img src> (não são alteradas; apenas contadas para aviso)
  const OTHER_REF_RES = [
    /\bbackground\s*=\s*["']?[^"'\s>]+\.(?:jpe?g|png|gif)/gi,
    /url\(\s*["']?[^)"']*\.(?:jpe?g|png|gif)/gi,
    /<v:(?:fill|image)\b(?:[^>"']|"[^"]*"|'[^']*')*\bsrc\s*=/gi
  ];

  function parseSrc(src) {
    const r = { fileName: '', fileOffset: -1, prefix: '', id: '', ext: '', status: 'unrecognized', reasons: [] };
    if (!src.trim()) { r.reasons.push('src vazio'); return r; }
    if (src.indexOf('%%') !== -1) { r.reasons.push('src contém AMPscript/variável — não alterado'); return r; }
    if (/^data:/i.test(src)) { r.reasons.push('imagem embutida (data URI)'); return r; }

    const cut = src.search(/[?#]/);
    const pathPart = cut === -1 ? src : src.slice(0, cut);
    const slash = Math.max(pathPart.lastIndexOf('/'), pathPart.lastIndexOf('\\'));
    r.fileOffset = slash + 1;
    r.fileName = pathPart.slice(r.fileOffset);
    if (!r.fileName) { r.reasons.push('URL sem nome de arquivo'); return r; }

    const m = FILE_RE.exec(r.fileName);
    if (!m) {
      if (r.fileName.indexOf('_') === -1) r.reasons.push('nome sem "_" — padrão não reconhecido');
      else if (r.fileName.indexOf('_') === 0) r.reasons.push('nada antes do primeiro "_"');
      else r.reasons.push('sem extensão reconhecível');
      return r;
    }
    r.prefix = m[1];
    r.id = m[2];
    r.ext = m[3];
    const idOk = ID_OK_RE.test(r.id);
    const extOk = EXT_OK_RE.test(r.ext);
    if (!idOk) r.reasons.push('identificador após "_" não é numérico ("' + r.id + '")');
    if (!extOk) r.reasons.push('extensão .' + r.ext + ' fora do padrão (jpg, jpeg, png, gif)');
    r.status = idOk && extOk ? 'ok' : 'ambiguous';
    return r;
  }

  function detect(text) {
    const comments = ns.HtmlUtils.findRanges(text, COMMENT_RE);
    const items = [];

    IMG_TAG_RE.lastIndex = 0;
    let m;
    while ((m = IMG_TAG_RE.exec(text)) !== null) {
      const tag = m[0];
      const tagStart = m.index;
      const item = {
        index: items.length,
        tagStart: tagStart,
        inComment: ns.HtmlUtils.isInside(tagStart, comments),
        src: null, srcStart: -1,
        fileName: '', prefix: '', id: '', ext: '',
        prefixStart: -1, prefixEnd: -1,
        status: 'unrecognized', reasons: []
      };

      const a = SRC_ATTR_RE.exec(tag);
      if (!a) {
        item.reasons.push('tag <img> sem atributo src');
      } else {
        const quoted = a[1] !== undefined || a[2] !== undefined;
        const value = a[1] !== undefined ? a[1] : (a[2] !== undefined ? a[2] : a[3]);
        const valueEndInTag = a.index + a[0].length - (quoted ? 1 : 0);
        item.src = value;
        item.srcStart = tagStart + valueEndInTag - value.length;

        const p = parseSrc(value);
        item.fileName = p.fileName;
        item.prefix = p.prefix;
        item.id = p.id;
        item.ext = p.ext;
        item.status = p.status;
        item.reasons = p.reasons;
        if (p.prefix) {
          item.prefixStart = item.srcStart + p.fileOffset;
          item.prefixEnd = item.prefixStart + p.prefix.length;
        }
      }
      items.push(item);
    }

    let otherRefs = 0;
    OTHER_REF_RES.forEach(function (re) { otherRefs += ns.HtmlUtils.count(text, re); });

    return { items, otherRefs };
  }

  ns.ImageDetector = { detect, parseSrc };
})(window.EmailAmp = window.EmailAmp || {});
