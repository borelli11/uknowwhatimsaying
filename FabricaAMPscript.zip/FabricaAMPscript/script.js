"use strict";

/* ==============================================================
    CONFIGURAÇÕES GERAIS
============================================================== */

const PLACEHOLDER_REGEX = /%%([^%]+)%%/g;

const AMP_RESERVED_WORDS = new Set([
    "if",
    "else",
    "elseif",
    "then",
    "endif",
    "and",
    "or",
    "not",
    "empty",
    "set",
    "var",
    "for",
    "next",
    "to",
    "do",
    "while",
    "endwhile",
    "true",
    "false"
]);

const THEME_STORAGE_KEY = "bradesco_ampscript_theme";

const LOADER_MIN_MS = 700;

const LOADER_START = Date.now();

/*
    Guarda os dados da última geração bem-sucedida,
    exibidos no modal de Log.
*/
let ultimoLog = null;


/* ==============================================================
    INICIALIZAÇÃO DA PÁGINA
============================================================== */

document.addEventListener("DOMContentLoaded", () => {

    const form = document.getElementById("ampForm");
    const output = document.getElementById("output");
    const copyButton = document.getElementById("copyButton");
    const logButton = document.getElementById("logButton");
    const campoInput = document.getElementById("campo");
    const messageInput = document.getElementById("message");

    output.classList.add("is-empty");

    form.addEventListener("submit", (event) => {

        event.preventDefault();

        const deName = document
            .getElementById("deName")
            .value
            .trim();

        const campo = campoInput.value.trim();
        const message = messageInput.value.trim();

        try {

            const ampScript = generateAmpScript(
                deName,
                campo,
                message
            );

            output.textContent = ampScript;
            output.classList.remove("is-empty", "is-error");

            registrarLog(deName, campo, message);

        } catch (error) {

            output.textContent =
                "ERRO: " + error.message;

            output.classList.remove("is-empty");
            output.classList.add("is-error");

            limparLog();

            showToast(error.message, "error");

        }

    });


    campoInput.addEventListener("input", () => {

        updateConnectedFields();
        validateCampos();
        validateConnections();

    });


    messageInput.addEventListener("input", () => {

        updateConnectedFields();
        validateConnections();

    });


    copyButton.addEventListener("click", () => {

        copyGeneratedCode(output);

    });


    logButton.addEventListener("click", () => {

        openLogModal();

    });


    initThemeToggle();
    initLogModal();
    initTitleGlow();

    updateConnectedFields();
    validateCampos();
    validateConnections();

    hideLoader();

});


/* ==============================================================
    LOADER
============================================================== */

/**
 * Remove o loader respeitando um tempo mínimo de exibição,
 * para a transição não "piscar" em máquinas rápidas.
 */
function hideLoader() {

    const loader = document.getElementById("appLoader");

    if (!loader) {
        return;
    }

    const decorrido = Date.now() - LOADER_START;
    const espera = Math.max(0, LOADER_MIN_MS - decorrido);

    setTimeout(() => {

        loader.classList.add("is-hidden");

        loader.addEventListener(
            "transitionend",
            () => loader.remove(),
            { once: true }
        );

    }, espera);

}


/* ==============================================================
    TEMA CLARO / ESCURO
============================================================== */

/**
 * O tema inicial já foi aplicado pelo script crítico no <head>.
 * Aqui só controlamos a troca e a persistência.
 */
function initThemeToggle() {

    const toggle = document.getElementById("themeToggle");

    if (!toggle) {
        return;
    }

    toggle.addEventListener("click", () => {

        const atual =
            document.documentElement.getAttribute("data-theme");

        const novo = atual === "dark" ? "light" : "dark";

        document.documentElement.setAttribute("data-theme", novo);

        try {
            localStorage.setItem(THEME_STORAGE_KEY, novo);
        } catch (error) {
            console.warn("Não foi possível salvar o tema.", error);
        }

    });

}


/* ==============================================================
    BRILHO DO TÍTULO
============================================================== */

/**
 * Ao passar o mouse no título, o brilho (--glow) sobe
 * suavemente de 0 a 1 e desce ao sair.
 *
 * O --glow é interpolado por requestAnimationFrame para a
 * intensidade subir e descer sem "degrau", mesmo em sombras
 * que o CSS não consegue animar diretamente via calc().
 */
function initTitleGlow() {

    const container = document.getElementById("titleGlow");

    if (!container) {
        return;
    }

    const reduzMovimento = window.matchMedia &&
        window.matchMedia("(prefers-reduced-motion: reduce)").matches;

    let atual = 0;
    let alvo = 0;
    let frame = null;

    const animar = () => {

        atual += (alvo - atual) * 0.14;

        if (Math.abs(alvo - atual) < 0.005) {
            atual = alvo;
        }

        container.style.setProperty("--glow", atual.toFixed(3));

        frame = atual === alvo
            ? null
            : requestAnimationFrame(animar);

    };

    const definirAlvo = (valor) => {

        alvo = valor;

        if (reduzMovimento) {
            atual = valor;
            container.style.setProperty("--glow", String(valor));
            return;
        }

        if (!frame) {
            frame = requestAnimationFrame(animar);
        }

    };

    container.addEventListener("mouseenter", () => {

        definirAlvo(1);

    });

    container.addEventListener("mouseleave", () => {

        definirAlvo(0);

    });

}


/* ==============================================================
    TOASTS
============================================================== */

const TOAST_ICONS = {
    success: '<path d="M20 6 9 17l-5-5"></path>',
    error: '<circle cx="12" cy="12" r="10"></circle><path d="M15 9l-6 6M9 9l6 6"></path>',
    warn: '<path d="M10.3 3.9 1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0z"></path><path d="M12 9v4M12 17h.01"></path>',
    info: '<circle cx="12" cy="12" r="10"></circle><path d="M12 16v-4M12 8h.01"></path>'
};

/**
 * Exibe uma notificação temporária no canto da tela.
 * Substitui os antigos window.alert().
 *
 * type: "success" | "error" | "warn" | "info"
 */
function showToast(message, type = "info", duration = 3200) {

    const container = document.getElementById("toastContainer");

    if (!container) {
        return;
    }

    const toast = document.createElement("div");
    toast.className = `toast toast-${type}`;
    toast.setAttribute("role", type === "error" ? "alert" : "status");

    const icon = document.createElementNS("http://www.w3.org/2000/svg", "svg");
    icon.setAttribute("viewBox", "0 0 24 24");
    icon.setAttribute("aria-hidden", "true");
    icon.innerHTML = TOAST_ICONS[type] || TOAST_ICONS.info;

    const text = document.createElement("span");
    text.textContent = message;

    toast.append(icon, text);
    container.appendChild(toast);

    setTimeout(() => {

        toast.classList.add("is-leaving");

        toast.addEventListener(
            "animationend",
            () => toast.remove(),
            { once: true }
        );

    }, duration);

}


/* ==============================================================
    EXTRAÇÃO DOS PLACEHOLDERS
============================================================== */

/**
 * Localiza todos os placeholders no padrão %%texto%%.
 *
 * Retorna:
 * [
 *   {
 *     original: "Dia-do-mes",
 *     completo: "%%Dia-do-mes%%",
 *     variavel: "DiaDoMes"
 *   }
 * ]
 */
function extractPlaceholders(message) {

    return [...message.matchAll(PLACEHOLDER_REGEX)]
        .map(match => {

            const original = match[1].trim();

            return {
                original,
                completo: match[0],
                variavel: sanitizeVariableName(original)
            };

        });

}


/* ==============================================================
    HIGIENIZAÇÃO DAS VARIÁVEIS
============================================================== */

/**
 * Converte o conteúdo de um placeholder em um nome seguro
 * para utilização como variável AMPscript.
 *
 * Exemplos:
 *
 * ValorpréAprovado  -> ValorpreAprovado
 * dia-do-mes        -> DiaDoMes
 * nome_cliente      -> NomeCliente
 * 1oNome            -> v1oNome
 * if                -> VarIf
 */
function sanitizeVariableName(text) {

    if (typeof text !== "string") {
        throw new Error(
            "O nome da variável precisa ser um texto válido."
        );
    }

    /*
        1. Remove espaços das pontas.
        2. Decompõe letras acentuadas.
        3. Remove os sinais gráficos dos acentos.
    */

    const textoSemAcentos = text
        .trim()
        .normalize("NFD")
        .replace(/[\u0300-\u036f]/g, "");

    /*
        Substitui qualquer sequência de caracteres que não seja
        formada por letras ou números por um espaço temporário.

        Isso cobre:
        espaços, hífens, underlines, asteriscos, pontos, vírgulas,
        barras, contrabarras, aspas, parênteses, $, #, @, %, &,
        ?, ! e outros caracteres especiais.
    */

    const partes = textoSemAcentos
        .replace(/[^a-zA-Z0-9]+/g, " ")
        .trim()
        .split(/\s+/)
        .filter(Boolean);

    /*
        Se o placeholder possuir somente caracteres especiais,
        nenhum nome de variável válido poderá ser criado.
    */

    if (partes.length === 0) {

        throw new Error(
            `O placeholder "%%${text}%%" não possui letras ou números válidos.`
        );

    }

    /*
        Converte cada parte para CamelCase.

        dia-do-mes:
        ["dia", "do", "mes"] -> DiaDoMes
    */

    let nomeLimpo = partes
        .map(formatCamelCasePart)
        .join("");

    /*
        Uma variável não pode começar diretamente com número.
        Nesse caso, adiciona o prefixo "n".
    */

    if (/^[0-9]/.test(nomeLimpo)) {

        nomeLimpo = `n${nomeLimpo}`;

    }

    /*
        Impede que o resultado seja idêntico a uma palavra
        reservada da linguagem.
    */

    if (AMP_RESERVED_WORDS.has(nomeLimpo.toLowerCase())) {

        nomeLimpo = `Var${capitalizeFirstLetter(nomeLimpo)}`;

    }

    /*
        Validação final defensiva.

        Depois de todos os tratamentos, o resultado deve começar
        com uma letra e conter somente letras ou números.
    */

    if (!/^[a-zA-Z][a-zA-Z0-9]*$/.test(nomeLimpo)) {

        throw new Error(
            `Não foi possível gerar uma variável segura para "%%${text}%%".`
        );

    }

    return nomeLimpo;

}


/**
 * Formata uma parte do nome sem destruir letras maiúsculas
 * já existentes no meio da palavra.
 *
 * ValorpreAprovado -> ValorpreAprovado
 * dia              -> Dia
 * 1oNome           -> 1oNome
 */
function formatCamelCasePart(part) {

    if (!part) {
        return "";
    }

    if (/^[0-9]/.test(part)) {
        return part;
    }

    return capitalizeFirstLetter(part);

}


function capitalizeFirstLetter(text) {

    if (!text) {
        return "";
    }

    return text.charAt(0).toUpperCase() + text.slice(1);

}


/* ==============================================================
    VALIDAÇÃO DE NOMES DUPLICADOS
============================================================== */

/**
 * Impede que placeholders diferentes produzam o mesmo nome
 * depois da higienização.
 *
 * Exemplo de conflito:
 *
 * %%Dia-do-mes%% -> DiaDoMes
 * %%Dia_do_mes%% -> DiaDoMes
 */
function validateSanitizedVariableNames(placeholders) {

    const nomesUtilizados = new Map();

    placeholders.forEach(placeholder => {

        const chave =
            placeholder.variavel.toLowerCase();

        if (nomesUtilizados.has(chave)) {

            const placeholderAnterior =
                nomesUtilizados.get(chave);

            throw new Error(
                `Os placeholders "%%${placeholderAnterior.original}%%" ` +
                `e "%%${placeholder.original}%%" geram o mesmo nome ` +
                `de variável: @${placeholder.variavel}.`
            );

        }

        nomesUtilizados.set(
            chave,
            placeholder
        );

    });

}


/* ==============================================================
    PRÉ-VISUALIZAÇÃO DOS CAMPOS CONECTADOS
============================================================== */

function updateConnectedFields() {

    const campo = document
        .getElementById("campo")
        .value
        .trim();

    const message = document
        .getElementById("message")
        .value
        .trim();

    const container =
        document.getElementById("camposconect");

    let placeholders;

    try {

        placeholders = extractPlaceholders(message);

    } catch (error) {

        showEmptyConnections(
            container,
            error.message
        );

        return;

    }

    const camposDE = campo
        .split(";")
        .map(item => item.trim())
        .filter(item => item !== "");

    container.replaceChildren();

    if (
        placeholders.length === 0 ||
        camposDE.length === 0
    ) {

        showEmptyConnections(
            container,
            "Nenhuma conexão identificada."
        );

        return;

    }

    const quantidade = Math.min(
        placeholders.length,
        camposDE.length
    );

    for (let i = 0; i < quantidade; i++) {

        const placeholder =
            placeholders[i];

        const badge =
            document.createElement("div");

        const variable =
            document.createElement("span");

        const arrow =
            document.createElement("span");

        const field =
            document.createElement("span");

        badge.className =
            "connection-badge";

        variable.className =
            "connection-variable";

        arrow.className =
            "connection-arrow";

        field.className =
            "connection-field";

        /*
            A interface mostra o nome já higienizado, exatamente
            como será utilizado dentro do AMPscript.
        */

        variable.textContent =
            `%%${placeholder.variavel}%%`;

        arrow.textContent = "→";
        field.textContent = camposDE[i];

        badge.append(
            variable,
            arrow,
            field
        );

        container.appendChild(badge);

    }

}


function showEmptyConnections(container, message) {

    const emptyMessage =
        document.createElement("div");

    emptyMessage.className =
        "empty-connections";

    emptyMessage.textContent = message;

    container.replaceChildren(emptyMessage);

}


/* ==============================================================
    VALIDAÇÃO DOS CAMPOS CONTRA OS ATALHOS
============================================================== */

function validateCampos() {

    const campoInput = document
        .getElementById("campo")
        .value
        .trim();

    const alerta =
        document.getElementById("campoAlerta");

    if (!campoInput) {

        alerta.classList.remove("show");
        return;

    }

    const atalhos = new Set();

    document
        .querySelectorAll(".categoria-body")
        .forEach(categoria => {

            categoria.innerHTML
                .split(/<br\s*\/?>/i)
                .forEach(item => {

                    const valor = item
                        .replace(/<[^>]*>/g, "")
                        .trim();

                    if (valor) {
                        atalhos.add(valor);
                    }

                });

        });

    const camposDigitados = campoInput
        .split(";")
        .map(item => item.trim())
        .filter(item => item !== "");

    const existeInvalido =
        camposDigitados.some(
            campo => !atalhos.has(campo)
        );

    alerta.classList.toggle(
        "show",
        existeInvalido
    );

}


/* ==============================================================
    VALIDAÇÃO DA RELAÇÃO 1:1
============================================================== */

function validateConnections() {

    const campo = document
        .getElementById("campo")
        .value
        .trim();

    const message = document
        .getElementById("message")
        .value
        .trim();

    const alerta =
        document.getElementById("conexaoAlerta");

    if (!campo && !message) {

        alerta.classList.remove("show");
        return;

    }

    let placeholders = [];

    try {

        placeholders =
            extractPlaceholders(message);

    } catch (error) {

        /*
            Um placeholder que não pode formar uma variável válida
            também representa uma conexão inconsistente.
        */

        alerta.classList.add("show");
        return;

    }

    const campos = campo
        .split(";")
        .map(item => item.trim());

    const camposValidos =
        campos.filter(item => item !== "");

    const possuiCampoVazio =
        campos.some(item => item === "");

    const quantidadeCampos =
        camposValidos.length;

    const quantidadeVariaveis =
        placeholders.length;

    const possuiInconsistencia =
        quantidadeCampos !== quantidadeVariaveis ||
        possuiCampoVazio;

    alerta.classList.toggle(
        "show",
        possuiInconsistencia
    );

}


/* ==============================================================
    GERAÇÃO DO AMPSCRIPT
============================================================== */

function generateAmpScript(
    deName,
    campo,
    message
) {

    const placeholders =
        extractPlaceholders(message);

    if (placeholders.length === 0) {

        throw new Error(
            "Nenhum placeholder encontrado na mensagem."
        );

    }

    /*
        Garante que duas entradas diferentes não resultem
        na mesma variável após a higienização.
    */

    validateSanitizedVariableNames(placeholders);

    const camposDE = campo
        .split(";")
        .map(item => item.trim());

    if (
        placeholders.length !==
        camposDE.length
    ) {

        throw new Error(
            `Quantidade incompatível. Encontrados ` +
            `${placeholders.length} placeholders para ` +
            `${camposDE.length} campos.`
        );

    }

    if (
        camposDE.some(item => item === "")
    ) {

        throw new Error(
            "Existem campos vazios na lista informada."
        );

    }

    let ampScript = "%%[";

    /*
        Os Lookups utilizam exclusivamente os nomes
        higienizados.
    */

    placeholders.forEach(
        (placeholder, index) => {

            const campoDE =
                camposDE[index];

            const variavelLimpa =
                placeholder.variavel;

            ampScript +=
                ` set @${variavelLimpa} = ` +
                `Lookup('${escapeAmpString(deName)}',` +
                `'${escapeAmpString(campoDE)}',` +
                `'Contact:ID',_subscriberkey)`;

        }
    );

    let textoMensagem = message;

    /*
        A substituição procura o placeholder original completo,
        mas a tag gerada utiliza a variável higienizada.
    */

    placeholders.forEach(
        (placeholder, index) => {

            const campoDE =
                camposDE[index];

            const variavelLimpa =
                placeholder.variavel;

            let tagAmpScript;

            if (
                campoDE ===
                "Contact:FirstName"
            ) {

                tagAmpScript =
                    `%%=Propercase(@${variavelLimpa})=%%`;

            } else {

                tagAmpScript =
                    `%%=v(@${variavelLimpa})=%%`;

            }

            /*
                replace() substitui uma ocorrência por vez.

                Isso preserva o vínculo sequencial entre cada
                placeholder encontrado e cada campo informado.
            */

            textoMensagem =
                textoMensagem.replace(
                    placeholder.completo,
                    tagAmpScript
                );

        }
    );

    /*
        Evita quebra da instrução AMPscript caso a mensagem
        possua aspas duplas.
    */

    textoMensagem =
        textoMensagem.replace(/"/g, '""');

    ampScript +=
        ` set @msg = "${textoMensagem}" `;

    ampScript +=
        "]%%%%=TreatAsContent(@msg)=%%";

    showToast(
        "Código AMPscript gerado",
        "success"
    );

    return ampScript;

}


/* ==============================================================
    PROTEÇÃO DE STRINGS DO AMPSCRIPT
============================================================== */

/**
 * Dentro de strings delimitadas por aspas simples,
 * o AMPscript representa uma aspa simples literal
 * utilizando duas aspas simples.
 */
function escapeAmpString(text) {

    return String(text)
        .replace(/'/g, "''");

}


/* ==============================================================
    LOG DA GERAÇÃO
============================================================== */

/**
 * Registra a última geração bem-sucedida.
 * Só é chamado depois que generateAmpScript() passou por
 * todas as validações, então os dados já são consistentes.
 */
function registrarLog(deName, campo, message) {

    const placeholders =
        extractPlaceholders(message);

    const camposDE = campo
        .split(";")
        .map(item => item.trim());

    ultimoLog = {
        dataHora: new Date().toLocaleString("pt-BR"),
        deName,
        camposUsados: [...new Set(camposDE)],
        conexoes: placeholders.map((placeholder, index) => ({
            placeholder: placeholder.completo,
            variavel: placeholder.variavel,
            campo: camposDE[index]
        }))
    };

    document
        .getElementById("logButton")
        .disabled = false;

}


function limparLog() {

    ultimoLog = null;

    document
        .getElementById("logButton")
        .disabled = true;

}


function initLogModal() {

    const modal = document.getElementById("logModal");

    modal
        .querySelectorAll("[data-close-log]")
        .forEach(elemento => {
            elemento.addEventListener("click", closeLogModal);
        });

    document
        .getElementById("copyLogButton")
        .addEventListener("click", copyLog);

    document.addEventListener("keydown", (event) => {

        if (event.key === "Escape" && !modal.hidden) {
            closeLogModal();
        }

    });

}


function openLogModal() {

    if (!ultimoLog) {

        showToast(
            "Gere um código primeiro para ver o log.",
            "warn"
        );

        return;

    }

    renderLog(ultimoLog);

    const modal = document.getElementById("logModal");

    modal.hidden = false;
    document.body.classList.add("modal-open");

    /* Próximo frame: permite a transição de entrada */
    requestAnimationFrame(() => {
        modal.classList.add("is-open");
        modal.querySelector(".log-foot .primary-btn").focus();
    });

}


function closeLogModal() {

    const modal = document.getElementById("logModal");

    modal.classList.remove("is-open");
    document.body.classList.remove("modal-open");

    setTimeout(() => {
        modal.hidden = true;
        document.getElementById("logButton").focus();
    }, 200);

}


/**
 * Monta o conteúdo do modal via DOM (textContent),
 * sem innerHTML, porque os valores vêm do usuário.
 */
function renderLog(log) {

    document.getElementById("logDataHora").textContent =
        `Gerado em ${log.dataHora}`;

    document.getElementById("logDeName").textContent =
        log.deName;

    /* Campos usados */

    const chips = document.getElementById("logCamposUsados");

    chips.replaceChildren(
        ...log.camposUsados.map(campo => {
            const chip = document.createElement("span");
            chip.className = "log-chip";
            chip.textContent = campo;
            return chip;
        })
    );

    document.getElementById("logCamposCount").textContent =
        log.camposUsados.length;

    /* Campos conectados */

    const lista = document.getElementById("logConexoes");

    lista.replaceChildren(
        ...log.conexoes.map((conexao, index) => {

            const row = document.createElement("div");
            row.className = "log-row";

            const indice = document.createElement("span");
            indice.className = "log-index";
            indice.textContent = String(index + 1).padStart(2, "0");

            const variavel = document.createElement("span");
            variavel.className = "log-var";
            variavel.textContent = `@${conexao.variavel}`;

            const original = document.createElement("small");
            original.className = "log-original";
            original.textContent = conexao.placeholder;
            variavel.appendChild(original);

            const seta = document.createElement("span");
            seta.className = "log-arrow";
            seta.textContent = "→";

            const campo = document.createElement("span");
            campo.className = "log-field";
            campo.textContent = conexao.campo;

            row.append(indice, variavel, seta, campo);

            return row;

        })
    );

    document.getElementById("logConexoesCount").textContent =
        log.conexoes.length;

}


async function copyLog() {

    if (!ultimoLog) {
        return;
    }

    const linhas = [
        `Log da geração — ${ultimoLog.dataHora}`,
        "",
        `Data Extension: ${ultimoLog.deName}`,
        "",
        `Campos usados (${ultimoLog.camposUsados.length}):`,
        ...ultimoLog.camposUsados.map(campo => `- ${campo}`),
        "",
        `Campos conectados (${ultimoLog.conexoes.length}):`,
        ...ultimoLog.conexoes.map(
            conexao =>
                `- ${conexao.placeholder} (@${conexao.variavel}) -> ${conexao.campo}`
        )
    ];

    try {

        await navigator.clipboard
            .writeText(linhas.join("\n"));

        showToast("Log copiado.", "success");

    } catch (error) {

        console.error(error);

        showToast(
            "Não foi possível copiar o log. Verifique se a página usa HTTPS.",
            "error"
        );

    }

}


/* ==============================================================
    CÓPIA DO CÓDIGO
============================================================== */

async function copyGeneratedCode(outputElement) {

    const code =
        outputElement.textContent;

    if (
        !code ||
        code.includes(
            "Seu código AMPscript"
        )
    ) {

        showToast(
            "Nenhum código foi gerado ainda.",
            "warn"
        );

        return;

    }

    if (code.startsWith("ERRO:")) {

        showToast(
            "Não é possível copiar enquanto houver erro na geração.",
            "error"
        );

        return;

    }

    try {

        await navigator.clipboard
            .writeText(code);

        showToast(
            "Código copiado com sucesso!",
            "success"
        );

    } catch (error) {

        console.error(error);

        showToast(
            "Não foi possível copiar o código. " +
            "Verifique se a página usa HTTPS.",
            "error"
        );

    }

}
