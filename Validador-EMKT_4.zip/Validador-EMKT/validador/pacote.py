"""
Orquestração da conferência de um pacote.

Recebe a pasta que o analista de marketing enviou, descobre sozinho onde está o
HTML, os dois docx e as imagens, e roda as três verificações.
"""

import os
from dataclasses import dataclass, field

from . import (comparador, docx_parser, html_parser, imagens as mod_imagens,
               presenca, regras)
from .ocr import CacheOCR, ocr_disponivel

NOMES_PASTA_IMAGENS = ("imagens", "images", "img", "imgs", "assets", "peças", "pecas")


@dataclass
class ResultadoPacote:
    pasta: str
    quebra: str = ""
    caminho_html: str = ""
    caminho_conteudo: str = ""
    caminho_assunto: str = ""
    pasta_imagens: str = ""
    leitura_html: object = None
    leitura_conteudo: object = None
    leitura_assunto: object = None
    resultado_imagens: object = None
    resultado_texto: object = None
    apontamentos_assunto: list = field(default_factory=list)
    bloqueios: list[str] = field(default_factory=list)   # impedem a publicação
    alertas: list[str] = field(default_factory=list)     # o analista precisa saber
    avisos: list[str] = field(default_factory=list)
    erros: list[str] = field(default_factory=list)
    ocr_ativo: bool = False
    motivo_ocr: str = ""
    modo_texto: str = "sequencia"   # "sequencia" (com OCR) | "presenca" (sem OCR)
    nome_pasta: str = ""            # como o pacote chegou: briefing+CPI+ação

    @property
    def status(self) -> str:
        if self.erros:
            return "erro"
        if self.bloqueios:
            return "reprovado"
        problemas_imagem = self.resultado_imagens and not self.resultado_imagens.aprovado
        status_texto = self.resultado_texto.status if self.resultado_texto else "erro"
        if problemas_imagem or status_texto == "reprovado":
            return "reprovado"
        if status_texto in ("atencao", "parcial") or self.apontamentos_assunto:
            return "atencao"
        return "aprovado"


def _localizar_html(pasta: str) -> list[str]:
    """
    Varre o pacote inteiro atrás do HTML da peça.

    O arquivo pode estar na raiz ou dentro de uma pasta "html" — depende da
    agência. Entre vários, ganha o que tem mais cara de peça: index primeiro,
    depois o maior, porque HTML de e-mail é pesado e um arquivo pequeno
    costuma ser um fragmento ou um teste.
    """
    encontrados = []
    for raiz, _, arquivos in os.walk(pasta):
        for arquivo in arquivos:
            if arquivo.startswith("~") or arquivo.startswith("."):
                continue
            if arquivo.lower().endswith((".html", ".htm")):
                encontrados.append(os.path.join(raiz, arquivo))
    encontrados.sort(
        key=lambda c: (
            0 if os.path.basename(c).lower().startswith("index") else 1,
            -os.path.getsize(c),
        )
    )
    return encontrados


EXTENSOES_IMAGEM = (".jpg", ".jpeg", ".png", ".gif", ".webp", ".bmp")


def _localizar_pasta_imagens(pasta: str, caminho_html: str,
                             referenciadas: list[str] | None = None) -> str:
    """
    Descobre onde estão as imagens do pacote.

    A estrutura muda conforme a agência que desenvolveu: às vezes o HTML fica
    solto na raiz com uma pasta "imagens" ao lado, às vezes vem uma pasta
    "html" com o arquivo dentro e a pasta de imagens dentro dela. Em vez de
    apostar num layout, a busca vai do critério mais confiável para o mais
    genérico.
    """
    candidatas: dict[str, list[str]] = {}
    for raiz, _, arquivos in os.walk(pasta):
        imagens = [a for a in arquivos if a.lower().endswith(EXTENSOES_IMAGEM)]
        if imagens:
            candidatas[raiz] = imagens
    if not candidatas:
        return os.path.dirname(caminho_html) if caminho_html else pasta

    # 1. a pasta que mais cobre os arquivos que o HTML realmente chama.
    #    É o critério mais forte: liga o que está no disco ao que está no código.
    if referenciadas:
        alvo = {n.lower() for n in referenciadas}
        melhor, melhor_cobertura = None, 0
        for caminho, arquivos in candidatas.items():
            cobertura = len({a.lower() for a in arquivos} & alvo)
            if cobertura > melhor_cobertura:
                melhor, melhor_cobertura = caminho, cobertura
        if melhor and melhor_cobertura:
            return melhor

    # 2. pasta com nome conhecido
    for caminho in candidatas:
        if os.path.basename(caminho).lower() in NOMES_PASTA_IMAGENS:
            return caminho

    # 3. a que tem mais imagens
    return max(candidatas.items(), key=lambda item: len(item[1]))[0]


def validar(pasta: str, quebra: str | None = None, usar_ocr: bool = True,
            idioma_ocr: str = "por", ao_avancar=None) -> ResultadoPacote:
    resultado = ResultadoPacote(pasta=pasta)
    resultado.nome_pasta = os.path.basename(os.path.normpath(pasta))

    if not os.path.isdir(pasta):
        resultado.erros.append(f"pasta não encontrada: {pasta}")
        return resultado

    # --- localizar arquivos ---
    htmls = _localizar_html(pasta)
    if not htmls:
        resultado.erros.append("nenhum arquivo .html encontrado no pacote")
        return resultado
    resultado.caminho_html = htmls[0]
    if len(htmls) > 1:
        outros = ", ".join(os.path.basename(h) for h in htmls[1:])
        resultado.avisos.append(
            f"mais de um HTML no pacote; usando '{os.path.basename(htmls[0])}'. Outros: {outros}"
        )

    documentos = docx_parser.localizar_docx(pasta)
    if not documentos:
        # lista o que existe: quase sempre o motivo é .doc antigo, arquivo
        # ainda dentro de um zip, ou o pacote apontado um nível acima
        outros = []
        for raiz, _, arquivos in os.walk(pasta):
            for arquivo in arquivos:
                if arquivo.lower().endswith((".doc", ".zip", ".rar", ".7z", ".pdf")):
                    outros.append(arquivo)
        pista = ""
        if outros:
            pista = (" Encontrei no pacote: " + ", ".join(sorted(set(outros))[:6])
                     + ". Arquivos .doc antigos precisam ser salvos como .docx, "
                     "e compactados precisam ser extraídos antes.")
        resultado.erros.append(
            "Nenhum arquivo .docx encontrado neste pacote." + pista
        )
        return resultado

    conteudo, assunto = docx_parser.identificar_papeis(documentos)
    resultado.leitura_conteudo = conteudo
    resultado.leitura_assunto = assunto
    resultado.caminho_conteudo = conteudo.caminho if conteudo else ""
    resultado.caminho_assunto = assunto.caminho if assunto else ""

    if not resultado.leitura_conteudo:
        nomes = ", ".join(os.path.basename(d) for d in documentos)
        resultado.erros.append(
            "Encontrei .docx no pacote, mas nenhum com corpo de texto para comparar "
            f"com o HTML. Arquivos vistos: {nomes}."
        )
        return resultado
    if not resultado.leitura_assunto:
        resultado.avisos.append(
            "Não identifiquei um docx de assunto/pré-header. As regras de "
            "publicação que dependem dele não foram conferidas."
        )

    # --- OCR ---
    cache = None
    if usar_ocr:
        disponivel, motivo = ocr_disponivel()
        resultado.ocr_ativo = disponivel
        resultado.motivo_ocr = motivo
        if disponivel:
            cache = CacheOCR(idioma=idioma_ocr)
            if cache.aviso_idioma:
                resultado.avisos.append(cache.aviso_idioma)
        else:
            resultado.avisos.append(
                f"OCR indisponível ({motivo}). O texto dentro das imagens não foi "
                "conferido; as demais verificações rodaram normalmente."
            )
    else:
        resultado.motivo_ocr = "desativado por parâmetro"

    # --- leitura do HTML e montagem da fita ---
    # Primeira passada sem OCR só para descobrir quais arquivos o código chama;
    # com essa lista dá para achar a pasta de imagens certa mesmo em estrutura
    # que não conhecemos.
    referencias = html_parser.ler_html(resultado.caminho_html, pasta).imagens_referenciadas
    resultado.pasta_imagens = _localizar_pasta_imagens(
        pasta, resultado.caminho_html, referencias
    )

    # Lê as imagens em paralelo ANTES de montar a fita. O percurso do DOM é
    # sequencial por natureza — precisa respeitar a ordem de leitura — mas a
    # leitura em si não: adiantar tudo aqui encurta a espera sem mudar o
    # resultado, porque o percurso depois só consulta o que já está pronto.
    if cache is not None:
        caminhos = []
        for nome in dict.fromkeys(referencias):
            achado = html_parser._localizar_arquivo(resultado.pasta_imagens, nome)
            if achado:
                caminhos.append(achado)
        cache.pre_carregar(caminhos, ao_avancar=ao_avancar)

    resultado.leitura_html = html_parser.ler_html(
        resultado.caminho_html, resultado.pasta_imagens, cache_ocr=cache
    )
    resultado.erros.extend(resultado.leitura_html.erros)
    if resultado.erros:
        return resultado

    remotas = getattr(resultado.leitura_html, "imagens_remotas", [])
    if remotas:
        resultado.avisos.append(
            f"{len(remotas)} imagem(ns) chamada(s) por URL, não pelo pacote — "
            "é o caso da peça já hospedada. Elas não entram na conferência de "
            "pasta nem têm o texto lido: " + ", ".join(remotas[:5])
        )

    # --- verificação 1: imagens ---
    resultado.resultado_imagens = mod_imagens.verificar(
        resultado.pasta_imagens,
        resultado.leitura_html.imagens_referenciadas,
        quebra=quebra,
    )
    resultado.quebra = resultado.resultado_imagens.quebra

    # --- verificação 2 e 3: texto ---
    # Com OCR, a fita está completa e vale comparar sequência. Sem OCR, o texto
    # das imagens falta na fita mas sobra no docx: comparar sequência aí inventa
    # divergência. Nesse caso só perguntamos se o texto vivo consta no docx.
    imagens_sem_leitura = any(
        b.tipo == "imagem" and not b.ocr_lido and not b.oculto
        for b in resultado.leitura_html.fita
    )
    resultado.modo_texto = "presenca" if imagens_sem_leitura else "sequencia"
    if imagens_sem_leitura:
        resultado.resultado_texto = presenca.comparar(
            resultado.leitura_html.fita, resultado.leitura_conteudo.paragrafos
        )
    else:
        resultado.resultado_texto = comparador.comparar(
            resultado.leitura_html.fita, resultado.leitura_conteudo.paragrafos
        )

    # --- verificação 4: pré-header ---
    if resultado.leitura_assunto:
        resultado.apontamentos_assunto = comparador.comparar_assunto(
            resultado.leitura_assunto, resultado.leitura_html
        )

    # --- verificação 5: regras de publicação ---
    _aplicar_regras(resultado)

    return resultado


def _conferir_disclaimer(resultado: ResultadoPacote) -> None:
    """
    Endereço no disclaimer precisa vir com o código que impede o link.

    O cliente de e-mail transforma sozinho qualquer coisa com cara de endereço
    em link clicável. No disclaimer isso não pode acontecer, então a peça
    separa os caracteres com um invisível (&#xFEFF;) no ponto onde o cliente
    procuraria o padrão de domínio. Sem esse código, o link é gerado.
    """
    if not resultado.leitura_html:
        return

    for bloco in resultado.leitura_html.fita:
        if not bloco.classificacao.startswith("obrigatorio:disclaimer"):
            continue

        # Link com texto de frase — "Saiba mais", "Cancele aqui", "Fale
        # Conosco" — é intencional e existe em quase todo disclaimer. O que a
        # regra proíbe é o ENDEREÇO virar link: é isso que precisa da proteção.
        for texto_do_link in bloco.textos_de_link:
            if regras.enderecos_sem_protecao(texto_do_link):
                resultado.bloqueios.append(
                    "Endereço dentro de um link clicável no disclaimer: "
                    f"\u201c{texto_do_link.strip()[:90]}\u201d"
                )

        desprotegidos = regras.enderecos_sem_protecao(bloco.bruto)
        for endereco in desprotegidos:
            resultado.bloqueios.append(
                f"Endereço sem o código que impede o hyperlink no disclaimer: "
                f"\u201c{endereco}\u201d. Separe os caracteres com &#xFEFF; "
                "como nas demais peças."
            )


def _conferir_datas(resultado: ResultadoPacote) -> None:
    """
    Aponta datas já passadas na peça.

    Peça reaproveitada de mês anterior costuma trazer a data antiga junto, e o
    disclaimer é onde isso mais escapa. Fica como aviso: às vezes a data
    passada é proposital — início de vigência, data de contrato — e quem
    decide isso é o analista.
    """
    if not resultado.leitura_html:
        return

    achadas: dict[str, str] = {}
    for bloco in resultado.leitura_html.fita:
        for data in regras.datas_vencidas(bloco.conteudo):
            if data in achadas:
                continue
            onde = bloco.referencia if bloco.tipo == "imagem" else "texto do HTML"
            achadas[data] = onde

    if resultado.leitura_conteudo:
        for paragrafo in resultado.leitura_conteudo.paragrafos:
            for data in regras.datas_vencidas(paragrafo):
                achadas.setdefault(data, "CONTEUDO.docx")

    for data, onde in list(achadas.items())[:6]:
        resultado.alertas.append(f"Data vencida: {data} (em {onde}) — verificar.")


def _aplicar_regras(resultado: ResultadoPacote) -> None:
    """
    Regras do banco, separadas do restante da conferência.

    O que impede a publicação vira bloqueio e reprova o pacote. O que só merece
    atenção vira alerta e não muda o veredito — assunto longo não é erro, é
    informação para o analista decidir.
    """
    # Redirect: sem nenhum no código, a peça não sobe.
    if resultado.leitura_html and resultado.leitura_html.redirects == 0:
        resultado.bloqueios.append(
            "Nenhum redirect encontrado no HTML. A publicação exige pelo menos um."
        )

    _conferir_disclaimer(resultado)
    _conferir_datas(resultado)

    leitura = resultado.leitura_assunto
    if not leitura:
        return

    # Pré-header sem ponto final não passa na publicação.
    if leitura.pre_header:
        if not regras.pre_header_tem_ponto_final(leitura.pre_header):
            resultado.bloqueios.append(
                "O pré-header não termina em ponto final: "
                f"\u201c{leitura.pre_header}\u201d"
            )
        excedente = regras.excedeu(leitura.pre_header, regras.LIMITE_PRE_HEADER)
        if excedente:
            resultado.alertas.append(
                f"Pré-header com {len(leitura.pre_header.strip())} caracteres, "
                f"{excedente} acima dos {regras.LIMITE_PRE_HEADER} de referência."
            )

    if leitura.assunto:
        excedente = regras.excedeu(leitura.assunto, regras.LIMITE_ASSUNTO)
        if excedente:
            resultado.alertas.append(
                f"Assunto com {len(leitura.assunto.strip())} caracteres, "
                f"{excedente} acima dos {regras.LIMITE_ASSUNTO} de referência."
            )


def _tem_direto(pasta: str, extensoes: tuple) -> bool:
    """Arquivo com essa extensão solto na própria pasta, sem descer níveis."""
    try:
        return any(
            item.lower().endswith(extensoes)
            and not item.startswith(("~", "."))
            and os.path.isfile(os.path.join(pasta, item))
            for item in os.listdir(pasta)
        )
    except OSError:
        return False


def _tem_em_algum_lugar(pasta: str, extensoes: tuple) -> bool:
    for _, _, arquivos in os.walk(pasta):
        if any(a.lower().endswith(extensoes) and not a.startswith(("~", "."))
               for a in arquivos):
            return True
    return False


def _e_pacote(pasta: str) -> bool:
    """
    Um pacote tem HTML e docx dentro dele, em qualquer nível.

    Exigir os dois é o que separa o pacote de verdade de uma subpasta "html".
    A pasta html tem o arquivo da peça, mas os docx ficam um nível acima — se
    o critério fosse só "tem HTML", ela seria confundida com um pacote e a
    conferência rodaria sem o texto para comparar.
    """
    return (_tem_em_algum_lugar(pasta, (".html", ".htm"))
            and _tem_em_algum_lugar(pasta, (".docx",)))


def localizar_pacotes(raiz: str) -> list[str]:
    """
    Descobre se o que foi arrastado é UM pacote ou uma caixa com vários.

    Não dá para exigir que a pessoa escolha o modo certo antes de arrastar: ela
    tem a pasta na mão, não a estrutura na cabeça. E a estrutura varia com a
    agência que desenvolveu — o HTML tanto vem solto na raiz quanto dentro de
    uma pasta "html", com as imagens ao lado dele.
    """
    if not os.path.isdir(raiz):
        return []

    # Arquivo de pacote solto na raiz significa que a raiz é o próprio pacote:
    # os docx ficam ali e o HTML pode estar numa subpasta.
    if _tem_direto(raiz, (".html", ".htm", ".docx")):
        return [raiz]

    filhos = []
    try:
        itens = sorted(os.listdir(raiz))
    except OSError:
        return []
    for item in itens:
        caminho = os.path.join(raiz, item)
        if os.path.isdir(caminho) and _e_pacote(caminho):
            filhos.append(caminho)

    if filhos:
        return filhos
    if _e_pacote(raiz) or _tem_em_algum_lugar(raiz, (".html", ".htm")):
        return [raiz]
    return []


def validar_lote(pasta_raiz: str, **kwargs) -> list[ResultadoPacote]:
    """Confere cada pacote encontrado dentro da pasta."""
    return [validar(caminho, **kwargs) for caminho in localizar_pacotes(pasta_raiz)]
