"""
Leitura dos .docx do pacote.

Dois papéis diferentes:
  CONTEUDO.docx  -> todo o texto legível da peça, na ordem de leitura
  ASSUNTO.docx   -> assunto e pré-header

A identificação é por nome de arquivo, com heurística por conteúdo quando o
analista nomeia fora do padrão.
"""

import os
import re
from difflib import SequenceMatcher
from dataclasses import dataclass, field

from .normalizacao import limpar, sem_acento

RE_ASSUNTO = re.compile(r"assunto|subject|pre.?header|preheader", re.IGNORECASE)
RE_CONTEUDO = re.compile(r"conte.?do|content|texto|alt", re.IGNORECASE)


@dataclass
class LeituraDocx:
    caminho: str
    papel: str = "indefinido"       # "conteudo" | "assunto" | "indefinido"
    paragrafos: list[str] = field(default_factory=list)
    assunto: str = ""
    pre_header: str = ""
    erros: list[str] = field(default_factory=list)

    def texto_completo(self) -> str:
        return "\n".join(self.paragrafos)


DIGITOS_SOBRESCRITOS = {
    "0": "\u2070", "1": "\u00b9", "2": "\u00b2", "3": "\u00b3", "4": "\u2074",
    "5": "\u2075", "6": "\u2076", "7": "\u2077", "8": "\u2078", "9": "\u2079",
}


def _texto_com_sobrescrito(paragrafo) -> str:
    """
    Monta o texto do parágrafo preservando a chamada de nota como sobrescrito.

    O Word guarda o "1" de "18x¹" como formatação, não como caractere: lido
    direto, ele vira um "1" comum e a peça aparece como "18x1" na comparação
    lado a lado, exatamente onde a pessoa quer conferir se a nota está certa.
    Converter para o caractere sobrescrito devolve a leitura fiel — e não afeta
    a comparação, que normaliza ¹ para 1 dos dois lados.
    """
    partes = []
    for run in paragrafo.runs:
        texto = run.text
        if texto and run.font.superscript and texto.strip().isdigit():
            texto = "".join(DIGITOS_SOBRESCRITOS.get(c, c) for c in texto)
        partes.append(texto)
    montado = "".join(partes)
    # runs vazios em parágrafo com campo automático: cai para o texto simples
    return montado if montado.strip() else paragrafo.text


def _extrair_paragrafos(caminho: str) -> tuple[list[str], list[str]]:
    """Lê parágrafos e também o texto dentro de tabelas, que o Word esconde do iterador padrão."""
    from docx import Document

    erros = []
    try:
        documento = Document(caminho)
    except Exception as e:
        return [], [f"não foi possível abrir: {e}"]

    linhas = []
    for paragrafo in documento.paragraphs:
        texto_do_paragrafo = _texto_com_sobrescrito(paragrafo)
        # Quebra de linha manual (Shift+Enter) fica DENTRO do parágrafo e volta
        # como \n. Sem dividir aqui, "Assunto: X" e "Pré-header: Y" escritos no
        # mesmo bloco viram uma linha só, e o assunto engole o pré-header
        # inteiro. Isso acontece muito quando o pessoal formata em negrito.
        for pedaco in texto_do_paragrafo.split("\n"):
            texto = limpar(pedaco)
            if texto:
                linhas.append(texto)

    for tabela in documento.tables:
        for linha in tabela.rows:
            for celula in linha.cells:
                texto = limpar(celula.text)
                if texto and texto not in linhas[-3:]:
                    linhas.append(texto)

    return linhas, erros


def ler_docx(caminho: str, papel: str | None = None) -> LeituraDocx:
    """Lê o arquivo. O papel, quando não informado, é decidido em identificar_papeis()."""
    leitura = LeituraDocx(caminho=caminho)
    leitura.paragrafos, leitura.erros = _extrair_paragrafos(caminho)
    if papel:
        leitura.papel = papel
        if papel == "assunto":
            leitura.assunto, leitura.pre_header = _separar_assunto(leitura.paragrafos)
    return leitura


def _pontuar_como_assunto(leitura: LeituraDocx) -> int:
    """
    O quanto este arquivo se parece com o docx de assunto e pré-header.

    O nome do arquivo não serve de critério: em pacote real ele costuma ser a
    quebra, o CPI ou a ação, e não "ASSUNTO" ou "CONTEUDO". O que distingue os
    dois é o conteúdo — o de assunto é curto e traz os rótulos; o de conteúdo é
    a peça inteira transcrita.
    """
    corpo = " ".join(leitura.paragrafos).lower()
    palavras = len(corpo.split())
    pontos = 0

    if RE_ASSUNTO.search(os.path.basename(leitura.caminho)):
        pontos += 3
    if re.search(r"\bassunto\b", corpo):
        pontos += 4
    if re.search(r"pr[eé].?header|preheader", corpo):
        pontos += 4
    if palavras <= 40:
        pontos += 3
    elif palavras <= 80:
        pontos += 1
    if len(leitura.paragrafos) <= 6:
        pontos += 2
    if palavras > 150:
        pontos -= 5
    return pontos


def identificar_papeis(caminhos: list[str]) -> tuple[LeituraDocx | None, LeituraDocx | None]:
    """
    Decide qual docx é o de conteúdo e qual é o de assunto.

    Devolve (conteudo, assunto). Regra, na ordem:
      - lê todos e pontua cada um pela cara de "assunto"
      - o melhor pontuado vira assunto, desde que passe do limiar
      - entre os restantes, o de maior corpo vira o conteúdo
      - com um arquivo só, ele é conteúdo, a menos que seja claramente assunto
    """
    leituras = [ler_docx(caminho) for caminho in caminhos]
    leituras = [l for l in leituras if l.paragrafos or not l.erros]
    if not leituras:
        return None, None

    pontuados = sorted(
        ((_pontuar_como_assunto(l), -len(" ".join(l.paragrafos)), l) for l in leituras),
        key=lambda t: (-t[0], t[1]),
    )

    assunto = None
    melhor_pontos, _, melhor = pontuados[0]
    # limiar 6: exige pelo menos dois sinais fortes (um rótulo + ser curto),
    # para não promover a assunto um conteúdo que por acaso é pequeno
    if melhor_pontos >= 6:
        assunto = melhor
        assunto.papel = "assunto"
        assunto.assunto, assunto.pre_header = _separar_assunto(assunto.paragrafos)

    candidatos = [l for l in leituras if l is not assunto]
    conteudo = None
    if candidatos:
        conteudo = max(candidatos, key=lambda l: len(" ".join(l.paragrafos)))
        conteudo.papel = "conteudo"
    elif assunto is not None and len(leituras) == 1:
        # arquivo único com cara de assunto: sem material para comparar o texto
        conteudo = None

    return conteudo, assunto


# Rótulos de referência, já sem acento e sem separador. A comparação é por
# similaridade, não por igualdade: em pacote real aparece "Pré-header",
# "Pre header", "Preheader", "Prehead" e uma boa variedade de digitação
# apressada, e nenhuma delas deveria quebrar a leitura.
ROTULOS_DE_REFERENCIA = {
    "assunto": ["assunto", "subject", "titulo"],
    "pre_header": ["preheader", "previewtext", "preview", "prechamada"],
}

SIMILARIDADE_MINIMA = 0.72


def _achatar_rotulo(texto: str) -> str:
    """Deixa só as letras minúsculas sem acento, para comparar grafias."""
    return re.sub(r"[^a-z]", "", sem_acento(texto.lower()))


def _classificar_rotulo(candidato: str) -> str | None:
    achatado = _achatar_rotulo(candidato)
    if len(achatado) < 4:
        return None
    melhor_papel, melhor_nota = None, 0.0
    for papel, referencias in ROTULOS_DE_REFERENCIA.items():
        for referencia in referencias:
            nota = SequenceMatcher(None, achatado, referencia).ratio()
            if nota > melhor_nota:
                melhor_papel, melhor_nota = papel, nota
    return melhor_papel if melhor_nota >= SIMILARIDADE_MINIMA else None


def _identificar_rotulo(linha: str) -> tuple[str | None, str]:
    """
    Devolve (papel, valor) de uma linha do docx de assunto.

    A ordem das tentativas importa. Os dois-pontos vêm primeiro porque o hífen
    também faz parte do próprio rótulo — cortar "Pré-header: X" no hífen daria
    "Pré" como candidato, que é curto demais para reconhecer.
    """
    linha = linha.strip()
    if not linha:
        return None, ""

    # a linha inteira é o rótulo; o valor vem na linha de baixo
    papel = _classificar_rotulo(linha)
    if papel and len(linha.split()) <= 3:
        return papel, ""

    for separador in (r":", r"[-–—]"):
        achado = re.match(rf"^([^\n]{{2,28}}?)\s*{separador}\s*(.+)$", linha)
        if achado:
            papel = _classificar_rotulo(achado.group(1))
            if papel:
                return papel, achado.group(2).strip()

    # sem separador nenhum: "Assunto Seu crédito está liberado"
    palavras = linha.split()
    for quantidade in (2, 1):
        if len(palavras) > quantidade:
            candidato = " ".join(palavras[:quantidade])
            # o candidato não pode ser bem maior que o rótulo que representa,
            # senão "Pré-header: Simule" casaria e comeria a primeira palavra
            if len(_achatar_rotulo(candidato)) <= 14:
                papel = _classificar_rotulo(candidato)
                if papel:
                    return papel, " ".join(palavras[quantidade:]).strip()
    return None, linha


def _separar_assunto(paragrafos: list[str]) -> tuple[str, str]:
    """Separa assunto e pré-header, aceitando tanto 'Assunto: x' quanto linhas soltas."""
    assunto, pre_header = "", ""
    pendente = None

    for linha in paragrafos:
        papel, valor = _identificar_rotulo(linha)
        if papel:
            if valor:
                # rótulo e valor na mesma linha
                if papel == "assunto" and not assunto:
                    assunto = valor
                elif papel == "pre_header" and not pre_header:
                    pre_header = valor
                pendente = None
            else:
                # rótulo sozinho: o valor vem na linha de baixo
                pendente = papel
            continue
        if pendente == "assunto" and not assunto:
            assunto, pendente = linha, None
        elif pendente == "pre_header" and not pre_header:
            pre_header, pendente = linha, None

    # Sem rótulo nenhum, vale a ordem em que costumam ser escritos.
    restantes = [l for l in paragrafos if not _identificar_rotulo(l)[0]]
    if not assunto and restantes:
        assunto = restantes[0]
    if not pre_header and len(restantes) > 1:
        pre_header = restantes[1]
    return assunto, pre_header


def localizar_docx(pasta: str) -> list[str]:
    encontrados = []
    for raiz, _, arquivos in os.walk(pasta):
        for arquivo in arquivos:
            if arquivo.lower().endswith(".docx") and not arquivo.startswith("~$"):
                encontrados.append(os.path.join(raiz, arquivo))
    return sorted(encontrados)
