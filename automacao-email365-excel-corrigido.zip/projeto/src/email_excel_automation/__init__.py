"""
Pacote email_excel_automation
==============================
Sistema modular para ler e-mails de uma caixa corporativa, extrair
dados tabulares e preenchê-los automaticamente em uma planilha Excel.

Módulos:
    exceptions      -> Exceções customizadas usadas em todo o sistema
    logger_setup    -> Configuração de logging seguro (com máscara de dados)
    config_loader   -> Carregamento e validação de config.yaml e .env
    auth            -> Token OAuth2 (App-Only ou delegado) via MSAL
    graph_client    -> Wrapper HTTP do Microsoft Graph API
    email_client    -> Busca e leitura de e-mails via Graph API
    email_parser    -> Extração de tabelas do corpo do e-mail (HTML/texto)
    validators      -> Validação das linhas extraídas antes de gravar
    excel_writer    -> Escrita dos dados na planilha (local ou Graph)
    state_store     -> Registro de e-mails já processados (idempotência)
    main            -> Orquestra o fluxo completo (ponto de entrada)
"""

__version__ = "1.1.0"
