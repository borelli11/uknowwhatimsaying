"""
excel_writer.py
=================
Grava as linhas validadas na planilha Excel de destino.

Dois backends, escolhidos por config.yaml -> excel.backend:

1. LocalExcelWriter ("local")
   Usa openpyxl diretamente sobre um caminho de arquivo. Funciona para:
   - arquivo em disco local
   - pasta de rede mapeada / caminho UNC (\\\\servidor\\pasta\\arquivo.xlsx)
   - pasta do OneDrive/SharePoint sincronizada localmente pelo cliente
     de sincronização (aparece como uma pasta normal no Windows)

2. GraphExcelWriter ("graph")
   Edita o arquivo diretamente no SharePoint ou OneDrive "na nuvem",
   via Microsoft Graph Excel API, sem baixar o arquivo inteiro. Usa uma
   Tabela do Excel (Inserir > Tabela) como destino, através do endpoint
   de "rows/add" - isso evita ter que calcular manualmente qual é a
   próxima linha livre e é seguro para gravações concorrentes.

Ambos implementam a mesma interface (ExcelWriterBase), então o restante
do sistema (main.py) não precisa saber qual backend está em uso.
"""

import logging
from abc import ABC, abstractmethod
from pathlib import Path
from typing import Dict, List
from urllib.parse import quote

from openpyxl import Workbook, load_workbook

from .exceptions import ExcelWriteError
from .graph_client import GraphClient


class ExcelWriterBase(ABC):
    """Interface comum aos backends de escrita de planilha."""

    @abstractmethod
    def append_rows(self, rows: List[Dict[str, str]]) -> int:
        """Grava as linhas na planilha e retorna a quantidade gravada."""
        raise NotImplementedError


class LocalExcelWriter(ExcelWriterBase):
    """Escreve em um arquivo .xlsx local, de rede ou sincronizado."""

    def __init__(
        self,
        output_path: str,
        sheet_name: str,
        expected_columns: List[str],
        start_row: int = 2,
        create_if_missing: bool = True,
        logger: logging.Logger | None = None,
    ) -> None:
        self._path = Path(output_path)
        self._sheet_name = sheet_name
        self._expected_columns = expected_columns
        self._start_row = start_row
        self._create_if_missing = create_if_missing
        self._logger = logger or logging.getLogger("email_excel_automation")

    def _load_or_create_workbook(self) -> Workbook:
        if self._path.is_file():
            try:
                return load_workbook(self._path)
            except Exception as exc:
                raise ExcelWriteError(f"Não foi possível abrir a planilha existente: {exc}") from exc

        if not self._create_if_missing:
            raise ExcelWriteError(
                f"Planilha não encontrada em '{self._path}' e create_if_missing=false."
            )

        self._path.parent.mkdir(parents=True, exist_ok=True)
        workbook = Workbook()
        default_sheet = workbook.active
        default_sheet.title = self._sheet_name
        default_sheet.append(self._expected_columns)  # cabeçalho
        self._logger.info("Nova planilha criada em '%s'.", self._path)
        return workbook

    def append_rows(self, rows: List[Dict[str, str]]) -> int:
        workbook = self._load_or_create_workbook()

        if self._sheet_name not in workbook.sheetnames:
            sheet = workbook.create_sheet(self._sheet_name)
            sheet.append(self._expected_columns)
        else:
            sheet = workbook[self._sheet_name]

        # Encontra a próxima linha livre a partir de start_row, olhando a coluna A
        next_row = max(sheet.max_row + 1, self._start_row)

        for offset, row in enumerate(rows):
            values = [row[col] for col in self._expected_columns]
            for col_index, value in enumerate(values, start=1):
                sheet.cell(row=next_row + offset, column=col_index, value=value)

        try:
            workbook.save(self._path)
        except PermissionError as exc:
            raise ExcelWriteError(
                f"Não foi possível salvar '{self._path}': o arquivo pode estar "
                "aberto em outro programa (ex: Excel). Feche-o e tente novamente."
            ) from exc
        except OSError as exc:
            raise ExcelWriteError(f"Erro de I/O ao salvar a planilha: {exc}") from exc

        self._logger.info("%d linha(s) gravada(s) em '%s'.", len(rows), self._path)
        return len(rows)


class GraphExcelWriter(ExcelWriterBase):
    """Escreve em uma Tabela do Excel hospedada no SharePoint/OneDrive,
    via Microsoft Graph Excel API (sem baixar o arquivo).
    """

    def __init__(
        self,
        graph_client: GraphClient,
        drive_id: str,
        item_path: str,
        table_name: str,
        expected_columns: List[str],
        logger: logging.Logger | None = None,
    ) -> None:
        self._graph = graph_client
        self._drive_id = drive_id
        self._item_path = item_path
        self._table_name = table_name
        self._expected_columns = expected_columns
        self._logger = logger or logging.getLogger("email_excel_automation")

    def _table_rows_url(self) -> str:
        item_segment = quote(self._item_path)
        return (
            f"/drives/{self._drive_id}/root:{item_segment}:"
            f"/workbook/tables/{self._table_name}/rows/add"
        )

    def append_rows(self, rows: List[Dict[str, str]]) -> int:
        if not rows:
            return 0

        # A API espera uma lista de listas de valores, na ordem das colunas
        values = [[row[col] for col in self._expected_columns] for row in rows]

        try:
            self._graph.post(self._table_rows_url(), {"values": values})
        except Exception as exc:
            raise ExcelWriteError(
                f"Falha ao gravar linhas na tabela '{self._table_name}' via Graph API: {exc}"
            ) from exc

        self._logger.info(
            "%d linha(s) gravada(s) via Graph API na tabela '%s'.",
            len(rows), self._table_name,
        )
        return len(rows)


def build_excel_writer(settings, graph_client: GraphClient | None, logger: logging.Logger) -> ExcelWriterBase:
    """Fábrica: constrói o writer correto com base em excel.backend."""
    excel_cfg = settings.excel

    if excel_cfg.backend == "local":
        return LocalExcelWriter(
            output_path=excel_cfg.output_path,
            sheet_name=excel_cfg.sheet_name,
            expected_columns=excel_cfg.expected_columns,
            start_row=excel_cfg.start_row,
            create_if_missing=excel_cfg.create_if_missing,
            logger=logger,
        )

    if excel_cfg.backend == "graph":
        if graph_client is None:
            raise ExcelWriteError("Backend 'graph' requer um GraphClient autenticado.")
        return GraphExcelWriter(
            graph_client=graph_client,
            drive_id=excel_cfg.graph_drive_id,
            item_path=excel_cfg.graph_item_path,
            table_name=excel_cfg.graph_table_name,
            expected_columns=excel_cfg.expected_columns,
            logger=logger,
        )

    raise ExcelWriteError(f"excel.backend inválido: '{excel_cfg.backend}'. Use 'local' ou 'graph'.")
