"""
exceptions.py
==============
Define exceções específicas do sistema. Usar exceções customizadas
(em vez de Exception genérica) facilita o tratamento de erros de forma
precisa em cada camada do sistema, e deixa os logs mais claros.
"""


class AutomationError(Exception):
    """Classe base para todas as exceções deste sistema."""


class ConfigError(AutomationError):
    """Erro ao carregar ou validar configurações (config.yaml ou .env)."""


class AuthError(AutomationError):
    """Erro ao autenticar no Microsoft Entra ID (Azure AD).

    IMPORTANTE: mensagens desta exceção nunca devem conter o client
    secret, a senha do certificado ou o token de acesso.
    """


class GraphApiError(AutomationError):
    """Erro em uma chamada à Microsoft Graph API (Outlook/Excel/SharePoint)."""


class EmailSearchError(AutomationError):
    """Erro ao buscar ou ler e-mails na caixa de entrada."""


class ParsingError(AutomationError):
    """Erro ao extrair a tabela de dados do corpo do e-mail."""


class ValidationError(AutomationError):
    """Erro quando os dados extraídos não passam nas regras de validação."""


class ExcelWriteError(AutomationError):
    """Erro ao abrir, criar ou gravar na planilha Excel."""
