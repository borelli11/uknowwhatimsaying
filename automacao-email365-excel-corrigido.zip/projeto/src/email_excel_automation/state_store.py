"""
state_store.py
================
Controle de idempotência: registra quais e-mails já foram gravados na
planilha, para que a mesma linha não entre duas vezes.

Por que isso é necessário
-------------------------
A busca usa uma janela de dias (email.search_since_days). Um job agendado
diariamente com janela de 7 dias reencontra o mesmo e-mail em 7 execuções
seguidas - sem este controle, a planilha recebe a mesma linha 7 vezes.

O que é (e o que NÃO é) gravado
-------------------------------
Gravamos apenas o hash SHA-256 do id da mensagem no Graph, mais a data de
processamento. Nunca o assunto, o corpo, endereços ou as linhas extraídas.
O arquivo de estado, portanto, não contém dado de negócio nem dado pessoal:
mesmo que vaze, não revela conteúdo de e-mail nem permite reconstruí-lo.

Registros mais antigos que `retention_days` são descartados a cada
execução, para o arquivo não crescer indefinidamente.
"""

import hashlib
import json
import logging
import os
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Dict


class ProcessedMessageStore:
    """Conjunto persistente de e-mails já processados com sucesso."""

    def __init__(
        self,
        path: str,
        retention_days: int = 30,
        logger: logging.Logger | None = None,
    ) -> None:
        self._path = Path(path)
        self._retention_days = retention_days
        self._logger = logger or logging.getLogger("email_excel_automation")
        self._entries: Dict[str, str] = self._load()
        self._alterado = False

    # ------------------------------------------------------------------

    @staticmethod
    def _key(message_id: str) -> str:
        return hashlib.sha256(message_id.encode("utf-8")).hexdigest()

    def _load(self) -> Dict[str, str]:
        if not self._path.is_file():
            return {}
        try:
            data = json.loads(self._path.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError) as exc:
            self._logger.warning(
                "Arquivo de estado '%s' ilegível (%s); será recriado. "
                "ATENÇÃO: e-mails já processados podem ser gravados novamente nesta execução.",
                self._path, type(exc).__name__,
            )
            return {}

        if not isinstance(data, dict):
            self._logger.warning("Arquivo de estado '%s' em formato inesperado; será recriado.", self._path)
            return {}

        return {k: v for k, v in data.items() if isinstance(k, str) and isinstance(v, str)}

    # ------------------------------------------------------------------

    def ja_processado(self, message_id: str) -> bool:
        return self._key(message_id) in self._entries

    def marcar_processado(self, message_id: str) -> None:
        self._entries[self._key(message_id)] = datetime.now(timezone.utc).isoformat()
        self._alterado = True

    def _remover_antigos(self) -> int:
        limite = datetime.now(timezone.utc) - timedelta(days=self._retention_days)
        antigos = []
        for chave, quando in self._entries.items():
            try:
                if datetime.fromisoformat(quando) < limite:
                    antigos.append(chave)
            except ValueError:
                antigos.append(chave)  # timestamp inválido: descarta

        for chave in antigos:
            del self._entries[chave]

        return len(antigos)

    def salvar(self) -> None:
        """Grava o estado em disco (escrita atômica, para não corromper
        o arquivo se a execução for interrompida no meio)."""
        removidos = self._remover_antigos()
        if not self._alterado and not removidos:
            return

        self._path.parent.mkdir(parents=True, exist_ok=True)
        temporario = self._path.with_suffix(self._path.suffix + ".tmp")

        try:
            temporario.write_text(
                json.dumps(self._entries, indent=2), encoding="utf-8"
            )
            os.replace(temporario, self._path)
        except OSError as exc:
            self._logger.error(
                "Não foi possível gravar o arquivo de estado '%s': %s. "
                "A próxima execução pode reprocessar e-mails já gravados.",
                self._path, exc,
            )
            return

        if removidos:
            self._logger.debug("%d registro(s) antigo(s) removido(s) do estado.", removidos)
