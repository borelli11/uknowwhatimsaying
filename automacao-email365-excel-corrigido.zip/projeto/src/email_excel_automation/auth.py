"""
auth.py
========
Responsável por obter o token de acesso (OAuth2) para o Microsoft Graph
API. Suporta dois modos, escolhidos via config.yaml -> auth.mode:

1. "app_only" (client credentials via MSAL ConfidentialClientApplication)
   - Não depende de usuário logado; ideal para job automático em servidor.
   - Requer Application Permissions + admin consent no Entra ID, e
     idealmente uma Application Access Policy no Exchange restringindo
     a mailbox acessível (ver README).
   - Autentica por certificado (recomendado) ou client secret.

2. "delegated" (interactive login via MSAL PublicClientApplication)
   - Abre o navegador para você logar com a própria conta corporativa.
   - Ideal para testes locais/prototipagem: normalmente não exige
     aprovação de administrador (Delegated Permissions com user
     consent), e acessa sempre a MESMA mailbox de quem logou (/me).

Princípio de menor privilégio
-----------------------------
Os escopos delegados são montados dinamicamente a partir da configuração
(ver build_delegated_scopes), e não como uma lista fixa: o sistema só
pede `Mail.ReadWrite` se realmente for marcar e-mails como lidos, e só
pede permissão de arquivo se o backend do Excel for "graph". Assim o
consentimento apresentado ao usuário/administrador reflete exatamente o
que a execução vai fazer.

Cache de token (modo delegado)
------------------------------
O cache contém um refresh token - tão sensível quanto uma senha. Quando
`msal-extensions` está instalado, o cache é gravado com a proteção nativa
do sistema operacional (DPAPI no Windows, Keychain no macOS, libsecret no
Linux). Sem essa biblioteca, cai para um arquivo em texto puro e o
sistema AVISA explicitamente no log - não fingimos proteção que não
existe.

Em ambos os casos, o token de acesso NUNCA é logado nem incluído em
mensagens de exceção.
"""

import logging
import os
import stat
from pathlib import Path

import msal

from .config_loader import Settings
from .exceptions import AuthError

APP_ONLY_SCOPE = ["https://graph.microsoft.com/.default"]

# O MSAL adiciona openid/profile/offline_access automaticamente e REJEITA
# (ValueError) se forem passados pelo chamador. Guardamos a lista para
# validar o que vem de auth.extra_delegated_scopes no config.yaml.
MSAL_RESERVED_SCOPES = frozenset({"openid", "profile", "offline_access"})

AUTHORITY_TEMPLATE = "https://login.microsoftonline.com/{tenant_id}"

# Cache do token delegado fica fora do repositório do projeto, na pasta
# do usuário do SO - nunca deve ser commitado nem compartilhado.
TOKEN_CACHE_DIR = Path.home() / ".email_excel_automation"
TOKEN_CACHE_FILE = TOKEN_CACHE_DIR / "delegated_token_cache.bin"


def build_delegated_scopes(settings: Settings) -> list[str]:
    """Monta a lista mínima de escopos delegados para esta execução.

    - Leitura de e-mail: `Mail.Read`, ou `Mail.ReadWrite` apenas se
      email.mark_as_read = true (marcar como lido é um PATCH).
    - Escrita de planilha: nada, se excel.backend = "local" (o arquivo é
      acessado pelo sistema de arquivos, não pelo Graph). Só pede
      permissão de arquivo quando backend = "graph".
    - auth.extra_delegated_scopes permite acrescentar escopos quando o
      destino exige (ex: SharePoint costuma pedir Sites.ReadWrite.All
      em vez de Files.ReadWrite.All).
    """
    scopes: list[str] = ["Mail.ReadWrite" if settings.email.mark_as_read else "Mail.Read"]

    if settings.excel.backend == "graph":
        scopes.append("Files.ReadWrite.All")

    scopes.extend(settings.auth.extra_delegated_scopes)

    reservados = {s for s in scopes if s.lower() in MSAL_RESERVED_SCOPES}
    if reservados:
        raise AuthError(
            f"Escopo(s) reservado(s) pelo MSAL não podem ser solicitados: "
            f"{sorted(reservados)}. O MSAL já os adiciona automaticamente; "
            "remova-os de auth.extra_delegated_scopes no config.yaml."
        )

    # Remove duplicatas preservando a ordem (útil para log e diagnóstico)
    vistos: set[str] = set()
    return [s for s in scopes if not (s in vistos or vistos.add(s))]


class AppOnlyAuthenticator:
    """Autenticação App-Only (client credentials) - sem usuário logado."""

    def __init__(self, settings: Settings, logger: logging.Logger | None = None) -> None:
        self._auth_cfg = settings.auth
        self._logger = logger or logging.getLogger("email_excel_automation")
        self._app = self._build_confidential_client()

    def _build_confidential_client(self) -> msal.ConfidentialClientApplication:
        authority = AUTHORITY_TEMPLATE.format(tenant_id=self._auth_cfg.tenant_id)

        if self._auth_cfg.auth_method == "certificate":
            credential = self._build_certificate_credential()
        elif self._auth_cfg.auth_method == "client_secret":
            credential = self._build_secret_credential()
        else:
            raise AuthError(
                f"auth_method inválido: '{self._auth_cfg.auth_method}'. "
                "Use 'certificate' ou 'client_secret'."
            )

        return msal.ConfidentialClientApplication(
            client_id=self._auth_cfg.client_id,
            authority=authority,
            client_credential=credential,
        )

    def _build_certificate_credential(self) -> dict:
        cert_path = self._auth_cfg.certificate_path
        if not cert_path or not os.path.isfile(cert_path):
            raise AuthError(
                f"Certificado não encontrado em '{cert_path}'. Verifique "
                "config.yaml (auth.certificate_path)."
            )

        thumbprint = os.getenv(self._auth_cfg.certificate_thumbprint_env or "", "")
        if not thumbprint:
            raise AuthError(
                "Thumbprint do certificado não definido. Configure a variável "
                f"'{self._auth_cfg.certificate_thumbprint_env}' no .env ou no "
                "ambiente de execução."
            )

        # A chave privada é esperada em PEM (texto). Um .pfx é binário e
        # falharia aqui com UnicodeDecodeError - erro claro é melhor que
        # stack trace obscuro.
        try:
            with open(cert_path, "r", encoding="utf-8") as f:
                private_key = f.read()
        except UnicodeDecodeError as exc:
            raise AuthError(
                f"'{cert_path}' não parece ser um arquivo PEM de texto. "
                "Converta o .pfx para .pem (openssl pkcs12 -in cert.pfx "
                "-out cert.pem -nodes) ou aponte auth.certificate_path "
                "para o .pem correspondente."
            ) from exc

        cert_password = os.getenv("AZURE_CERT_PASSWORD") or None

        credential = {"private_key": private_key, "thumbprint": thumbprint}
        if cert_password:
            credential["passphrase"] = cert_password
        return credential

    def _build_secret_credential(self) -> str:
        secret_env_name = self._auth_cfg.client_secret_env or "AZURE_CLIENT_SECRET"
        secret = os.getenv(secret_env_name)
        if not secret:
            raise AuthError(
                f"Client secret não definido. Configure a variável "
                f"'{secret_env_name}' no .env ou no ambiente de execução."
            )
        return secret

    def get_access_token(self) -> str:
        result = self._app.acquire_token_silent(APP_ONLY_SCOPE, account=None)
        if not result:
            result = self._app.acquire_token_for_client(scopes=APP_ONLY_SCOPE)

        if "access_token" not in result:
            error_desc = result.get("error_description", "erro desconhecido")
            self._logger.error("Falha ao obter token de acesso (App-Only).")
            raise AuthError(f"Falha na autenticação App-Only: {error_desc}")

        return result["access_token"]


class DelegatedAuthenticator:
    """Autenticação delegada (login interativo pelo navegador)."""

    def __init__(self, settings: Settings, logger: logging.Logger | None = None) -> None:
        self._auth_cfg = settings.auth
        self._logger = logger or logging.getLogger("email_excel_automation")
        self._scopes = build_delegated_scopes(settings)
        self._logger.info("Escopos delegados solicitados: %s", ", ".join(self._scopes))

        # True quando caímos no cache em texto puro e precisamos gravá-lo
        # manualmente a cada execução.
        self._cache_manual = False
        self._cache = self._build_token_cache()

        self._app = msal.PublicClientApplication(
            client_id=self._auth_cfg.client_id,
            authority=AUTHORITY_TEMPLATE.format(tenant_id=self._auth_cfg.tenant_id),
            token_cache=self._cache,
        )

    # ------------------------------------------------------------------
    # Cache de token
    # ------------------------------------------------------------------

    def _build_token_cache(self):
        """Cache protegido pelo SO quando possível; texto puro com aviso caso contrário."""
        TOKEN_CACHE_DIR.mkdir(parents=True, exist_ok=True)

        try:
            from msal_extensions import PersistedTokenCache, build_encrypted_persistence
        except ImportError:
            self._logger.warning(
                "Biblioteca 'msal-extensions' não instalada: o cache do refresh token "
                "será gravado em TEXTO PURO em '%s'. Instale-a (pip install msal-extensions) "
                "para usar a proteção nativa do SO (DPAPI/Keychain/libsecret).",
                TOKEN_CACHE_FILE,
            )
            return self._build_plaintext_cache()

        try:
            persistence = build_encrypted_persistence(str(TOKEN_CACHE_FILE))
        except Exception as exc:  # sem DPAPI/Keychain/libsecret disponível
            self._logger.warning(
                "Proteção nativa do SO indisponível para o cache de token (%s). "
                "O refresh token será gravado em TEXTO PURO em '%s'.",
                type(exc).__name__, TOKEN_CACHE_FILE,
            )
            return self._build_plaintext_cache()

        self._logger.debug("Cache de token protegido pelo sistema operacional.")
        return PersistedTokenCache(persistence)

    def _build_plaintext_cache(self) -> msal.SerializableTokenCache:
        self._cache_manual = True
        cache = msal.SerializableTokenCache()
        if TOKEN_CACHE_FILE.is_file():
            try:
                cache.deserialize(TOKEN_CACHE_FILE.read_text(encoding="utf-8"))
            except Exception:
                self._logger.warning(
                    "Cache de token local corrompido/ilegível; será recriado no próximo login."
                )
        return cache

    def _persist_token_cache(self) -> None:
        """Grava o cache em texto puro (só usado no modo de fallback)."""
        if not self._cache_manual or not self._cache.has_state_changed:
            return

        TOKEN_CACHE_FILE.write_text(self._cache.serialize(), encoding="utf-8")

        # Restringe leitura/escrita ao dono do arquivo. ATENÇÃO: no Windows
        # isto NÃO aplica ACL - mexe apenas no atributo somente-leitura e
        # não protege o arquivo de outros usuários da máquina. Por isso o
        # caminho recomendado no Windows é ter msal-extensions instalado
        # (DPAPI), e não este fallback.
        try:
            os.chmod(TOKEN_CACHE_FILE, stat.S_IRUSR | stat.S_IWUSR)
        except OSError:
            pass

    # ------------------------------------------------------------------

    def get_access_token(self) -> str:
        accounts = self._app.get_accounts()
        result = None
        if accounts:
            result = self._app.acquire_token_silent(self._scopes, account=accounts[0])

        if not result:
            self._logger.info("Nenhum token em cache válido. Abrindo navegador para login...")
            result = self._app.acquire_token_interactive(scopes=self._scopes)

        self._persist_token_cache()

        if not result or "access_token" not in result:
            error_desc = (result or {}).get("error_description", "erro desconhecido")
            self._logger.error("Falha ao obter token de acesso (delegado).")
            raise AuthError(f"Falha na autenticação delegada: {error_desc}")

        return result["access_token"]


def build_authenticator(settings: Settings, logger: logging.Logger | None = None):
    """Fábrica: retorna o autenticador correto conforme auth.mode."""
    if settings.auth.mode == "app_only":
        return AppOnlyAuthenticator(settings, logger=logger)
    if settings.auth.mode == "delegated":
        return DelegatedAuthenticator(settings, logger=logger)
    raise AuthError(f"auth.mode inválido: '{settings.auth.mode}'. Use 'app_only' ou 'delegated'.")
