"""
validators.py
===============
Valida as linhas extraídas do e-mail antes de gravá-las na planilha.

Regras aplicadas:
- Todas as colunas esperadas (config.yaml -> excel.expected_columns)
  precisam existir e não estar vazias.
- Colunas extras no e-mail (fora da lista esperada) são ignoradas -
  isso torna o sistema tolerante a pequenas mudanças de layout.
- Linhas inválidas são descartadas e registradas em log (sem incluir
  o conteúdo completo da linha em nível INFO/WARNING para evitar
  logar dados de negócio sensíveis; o detalhe fica em DEBUG).
"""

import logging
from typing import Dict, List

from .exceptions import ValidationError


def validate_rows(
    rows: List[Dict[str, str]],
    expected_columns: List[str],
    logger: logging.Logger | None = None,
) -> List[Dict[str, str]]:
    """Filtra e normaliza as linhas extraídas do e-mail.

    Args:
        rows: linhas brutas extraídas pelo email_parser.
        expected_columns: colunas obrigatórias, na ordem de escrita.
        logger: logger a ser usado (opcional).

    Returns:
        Lista de linhas válidas, cada uma contendo exatamente as
        expected_columns, com valores já sem espaços nas pontas.

    Raises:
        ValidationError: se nenhuma linha restar válida após a filtragem.
    """
    logger = logger or logging.getLogger("email_excel_automation")
    validated: List[Dict[str, str]] = []
    descartadas = 0

    for index, row in enumerate(rows):
        missing = [col for col in expected_columns if not (row.get(col) or "").strip()]
        if missing:
            descartadas += 1
            logger.warning("Linha %d ignorada: coluna(s) ausente(s)/vazia(s): %s", index, missing)
            logger.debug("Conteúdo da linha descartada (linha %d): %s", index, row)
            continue

        validated.append({col: row[col].strip() for col in expected_columns})

    if descartadas:
        logger.info("%d linha(s) descartada(s) por falha de validação.", descartadas)

    if not validated:
        raise ValidationError(
            "Nenhuma linha válida encontrada após a validação. Verifique se o "
            "layout do e-mail corresponde às colunas esperadas em config.yaml."
        )

    logger.info("%d linha(s) válida(s) prontas para gravação.", len(validated))
    return validated
