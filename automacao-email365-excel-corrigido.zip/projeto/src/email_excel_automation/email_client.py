"""
email_client.py
=================
Cliente para ler e-mails do Outlook (Exchange Online) via Microsoft
Graph API.

O "segmento" da mailbox no Graph muda conforme o modo de autenticação:
- delegado -> "/me/..."      (sempre a mailbox de quem logou)
- app_only -> "/users/{upn}/..." (mailbox explícita, sem usuário logado)

Esse detalhe é resolvido uma única vez em main.py (mailbox_segment) e
passado pronto para esta classe, que não precisa saber qual modo de
autenticação está em uso.
"""

import logging
from datetime import datetime, timedelta, timezone
from typing import List

from .exceptions import EmailSearchError
from .graph_client import GraphClient


class EmailMessage:
    """Representação simplificada de um e-mail retornado pelo Graph."""

    def __init__(self, raw: dict) -> None:
        self.id: str = raw["id"]
        self.subject: str = raw.get("subject", "")
        body = raw.get("body", {})
        self.body_content_type: str = body.get("contentType", "text")  # "html" ou "text"
        self.body_content: str = body.get("content", "")


class EmailClient:
    """Cliente de leitura de e-mails via Graph API."""

    def __init__(
        self,
        graph_client: GraphClient,
        mailbox_segment: str,
        folder: str = "Inbox",
        logger: logging.Logger | None = None,
    ) -> None:
        """
        Args:
            mailbox_segment: prefixo de rota do Graph já resolvido,
                ex: "me" ou "users/usuario%40empresa.com.br".
        """
        self._graph = graph_client
        self._mailbox_segment = mailbox_segment
        self._folder = folder
        self._logger = logger or logging.getLogger("email_excel_automation")

    def _base_url(self) -> str:
        return f"/{self._mailbox_segment}/mailFolders/{self._folder}/messages"

    @staticmethod
    def _build_subject_query(subject: str) -> str:
        """Monta o valor de $search em KQL para um assunto.

        Em KQL, uma restrição de propriedade só amarra a PRIMEIRA palavra:
        `subject:Relatório Diário de Vendas` procura "Relatório" no assunto
        e "Diário de Vendas" livremente em from/subject/body - o que faria
        o robô ler e-mails que não são dele. Para amarrar a frase inteira
        ao assunto, ela precisa vir entre aspas internas escapadas:

            "subject:\\"Relatório Diário de Vendas\\""

        Aspas duplas presentes no assunto configurado são removidas, para
        que não seja possível quebrar a query a partir do config.yaml.
        """
        sanitized = subject.replace('"', " ").strip()
        return f'"subject:\\"{sanitized}\\""'

    def search_by_subject(self, subject: str, since_days: int = 7) -> List[EmailMessage]:
        """Busca e-mails cujo assunto contenha o texto informado, nos
        últimos `since_days` dias, dentro da pasta configurada.

        Nota: $search não pode ser combinado com $filter no Graph, por isso
        o recorte por data é feito aqui, sobre o resultado. O Graph devolve
        os resultados de $search ordenados por data de envio (mais recentes
        primeiro), então o $top abaixo pega a janela mais recente.
        """
        params = {
            "$search": self._build_subject_query(subject),
            "$select": "id,subject,body,receivedDateTime",
            "$top": "50",
        }

        try:
            data = self._graph.get(self._base_url(), params=params)
        except Exception as exc:
            raise EmailSearchError(f"Erro ao buscar e-mails com assunto '{subject}'.") from exc

        raw_messages = data.get("value", [])
        cutoff = datetime.now(timezone.utc) - timedelta(days=since_days)

        filtered = []
        for raw in raw_messages:
            received = raw.get("receivedDateTime")
            if received:
                received_dt = datetime.fromisoformat(received.replace("Z", "+00:00"))
                if received_dt < cutoff:
                    continue
            filtered.append(EmailMessage(raw))

        self._logger.info(
            "Assunto '%s': %d e-mail(s) encontrado(s) nos últimos %d dia(s).",
            subject, len(filtered), since_days,
        )
        return filtered

    def mark_as_read(self, message: EmailMessage) -> None:
        """Marca um e-mail como lido."""
        url = f"/{self._mailbox_segment}/messages/{message.id}"
        self._graph.patch(url, {"isRead": True})
