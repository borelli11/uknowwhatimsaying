"""
email_parser.py
=================
Extrai dados tabulares do corpo de um e-mail.

Usa o padrão "Strategy": cada formato de corpo (HTML ou texto simples)
tem sua própria classe de parser, e uma fábrica escolhe a estratégia
correta com base no content-type retornado pelo Graph API. Para dar
suporte a um novo formato no futuro (ex: CSV anexado, e-mail em outro
layout), basta criar uma nova classe e registrá-la na fábrica -
nenhum outro módulo precisa ser alterado.
"""

import csv
import io
import logging
from abc import ABC, abstractmethod
from typing import Dict, List, Sequence

from bs4 import BeautifulSoup

from .exceptions import ParsingError


class BaseTableParser(ABC):
    """Interface comum a todos os parsers de tabela."""

    def __init__(self, expected_columns: Sequence[str] | None = None) -> None:
        self._expected_columns = list(expected_columns or [])

    @abstractmethod
    def parse(self, content: str) -> List[Dict[str, str]]:
        """Recebe o corpo do e-mail (string) e retorna uma lista de linhas,
        cada linha representada como um dicionário {nome_da_coluna: valor}.
        """
        raise NotImplementedError


class HtmlTableParser(BaseTableParser):
    """Extrai a tabela de dados de um corpo de e-mail em HTML.

    E-mails do Outlook quase sempre trazem tabelas de LAYOUT envolvendo o
    conteúdo (assinatura, cabeçalho corporativo, moldura). Pegar
    simplesmente a primeira `<table>` do documento costuma pegar a moldura
    e descartar o e-mail inteiro. Por isso, quando as colunas esperadas são
    conhecidas, escolhemos a tabela cujo cabeçalho mais se aproxima delas;
    só caímos na primeira tabela utilizável quando não há como comparar.

    Esperado: a primeira linha da tabela escolhida é o cabeçalho.
    """

    def parse(self, content: str) -> List[Dict[str, str]]:
        soup = BeautifulSoup(content, "lxml")
        tables = soup.find_all("table")
        if not tables:
            raise ParsingError("Nenhuma tabela HTML encontrada no corpo do e-mail.")

        melhor_tabela = None
        melhor_pontuacao = -1

        for table in tables:
            rows = table.find_all("tr")
            if len(rows) < 2:
                continue  # sem cabeçalho + ao menos uma linha de dados

            headers = self._cell_texts(rows[0])
            pontuacao = self._pontuar_cabecalho(headers)
            if pontuacao > melhor_pontuacao:
                melhor_pontuacao, melhor_tabela = pontuacao, table

        if melhor_tabela is None:
            raise ParsingError("Tabela encontrada não possui cabeçalho e/ou linhas de dados.")

        if self._expected_columns and melhor_pontuacao == 0:
            raise ParsingError(
                "Nenhuma tabela do e-mail tem cabeçalho compatível com as colunas "
                "esperadas em config.yaml (excel.expected_columns)."
            )

        return self._linhas_da_tabela(melhor_tabela)

    def _pontuar_cabecalho(self, headers: List[str]) -> int:
        """Quantas colunas esperadas aparecem neste cabeçalho."""
        if not self._expected_columns:
            return 0
        presentes = {h.strip().casefold() for h in headers}
        return sum(1 for col in self._expected_columns if col.strip().casefold() in presentes)

    @staticmethod
    def _cell_texts(row) -> List[str]:
        return [cell.get_text(strip=True) for cell in row.find_all(["th", "td"])]

    def _linhas_da_tabela(self, table) -> List[Dict[str, str]]:
        rows = table.find_all("tr")
        headers = self._cell_texts(rows[0])

        data_rows: List[Dict[str, str]] = []
        for tr in rows[1:]:
            cells = self._cell_texts(tr)
            if not cells or all(c == "" for c in cells):
                continue  # ignora linhas em branco
            data_rows.append(dict(zip(headers, cells)))

        return data_rows


class PlainTextTableParser(BaseTableParser):
    """Extrai dados tabulares de um e-mail em texto simples, delimitado
    por vírgula ou ponto-e-vírgula, com cabeçalho na primeira linha não
    vazia (formato comum em relatórios gerados automaticamente por
    outros sistemas que enviam e-mail em texto puro).
    """

    def __init__(
        self,
        expected_columns: Sequence[str] | None = None,
        delimiter: str = ";",
    ) -> None:
        super().__init__(expected_columns)
        self._delimiter = delimiter

    def parse(self, content: str) -> List[Dict[str, str]]:
        lines = [line for line in content.splitlines() if line.strip()]
        if len(lines) < 2:
            raise ParsingError("Corpo do e-mail em texto não contém dados tabulares suficientes.")

        # Detecta automaticamente ; ou , como delimitador, olhando o cabeçalho
        delimiter = self._delimiter if self._delimiter in lines[0] else ","

        reader = csv.DictReader(io.StringIO("\n".join(lines)), delimiter=delimiter)
        data_rows = [row for row in reader if any((v or "").strip() for v in row.values())]

        if not data_rows:
            raise ParsingError("Nenhuma linha de dados válida encontrada no texto do e-mail.")

        return data_rows


class ParserFactory:
    """Escolhe o parser correto com base no content-type do corpo do e-mail."""

    @staticmethod
    def get_parser(
        content_type: str, expected_columns: Sequence[str] | None = None
    ) -> BaseTableParser:
        normalized = (content_type or "").lower()
        if "html" in normalized:
            return HtmlTableParser(expected_columns)
        return PlainTextTableParser(expected_columns)


def extract_table_from_email(
    content: str,
    content_type: str,
    expected_columns: Sequence[str] | None = None,
    logger: logging.Logger | None = None,
) -> List[Dict[str, str]]:
    """Função de conveniência: extrai a tabela do corpo do e-mail usando
    o parser adequado ao content-type informado pelo Graph API.

    `expected_columns` é opcional, mas recomendado: é o que permite
    distinguir a tabela de dados das tabelas de layout do Outlook.
    """
    logger = logger or logging.getLogger("email_excel_automation")
    parser = ParserFactory.get_parser(content_type, expected_columns)
    rows = parser.parse(content)
    logger.info("Extração concluída: %d linha(s) encontrada(s) no corpo do e-mail.", len(rows))
    return rows
