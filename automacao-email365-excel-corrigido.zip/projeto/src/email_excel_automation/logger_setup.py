"""
logger_setup.py
=================
Configura o logging do sistema.

Boas práticas de segurança aplicadas aqui:
1. Os logs vão para arquivo (rotacionado, para não crescer sem limite)
   e também para o console, para acompanhar em tempo real.
2. Um filtro (SensitiveDataFilter) mascara automaticamente padrões que
   se pareçam com e-mails, senhas ou tokens em QUALQUER mensagem de log,
   como uma camada extra de proteção - mesmo que, por engano, algum
   código tente logar algo sensível, o filtro reduz o vazamento.
   Isso é "defesa em profundidade": a regra principal continua sendo
   "nunca logar credenciais", este filtro é apenas uma rede de segurança.
"""

import logging
import re
from logging.handlers import RotatingFileHandler
from pathlib import Path


class SensitiveDataFilter(logging.Filter):
    """Filtro que mascara padrões sensíveis antes de gravar o log."""

    # Padrões simples e eficazes para o caso comum:
    # - e-mails (usuario@dominio.com)
    # - trechos do tipo password=..., senha=..., token=...
    _EMAIL_PATTERN = re.compile(r"[\w\.\-+]+@[\w\-]+\.[\w\.\-]+")
    _SECRET_PATTERN = re.compile(
        r"(senha|password|pwd|token|secret)\s*[:=]\s*\S+", re.IGNORECASE
    )

    def filter(self, record: logging.LogRecord) -> bool:
        try:
            message = record.getMessage()
        except Exception:
            # Se não for possível montar a mensagem, deixa passar sem alterar
            return True

        masked = self._EMAIL_PATTERN.sub("[EMAIL_OCULTO]", message)
        masked = self._SECRET_PATTERN.sub(r"\1=[OCULTO]", masked)

        # Sobrescreve a mensagem já mascarada e limpa os args originais
        # para evitar que a formatação reintroduza dados sensíveis.
        record.msg = masked
        record.args = ()
        return True


def setup_logging(
    level: str = "INFO",
    log_dir: str = "./logs",
    max_bytes: int = 5_242_880,
    backup_count: int = 5,
) -> logging.Logger:
    """Configura e retorna o logger principal do sistema.

    Args:
        level: Nível mínimo de log (DEBUG, INFO, WARNING, ERROR).
        log_dir: Pasta onde os arquivos de log serão gravados.
        max_bytes: Tamanho máximo de cada arquivo antes de rotacionar.
        backup_count: Quantidade de arquivos antigos mantidos.

    Returns:
        Logger configurado, pronto para uso em todo o sistema.
    """
    Path(log_dir).mkdir(parents=True, exist_ok=True)

    logger = logging.getLogger("email_excel_automation")
    logger.setLevel(getattr(logging, level.upper(), logging.INFO))

    # Evita duplicar handlers se setup_logging for chamado mais de uma vez
    if logger.handlers:
        return logger

    formatter = logging.Formatter(
        fmt="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )

    sensitive_filter = SensitiveDataFilter()

    # Handler de arquivo, com rotação automática
    file_handler = RotatingFileHandler(
        filename=str(Path(log_dir) / "automation.log"),
        maxBytes=max_bytes,
        backupCount=backup_count,
        encoding="utf-8",
    )
    file_handler.setFormatter(formatter)
    file_handler.addFilter(sensitive_filter)

    # Handler de console, útil durante execução manual/depuração
    console_handler = logging.StreamHandler()
    console_handler.setFormatter(formatter)
    console_handler.addFilter(sensitive_filter)

    logger.addHandler(file_handler)
    logger.addHandler(console_handler)

    return logger
