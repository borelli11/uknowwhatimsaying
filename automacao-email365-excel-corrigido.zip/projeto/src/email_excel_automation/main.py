"""
main.py
========
Ponto de entrada do sistema. Orquestra o fluxo completo:

    1. Carrega o .env para o ambiente e a configuração (config.yaml),
       e prepara o logging seguro.
    2. Autentica no Microsoft Entra ID e cria o cliente Graph.
    3. Para cada assunto configurado, busca e-mails na mailbox alvo.
    4. Pula e-mails já processados em execuções anteriores (idempotência).
    5. Extrai a tabela de dados do corpo de cada e-mail.
    6. Valida as linhas extraídas.
    7. Grava as linhas válidas na planilha (local ou SharePoint/OneDrive).
    8. Registra o e-mail como processado e, opcionalmente, marca como lido.

Uso:
    python -m email_excel_automation.main [--config CAMINHO] [--dry-run]
"""

import argparse
import sys
from urllib.parse import quote

from dotenv import load_dotenv

from .auth import build_authenticator
from .config_loader import Settings, load_settings
from .email_client import EmailClient
from .email_parser import extract_table_from_email
from .excel_writer import build_excel_writer
from .exceptions import AutomationError
from .graph_client import GraphClient
from .logger_setup import setup_logging
from .state_store import ProcessedMessageStore
from .validators import validate_rows


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Automação E-mail (M365) -> Excel")
    parser.add_argument(
        "--config", default="config/config.yaml", help="Caminho do arquivo config.yaml"
    )
    parser.add_argument(
        "--dry-run", action="store_true",
        help="Executa todo o processamento sem gravar na planilha (sobrescreve app.dry_run)",
    )
    return parser.parse_args()


def run(settings: Settings, logger) -> int:
    """Executa o fluxo completo. Retorna a quantidade total de linhas gravadas."""
    authenticator = build_authenticator(settings, logger=logger)
    graph_client = GraphClient(authenticator, logger=logger)

    # Resolve o segmento de rota do Graph conforme o modo de autenticação:
    # "delegated" -> sempre a própria mailbox (/me); "app_only" -> mailbox
    # explícita (/users/{upn}), pois não há usuário logado nesse modo.
    if settings.auth.mode == "delegated":
        mailbox_segment = "me"
    else:
        mailbox_segment = f"users/{quote(settings.email.user_upn)}"

    email_client = EmailClient(
        graph_client=graph_client,
        mailbox_segment=mailbox_segment,
        folder=settings.email.folder,
        logger=logger,
    )

    excel_writer = build_excel_writer(
        settings,
        graph_client=graph_client if settings.excel.backend == "graph" else None,
        logger=logger,
    )

    processados = ProcessedMessageStore(
        path=settings.app.state_path,
        retention_days=settings.app.state_retention_days,
        logger=logger,
    )

    total_gravado = 0

    try:
        for subject in settings.email.subject_filters:
            logger.info("Processando assunto: '%s'", subject)

            # A busca também fica dentro de um try: falhar em um assunto
            # não deve impedir o processamento dos demais.
            try:
                messages = email_client.search_by_subject(
                    subject, settings.email.search_since_days
                )
            except AutomationError as exc:
                logger.error("Falha ao buscar e-mails do assunto '%s': %s", subject, exc)
                continue

            for message in messages:
                if processados.ja_processado(message.id):
                    logger.debug(
                        "E-mail '%s' já processado em execução anterior; ignorado.",
                        message.subject,
                    )
                    continue

                try:
                    rows = extract_table_from_email(
                        content=message.body_content,
                        content_type=message.body_content_type,
                        expected_columns=settings.excel.expected_columns,
                        logger=logger,
                    )
                    valid_rows = validate_rows(
                        rows, settings.excel.expected_columns, logger=logger
                    )

                    if settings.app.dry_run:
                        # Em dry-run nada é gravado e nada é marcado como
                        # processado - a execução seguinte reprocessa igual.
                        logger.info(
                            "[DRY-RUN] %d linha(s) seriam gravadas para o e-mail '%s'.",
                            len(valid_rows), message.subject,
                        )
                        continue

                    excel_writer.append_rows(valid_rows)
                    total_gravado += len(valid_rows)

                    # Só marca como processado DEPOIS da gravação bem-sucedida:
                    # se a escrita falhar, o e-mail é tentado de novo na
                    # próxima execução em vez de ser perdido silenciosamente.
                    processados.marcar_processado(message.id)

                    if settings.email.mark_as_read:
                        email_client.mark_as_read(message)

                except AutomationError as exc:
                    # Erro em UM e-mail não deve interromper o processamento
                    # dos demais; registramos e seguimos em frente.
                    logger.error(
                        "Falha ao processar e-mail '%s': %s", message.subject, exc
                    )
                    continue
    finally:
        # Grava o estado mesmo se algo inesperado interromper o fluxo,
        # para não reprocessar o que já foi gravado na planilha.
        processados.salvar()

    return total_gravado


def main() -> int:
    args = parse_args()

    # Carrega o .env para o ambiente do processo. override=False é
    # deliberado: variável já presente no ambiente (injetada por um cofre
    # de segredos, por exemplo) tem precedência sobre o arquivo em disco.
    load_dotenv(override=False)

    try:
        settings = load_settings(args.config)
    except AutomationError as exc:
        # Ainda não temos logger configurado neste ponto (depende do config)
        print(f"[ERRO DE CONFIGURAÇÃO] {exc}", file=sys.stderr)
        return 1

    if args.dry_run:
        settings.app.dry_run = True

    logger = setup_logging(
        level=settings.logging.level,
        log_dir=settings.logging.log_dir,
        max_bytes=settings.logging.max_bytes,
        backup_count=settings.logging.backup_count,
    )

    logger.info(
        "Iniciando execução (modo=%s, dry_run=%s, excel.backend=%s)",
        settings.auth.mode, settings.app.dry_run, settings.excel.backend,
    )

    try:
        total = run(settings, logger)
        logger.info("Execução concluída. Total de linhas gravadas: %d", total)
        return 0
    except AutomationError as exc:
        logger.error("Execução interrompida por erro: %s", exc)
        return 1
    except Exception:
        # Qualquer exceção não prevista também é logada (com stack trace
        # completo no arquivo de log, útil para diagnóstico), mas nunca
        # expõe credenciais, pois estas nunca chegam a variáveis locais
        # deste módulo.
        logger.exception("Erro inesperado durante a execução.")
        return 1


if __name__ == "__main__":
    sys.exit(main())
