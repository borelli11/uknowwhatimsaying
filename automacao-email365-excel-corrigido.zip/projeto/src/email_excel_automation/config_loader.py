"""
config_loader.py
==================
Carrega e valida:
1. Configurações não sensíveis do config.yaml (Azure AD IDs, mailbox,
   assuntos, destino da planilha, etc).
2. Nada de segredo é lido aqui - client secret / senha de certificado
   são lidos sob demanda pelo módulo auth.py, diretamente das variáveis
   de ambiente, nunca armazenados em um objeto de configuração genérico.
   O .env é carregado para o ambiente do processo em main.py, sem
   sobrescrever variáveis já injetadas (cofre de segredos vence arquivo).

Usamos Pydantic para validar tipos e obrigatoriedade automaticamente.
"""

from pathlib import Path
from typing import List, Literal

import yaml
from pydantic import BaseModel, Field, field_validator

from .exceptions import ConfigError


# ----------------------------------------------------------------------
# Autenticação (Azure AD / Microsoft Entra ID) - apenas identificadores,
# nenhum segredo é armazenado nestes modelos.
# ----------------------------------------------------------------------

class AuthConfig(BaseModel):
    # "app_only": client credentials, sem usuário logado (para servidor).
    # "delegated": login interativo pelo navegador, com a própria conta
    #              (ideal para testes locais, sem precisar de admin consent).
    mode: Literal["app_only", "delegated"] = "app_only"

    tenant_id: str  # pode ser o GUID do tenant, ou "common"/"organizations"
    client_id: str
    auth_method: Literal["certificate", "client_secret"] = "certificate"

    # Usados apenas quando mode = "app_only"
    certificate_path: str | None = None
    certificate_thumbprint_env: str = "AZURE_CERT_THUMBPRINT"
    client_secret_env: str = "AZURE_CLIENT_SECRET"

    # Escopos delegados adicionais, quando o destino exigir (ex: planilha
    # no SharePoint costuma pedir Sites.ReadWrite.All em vez de
    # Files.ReadWrite.All). Os escopos básicos são deduzidos da própria
    # configuração em auth.build_delegated_scopes - não peça aqui o que a
    # execução não vai usar.
    extra_delegated_scopes: List[str] = Field(default_factory=list)


class EmailFilterConfig(BaseModel):
    # Obrigatório apenas quando auth.mode = "app_only" (validado em Settings
    # abaixo). No modo "delegated", a mailbox é sempre a de quem loga (/me).
    user_upn: str | None = None
    folder: str = "Inbox"
    subject_filters: List[str] = Field(min_length=1)
    search_since_days: int = 7
    mark_as_read: bool = False

    @field_validator("subject_filters")
    @classmethod
    def _sem_assuntos_vazios(cls, v: List[str]) -> List[str]:
        if any(not s.strip() for s in v):
            raise ValueError("subject_filters não pode conter itens vazios")
        return v


class ExcelConfig(BaseModel):
    backend: Literal["local", "graph"] = "local"

    # Backend "local"
    output_path: str = "./output/relatorio.xlsx"
    sheet_name: str = "Dados"
    start_row: int = 2
    create_if_missing: bool = True

    # Backend "graph"
    graph_drive_id: str = ""
    graph_item_path: str = ""
    graph_table_name: str = ""

    expected_columns: List[str] = Field(min_length=1)


class LoggingConfig(BaseModel):
    level: str = "INFO"
    log_dir: str = "./logs"
    max_bytes: int = 5_242_880
    backup_count: int = 5


class AppConfig(BaseModel):
    dry_run: bool = False

    # Controle de idempotência: onde fica o registro de e-mails já
    # processados, e por quantos dias ele é mantido. Guarda apenas hashes
    # de id de mensagem (ver state_store.py), nunca conteúdo.
    state_path: str = "./state/processed.json"
    state_retention_days: int = 30


class Settings(BaseModel):
    """Configuração completa e validada do sistema."""
    auth: AuthConfig
    email: EmailFilterConfig
    excel: ExcelConfig
    logging: LoggingConfig
    app: AppConfig = AppConfig()

    @field_validator("excel")
    @classmethod
    def _valida_campos_do_backend_excel(cls, excel: ExcelConfig) -> ExcelConfig:
        if excel.backend == "graph":
            faltando = [
                nome for nome, valor in [
                    ("graph_drive_id", excel.graph_drive_id),
                    ("graph_item_path", excel.graph_item_path),
                    ("graph_table_name", excel.graph_table_name),
                ] if not valor
            ]
            if faltando:
                raise ValueError(
                    f"excel.backend='graph' requer os campos: {', '.join(faltando)}"
                )
        return excel

    @field_validator("email")
    @classmethod
    def _valida_user_upn_no_modo_app_only(cls, email_cfg, info):
        auth_cfg = info.data.get("auth")
        if auth_cfg is not None and auth_cfg.mode == "app_only" and not email_cfg.user_upn:
            raise ValueError(
                "email.user_upn é obrigatório quando auth.mode='app_only' "
                "(em modo App-Only não existe usuário logado)."
            )
        return email_cfg


def load_settings(config_path: str = "config/config.yaml") -> Settings:
    """Lê e valida o arquivo config.yaml.

    Raises:
        ConfigError: se o arquivo não existir, tiver YAML inválido,
            ou não passar na validação de schema.
    """
    path = Path(config_path)
    if not path.is_file():
        raise ConfigError(f"Arquivo de configuração não encontrado: {config_path}")

    try:
        with path.open("r", encoding="utf-8") as f:
            raw_data = yaml.safe_load(f)
    except yaml.YAMLError as exc:
        raise ConfigError(f"YAML inválido em {config_path}: {exc}") from exc

    if not raw_data:
        raise ConfigError(f"Arquivo de configuração vazio: {config_path}")

    try:
        return Settings(**raw_data)
    except Exception as exc:  # inclui pydantic.ValidationError
        raise ConfigError(f"Configuração inválida em {config_path}: {exc}") from exc
