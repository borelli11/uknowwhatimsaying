"""
graph_client.py
=================
Wrapper HTTP fino sobre a Microsoft Graph API (https://graph.microsoft.com).

Centraliza aqui:
- Injeção do token de acesso (Authorization: Bearer ...) em toda chamada.
- Tratamento de erros HTTP com mensagens claras (sem vazar o token).
- Retentativa automática quando a API responde 429 (Too Many Requests),
  respeitando o cabeçalho "Retry-After" - isso é exigido pela própria
  Microsoft para uso correto e escalável do Graph API.

Tanto o EmailClient quanto o ExcelWriter (backend "graph") usam esta
classe, evitando duplicar lógica de HTTP/erros em vários lugares.
"""

import logging
import time
from typing import Any, Protocol

import requests

from .exceptions import GraphApiError


class TokenProvider(Protocol):
    """Qualquer objeto com get_access_token() serve (AppOnlyAuthenticator
    ou DelegatedAuthenticator) - GraphClient não precisa saber qual."""

    def get_access_token(self) -> str: ...

GRAPH_BASE_URL = "https://graph.microsoft.com/v1.0"
MAX_RETRIES = 3
DEFAULT_TIMEOUT_SECONDS = 30


class GraphClient:
    """Cliente HTTP simples e resiliente para o Microsoft Graph API."""

    def __init__(self, authenticator: TokenProvider, logger: logging.Logger | None = None) -> None:
        self._authenticator = authenticator
        self._logger = logger or logging.getLogger("email_excel_automation")

    def _headers(self) -> dict:
        token = self._authenticator.get_access_token()
        return {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json",
        }

    def _request(self, method: str, url: str, **kwargs: Any) -> requests.Response:
        """Executa uma chamada HTTP ao Graph, com retentativa em erro 429."""
        full_url = url if url.startswith("http") else f"{GRAPH_BASE_URL}{url}"

        for attempt in range(1, MAX_RETRIES + 1):
            response = requests.request(
                method=method,
                url=full_url,
                headers=self._headers(),
                timeout=DEFAULT_TIMEOUT_SECONDS,
                **kwargs,
            )

            if response.status_code == 429 and attempt < MAX_RETRIES:
                retry_after = int(response.headers.get("Retry-After", "5"))
                self._logger.warning(
                    "Graph API retornou 429 (limite de requisições). "
                    "Aguardando %ss antes de tentar novamente (tentativa %d/%d).",
                    retry_after, attempt, MAX_RETRIES,
                )
                time.sleep(retry_after)
                continue

            if not response.ok:
                # Nunca incluímos os headers (que contêm o token) na mensagem de erro
                raise GraphApiError(
                    f"Graph API retornou erro {response.status_code} em {method} {url}: "
                    f"{response.text[:500]}"
                )

            return response

        raise GraphApiError(f"Falha ao chamar Graph API após {MAX_RETRIES} tentativas: {method} {url}")

    def get(self, url: str, params: dict | None = None) -> dict:
        return self._request("GET", url, params=params).json()

    def post(self, url: str, json_body: dict) -> dict:
        response = self._request("POST", url, json=json_body)
        return response.json() if response.content else {}

    def patch(self, url: str, json_body: dict) -> dict:
        response = self._request("PATCH", url, json=json_body)
        return response.json() if response.content else {}
