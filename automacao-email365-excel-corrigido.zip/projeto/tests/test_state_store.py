"""Testes do state_store.py — controle de idempotência."""

import json
from datetime import datetime, timedelta, timezone

from email_excel_automation.state_store import ProcessedMessageStore


def test_marca_e_reconhece_mensagem_processada(tmp_path):
    caminho = tmp_path / "processed.json"

    store = ProcessedMessageStore(str(caminho), retention_days=30)
    assert not store.ja_processado("AAA")

    store.marcar_processado("AAA")
    store.salvar()

    # Nova instância (simula a próxima execução do job)
    outra = ProcessedMessageStore(str(caminho), retention_days=30)
    assert outra.ja_processado("AAA")
    assert not outra.ja_processado("BBB")


def test_nao_grava_o_id_em_texto_puro(tmp_path):
    """O arquivo de estado não pode conter o id da mensagem legível."""
    caminho = tmp_path / "processed.json"
    store = ProcessedMessageStore(str(caminho))
    store.marcar_processado("AAMkAGI2-id-real-da-mensagem")
    store.salvar()

    conteudo = caminho.read_text(encoding="utf-8")
    assert "AAMkAGI2-id-real-da-mensagem" not in conteudo


def test_remove_registros_antigos(tmp_path):
    caminho = tmp_path / "processed.json"
    antigo = (datetime.now(timezone.utc) - timedelta(days=90)).isoformat()
    recente = datetime.now(timezone.utc).isoformat()
    caminho.write_text(json.dumps({"hash_antigo": antigo, "hash_recente": recente}), encoding="utf-8")

    store = ProcessedMessageStore(str(caminho), retention_days=30)
    store.marcar_processado("nova")
    store.salvar()

    dados = json.loads(caminho.read_text(encoding="utf-8"))
    assert "hash_antigo" not in dados
    assert "hash_recente" in dados


def test_arquivo_corrompido_nao_quebra_a_execucao(tmp_path):
    caminho = tmp_path / "processed.json"
    caminho.write_text("{isso não é json}", encoding="utf-8")

    store = ProcessedMessageStore(str(caminho))
    assert not store.ja_processado("AAA")  # começa vazio, sem estourar
