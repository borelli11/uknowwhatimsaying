"""Testes do excel_writer.py (backend local) — usa arquivos temporários."""

from openpyxl import load_workbook

from email_excel_automation.excel_writer import LocalExcelWriter

COLUNAS = ["Data", "Produto", "Quantidade", "Valor"]


def test_cria_planilha_nova_e_grava_linhas(tmp_path):
    destino = tmp_path / "relatorio.xlsx"
    writer = LocalExcelWriter(
        output_path=str(destino),
        sheet_name="Dados",
        expected_columns=COLUNAS,
        create_if_missing=True,
    )

    linhas = [
        {"Data": "01/01/2026", "Produto": "Caneta", "Quantidade": "10", "Valor": "50.00"},
        {"Data": "02/01/2026", "Produto": "Caderno", "Quantidade": "5", "Valor": "75.00"},
    ]
    gravadas = writer.append_rows(linhas)

    assert gravadas == 2
    assert destino.is_file()

    wb = load_workbook(destino)
    sheet = wb["Dados"]
    assert [c.value for c in sheet[1]] == COLUNAS
    assert sheet.cell(row=2, column=2).value == "Caneta"
    assert sheet.cell(row=3, column=2).value == "Caderno"


def test_append_preserva_linhas_existentes(tmp_path):
    destino = tmp_path / "relatorio.xlsx"
    writer = LocalExcelWriter(str(destino), "Dados", COLUNAS, create_if_missing=True)

    writer.append_rows([{"Data": "01/01/2026", "Produto": "A", "Quantidade": "1", "Valor": "1.0"}])
    writer.append_rows([{"Data": "02/01/2026", "Produto": "B", "Quantidade": "2", "Valor": "2.0"}])

    wb = load_workbook(destino)
    sheet = wb["Dados"]
    assert sheet.cell(row=2, column=2).value == "A"
    assert sheet.cell(row=3, column=2).value == "B"
