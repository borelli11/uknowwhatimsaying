"""Testes do email_parser.py — não dependem de rede nem do Graph API."""

import pytest

from email_excel_automation.email_parser import extract_table_from_email
from email_excel_automation.exceptions import ParsingError


COLUNAS = ["Data", "Produto", "Quantidade", "Valor"]


def test_extrai_tabela_html_com_sucesso():
    html = """
    <html><body>
        <table>
            <tr><th>Data</th><th>Produto</th><th>Quantidade</th><th>Valor</th></tr>
            <tr><td>01/01/2026</td><td>Caneta</td><td>10</td><td>50.00</td></tr>
            <tr><td>02/01/2026</td><td>Caderno</td><td>5</td><td>75.00</td></tr>
        </table>
    </body></html>
    """
    rows = extract_table_from_email(html, "html")
    assert len(rows) == 2
    assert rows[0]["Produto"] == "Caneta"
    assert rows[1]["Quantidade"] == "5"


def test_html_sem_tabela_gera_erro():
    with pytest.raises(ParsingError):
        extract_table_from_email("<html><body>sem tabela aqui</body></html>", "html")


def test_extrai_tabela_texto_simples():
    texto = "Data;Produto;Quantidade;Valor\n01/01/2026;Caneta;10;50.00\n02/01/2026;Caderno;5;75.00"
    rows = extract_table_from_email(texto, "text")
    assert len(rows) == 2
    assert rows[0]["Data"] == "01/01/2026"


def test_texto_insuficiente_gera_erro():
    with pytest.raises(ParsingError):
        extract_table_from_email("apenas uma linha sem dados", "text")


def test_ignora_tabela_de_layout_do_outlook():
    """E-mail do Outlook costuma ter tabela de layout envolvendo o conteúdo.
    O parser deve escolher a tabela cujo cabeçalho bate com as colunas
    esperadas, não simplesmente a primeira do documento."""
    html = """
    <html><body>
        <table><tr><td>Banco XYZ - comunicado interno</td></tr>
        <tr><td>Não responda este e-mail</td></tr></table>
        <table>
            <tr><th>Data</th><th>Produto</th><th>Quantidade</th><th>Valor</th></tr>
            <tr><td>01/01/2026</td><td>Caneta</td><td>10</td><td>50.00</td></tr>
        </table>
    </body></html>
    """
    rows = extract_table_from_email(html, "html", expected_columns=COLUNAS)
    assert len(rows) == 1
    assert rows[0]["Produto"] == "Caneta"


def test_erro_quando_nenhuma_tabela_bate_com_as_colunas():
    html = """
    <html><body><table>
        <tr><th>Coluna A</th><th>Coluna B</th></tr>
        <tr><td>1</td><td>2</td></tr>
    </table></body></html>
    """
    with pytest.raises(ParsingError):
        extract_table_from_email(html, "html", expected_columns=COLUNAS)
