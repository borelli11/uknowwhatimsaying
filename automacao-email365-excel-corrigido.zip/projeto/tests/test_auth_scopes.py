"""Testes de menor privilégio nos escopos delegados (não fazem rede)."""

import pytest

from email_excel_automation.auth import MSAL_RESERVED_SCOPES, build_delegated_scopes
from email_excel_automation.config_loader import Settings
from email_excel_automation.exceptions import AuthError

BASE = {
    "auth": {"mode": "delegated", "tenant_id": "t", "client_id": "c"},
    "email": {"subject_filters": ["Relatório"]},
    "excel": {"backend": "local", "expected_columns": ["Data", "Valor"]},
    "logging": {},
}


def _settings(**overrides):
    import copy
    raw = copy.deepcopy(BASE)
    for secao, valores in overrides.items():
        raw[secao].update(valores)
    return Settings(**raw)


def test_backend_local_nao_pede_permissao_de_arquivo():
    scopes = build_delegated_scopes(_settings())
    assert scopes == ["Mail.Read"]


def test_backend_graph_pede_permissao_de_arquivo():
    s = _settings(excel={"backend": "graph", "graph_drive_id": "d",
                         "graph_item_path": "/x.xlsx", "graph_table_name": "T"})
    assert "Files.ReadWrite.All" in build_delegated_scopes(s)


def test_marcar_como_lido_exige_readwrite():
    assert build_delegated_scopes(_settings(email={"mark_as_read": True})) == ["Mail.ReadWrite"]


def test_nunca_solicita_escopo_reservado_pelo_msal():
    """offline_access/openid/profile fazem o MSAL levantar ValueError."""
    assert not set(build_delegated_scopes(_settings())) & MSAL_RESERVED_SCOPES

    with pytest.raises(AuthError):
        build_delegated_scopes(_settings(auth={"extra_delegated_scopes": ["offline_access"]}))
