"""Testes da montagem da query KQL (sem rede)."""

from email_excel_automation.email_client import EmailClient


def test_assunto_com_varias_palavras_fica_entre_aspas():
    """Sem aspas internas, o KQL amarraria só a primeira palavra ao assunto
    e procuraria o resto livremente em from/subject/body."""
    query = EmailClient._build_subject_query("Relatório Diário de Vendas")
    assert query == '"subject:\\"Relatório Diário de Vendas\\""'


def test_aspas_no_assunto_sao_removidas():
    query = EmailClient._build_subject_query('Relatório "Diário"')
    assert query.count('\\"') == 2
