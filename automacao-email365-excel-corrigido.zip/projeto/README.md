# Automação E-mail (Microsoft 365) → Excel

Sistema modular que lê e-mails do Outlook (Exchange Online) via
**Microsoft Graph API**, extrai dados tabulares do corpo do e-mail e
grava esses dados em uma planilha Excel — local, em rede, no OneDrive
(sincronizado) ou diretamente no SharePoint/OneDrive online.

## Índice
1. [Arquitetura](#arquitetura)
2. [Pré-requisitos no Azure AD (Entra ID)](#pré-requisitos-no-azure-ad-entra-id)
3. [Instalação](#instalação)
4. [Configuração](#configuração)
5. [Execução](#execução)
6. [Testes](#testes)
7. [Segurança](#segurança)
8. [Como expandir](#como-expandir)

---

## Arquitetura

```
E-mail (Outlook)  --Graph API-->  EmailClient  --texto do corpo-->  EmailParser
                                                                          |
                                                                          v
Planilha Excel  <--ExcelWriter (local ou Graph)--  Validators  <-- linhas extraídas
```

- **auth.py**: obtém token OAuth2 via MSAL, fluxo App-Only (client
  credentials), com certificado (recomendado) ou client secret.
- **graph_client.py**: wrapper HTTP genérico para o Graph API (erros,
  retentativa em 429).
- **email_client.py**: busca e lê e-mails de uma mailbox específica.
- **email_parser.py**: extrai a tabela do corpo (HTML ou texto), via
  *strategy pattern* — fácil de estender para novos formatos.
- **validators.py**: garante que as linhas extraídas têm as colunas
  esperadas antes de gravar.
- **state_store.py**: registra quais e-mails já foram gravados, para que
  a janela de busca não insira a mesma linha em execuções seguidas.
  Guarda apenas hashes de id de mensagem - nenhum conteúdo.
- **excel_writer.py**: grava as linhas via `openpyxl` (arquivo local/
  rede/OneDrive sincronizado) ou via Graph Excel API (SharePoint/
  OneDrive online, usando uma **Tabela do Excel** como destino).
- **main.py**: orquestra o fluxo e trata erros por e-mail individualmente
  (um e-mail com problema não interrompe o processamento dos demais).

---

## Teste rápido local (modo delegado, recomendado para começar)

Para rodar na sua máquina agora, sem precisar de admin consent nem de
certificado, use `auth.mode: "delegated"` (já é o padrão no
`config.yaml` de exemplo). Passos mínimos:

1. **App Registration** (mesmo em teste local, o Graph API sempre
   precisa de um): Azure AD → *App registrations* → *New registration*.
   - Em *Authentication* → *Add a platform* → **Mobile and desktop
     applications** → marque `http://localhost` como Redirect URI.
   - Anote `tenant_id` e `client_id` e coloque em `config.yaml`.
2. **Permissões delegadas**: *API permissions* → *Add a permission* →
   *Microsoft Graph* → **Delegated permissions**. Peça apenas o que a sua
   configuração usa - o sistema monta a lista sozinho e a registra no log
   no início da execução:
   - `Mail.Read` (ou `Mail.ReadWrite` se `mark_as_read: true`);
   - `Files.ReadWrite.All` **só** se `excel.backend: graph` (OneDrive);
     para planilha em site do SharePoint, use
     `auth.extra_delegated_scopes: ["Sites.ReadWrite.All"]`.
   Normalmente **não** precisa de admin consent para essas permissões
   básicas (depende da política do tenant) — se seu tenant exigir,
   você mesmo, como TI, pode clicar em *Grant admin consent*.
3. **Não precisa de `.env`** neste modo (nenhum secret/certificado é
   usado) — pode deixar `excel.backend: local` para nem precisar de
   permissão de arquivo no Graph.
4. Rode:
   ```bash
   python -m email_excel_automation.main --dry-run
   ```
   Uma janela do navegador abre para você logar com sua conta
   corporativa. Da segunda execução em diante, o login é reaproveitado
   via cache local em `~/.email_excel_automation/` (arquivo protegido
   com permissão 600, contém um refresh token — trate como senha, não
   compartilhe nem versiona esse diretório).

Quando o projeto for para produção/servidor, basta trocar
`auth.mode: "app_only"` e seguir a seção abaixo.

## Pré-requisitos no Azure AD (Entra ID) — modo App-Only (produção)

Estes passos são feitos **uma única vez** pela equipe de TI/Segurança,
fora do código, e valem apenas para `auth.mode: "app_only"`:

### 1. Criar o App Registration
No portal Azure AD → *App registrations* → *New registration*. Anote o
**Application (client) ID** e o **Directory (tenant) ID**.

### 2. Configurar autenticação por certificado (recomendado)
Em *Certificates & secrets* → *Certificates* → faça upload da chave
**pública** do certificado (o `.pem`/`.cer`). A chave **privada** fica
apenas no servidor onde a automação roda (`config.certificate_path`).

> Alternativa menos segura: gerar um *Client secret* em vez de
> certificado. Suportado pelo sistema (`auth_method: client_secret`),
> mas prefira certificado sempre que possível.

### 3. Conceder permissões de aplicativo (Application permissions)
Em *API permissions* → *Add a permission* → *Microsoft Graph* →
*Application permissions*:
- `Mail.Read` (leitura de e-mails) - ou `Mail.ReadWrite`, **somente** se
  `email.mark_as_read: true`, já que marcar como lido é uma escrita
- Se `excel.backend: graph` apontando para **SharePoint**: `Sites.ReadWrite.All`
- Se `excel.backend: graph` apontando para **OneDrive**: `Files.ReadWrite.All`

Clique em **Grant admin consent** (requer um administrador do tenant).

### 4. Restringir o acesso apenas à mailbox necessária (essencial!)
Por padrão, a permissão de aplicativo `Mail.Read` dá acesso a **todas**
as mailboxes do tenant — isso viola o princípio de menor privilégio.
Restrinja usando o Exchange Online PowerShell:

```powershell
New-ApplicationAccessPolicy `
  -AppId "<client-id-do-app>" `
  -PolicyScopeGroupId "usuario@empresa.com.br" `
  -AccessRight RestrictAccess `
  -Description "Automacao E-mail-Excel: acesso restrito a esta mailbox"
```

Assim, mesmo que o certificado/secret vaze, o aplicativo só consegue
ler a mailbox explicitamente autorizada.

---

## Instalação

```bash
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install -e .                  # instala o pacote (fonte em src/)
cp .env.example .env              # depois edite o .env com os valores reais
```

O `pip install -e .` é necessário porque o código fica em `src/`; sem ele,
`python -m email_excel_automation.main` não encontra o pacote. Em ambiente
que não permita instalação editável, use `pip install -r requirements.txt`
e rode tudo com `PYTHONPATH=src` na frente.

No modo delegado, instale também o extra que protege o cache do token:

```bash
pip install -e ".[delegated]"
```

## Configuração

1. Edite `config/config.yaml`:
   - `auth.tenant_id` e `auth.client_id` (do App Registration).
   - `email.user_upn`: a mailbox a ser lida.
   - `email.subject_filters`: assuntos a procurar.
   - `excel.backend`: `local` (arquivo em disco/rede/OneDrive
     sincronizado) ou `graph` (SharePoint/OneDrive online).
   - `excel.expected_columns`: colunas esperadas no relatório.

2. Edite `.env` (nunca commitar):
   - Certificado: `AZURE_CERT_THUMBPRINT` (e `AZURE_CERT_PASSWORD` se houver).
   - Ou secret: `AZURE_CLIENT_SECRET`.

3. Se `auth_method: certificate`, coloque a chave privada no caminho
   definido em `auth.certificate_path` (ex: `config/certs/automation.pem`),
   com permissões de leitura restritas ao usuário que roda a automação.

### Usando o backend `graph` (SharePoint/OneDrive online)
1. Crie uma **Tabela** na planilha de destino (selecione o intervalo →
   *Inserir* → *Tabela*) e dê um nome a ela (ex: `TabelaDados`), igual
   ao cabeçalho de `excel.expected_columns`.
2. Preencha `excel.graph_drive_id`, `excel.graph_item_path` e
   `excel.graph_table_name` no `config.yaml`.
3. Para descobrir o `drive_id`, consulte
   `GET /sites/{site-id}/drive` (SharePoint) ou
   `GET /users/{upn}/drive` (OneDrive) no Graph Explorer.

## Execução

```bash
# Teste seguro: processa tudo, mas não grava na planilha
python -m email_excel_automation.main --dry-run

# Execução normal
python -m email_excel_automation.main

# Usando um config em outro caminho
python -m email_excel_automation.main --config /caminho/outro-config.yaml
```

Se o pacote não estiver instalado (`pip install -e .`), prefixe os
comandos com `PYTHONPATH=src`.

Recomenda-se agendar via Task Scheduler (Windows), cron (Linux) ou um
pipeline de CI/CD corporativo, com o `.venv` já provisionado.

### Idempotência (não duplicar linhas)

A busca usa uma janela de dias (`email.search_since_days`), então o mesmo
e-mail é reencontrado em várias execuções. O sistema mantém em
`app.state_path` o registro do que já foi gravado e pula esses e-mails.
Consequências práticas:

- **Não apague o arquivo de estado** entre execuções agendadas; apagá-lo
  faz a janela inteira ser reprocessada e duplicar linhas na planilha.
- O e-mail só é marcado como processado **depois** da gravação dar certo:
  se a planilha estiver bloqueada, ele é tentado de novo na execução
  seguinte em vez de se perder.
- `--dry-run` não marca nada como processado.

## Testes

```bash
PYTHONPATH=src pytest tests/ -v
```

Os testes cobrem extração de tabelas (HTML/texto) e escrita de
planilha local — não dependem de rede nem de credenciais reais.

## Segurança

- Credenciais **nunca** ficam no código nem no `config.yaml` — apenas
  em `.env` (ideal: em produção, injetadas por um cofre de segredos).
- Preferência por **certificado** em vez de client secret (assinatura
  digital, sem segredo estático circulando).
- Restrição da mailbox acessível via *Application Access Policy* no
  Exchange Online (menor privilégio).
- Filtro de log (`SensitiveDataFilter`) mascara e-mails e padrões de
  senha/token como camada extra de proteção.
- Tokens de acesso nunca são logados nem incluídos em mensagens de erro.
- **Menor privilégio nos escopos**: os escopos delegados são montados a
  partir da configuração, não fixos no código. Com `backend: local` e
  `mark_as_read: false`, o sistema pede apenas `Mail.Read` - nenhuma
  permissão de arquivo é solicitada no consentimento.
- **Cache do refresh token (modo delegado)**: com `msal-extensions`
  instalado, o cache é protegido pelo recurso nativo do SO (DPAPI no
  Windows, Keychain no macOS, libsecret no Linux). Sem a biblioteca, ele
  é gravado em **texto puro** e o sistema emite um aviso explícito no log.
  Atenção: `chmod 600` não protege arquivo no Windows (não aplica ACL),
  por isso o `msal-extensions` é o caminho recomendado lá. Em servidor,
  prefira `auth.mode: "app_only"`, que não guarda refresh token algum.
- **Busca amarrada ao assunto**: a query KQL usa aspas internas
  (`subject:"frase inteira"`). Sem isso, apenas a primeira palavra ficaria
  presa ao assunto e o restante viraria busca livre no corpo de toda a
  caixa - o robô poderia ler e gravar dados de e-mails que não são dele.
- **Arquivo de estado sem dado sensível**: guarda apenas o hash SHA-256 do
  id da mensagem e a data. Não contém assunto, corpo, endereços nem as
  linhas extraídas.
- Um e-mail malformado - ou uma falha na busca de um dos assuntos - não
  interrompe o processamento dos demais (isolamento de falhas).

## Como expandir

- **Novo assunto/relatório**: adicione uma linha em
  `email.subject_filters` no `config.yaml`. Nenhuma alteração de
  código é necessária se o layout (HTML/texto tabular) for compatível.
- **Novo formato de corpo de e-mail** (ex: CSV anexado): crie uma
  nova classe em `email_parser.py` implementando `BaseTableParser` e
  registre-a em `ParserFactory`.
- **Novo destino de planilha**: crie uma nova classe em
  `excel_writer.py` implementando `ExcelWriterBase` e registre-a em
  `build_excel_writer`.
- **Múltiplas mailboxes**: instancie múltiplos `EmailClient` (um por
  `user_upn`) reutilizando o mesmo `GraphClient`/token.
