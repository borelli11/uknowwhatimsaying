"""
Aplicação web para localizar, dentro de uma pasta de rede, subpastas
"Val..." cuja validade esteja vencida há 3 meses ou mais — e, a partir da
tela, descontinuar essas peças, movendo-as para a pasta "Descontinuadas".

ATENÇÃO: a busca (/api/scan) é somente leitura, mas /api/mover e
/api/desfazer ALTERAM a rede. A primeira:
move a pasta da peça vencida de Disponíveis para Descontinuadas, recriando
CAMPANHA\\CANAL no destino e renomeando a peça com a data do dia. Não existe
lixeira em compartilhamento de rede — o que for movido só volta movendo de
volta. Por isso a tela exige confirmação antes de qualquer envio.

Como executar:
    pip install -r requirements.txt
    python app.py

Depois acesse: http://127.0.0.1:5000
"""

import getpass
import os

from flask import Flask, render_template, request, jsonify
from scanner import escanear_pastas, CANAIS, CANAL_OUTROS, ROTULO_OUTROS
from mover import (mover_pecas, devolver_pecas, caminho_esta_dentro,
                   ErroDeMovimentacao)

# A pasta de templates aceita tanto "templates" (padrão do Flask) quanto
# "template" (nome usado em algumas cópias do projeto), para o app subir sem
# depender de qual das duas está no disco.
PASTA_DO_PROJETO = os.path.dirname(os.path.abspath(__file__))
PASTA_TEMPLATES = (
    'templates'
    if os.path.isdir(os.path.join(PASTA_DO_PROJETO, 'templates'))
    else 'template'
)

app = Flask(__name__, template_folder=PASTA_TEMPLATES)


def usuario_da_maquina():
    """Login de quem está usando o programa, para registrar no log de envios.

    Como o servidor roda em 127.0.0.1 (só na própria máquina), quem abre a
    página é necessariamente quem está logado nela — por isso o nome vem do
    sistema em vez de um campo digitado, que ficaria em branco ou preenchido
    de qualquer jeito.
    """
    try:
        return getpass.getuser()
    except Exception:
        # Ambientes sem variável de usuário definida: melhor registrar
        # "desconhecido" do que derrubar o envio por causa do log.
        return 'desconhecido'



@app.route('/')
def pagina_inicial():
    # A lista de canais é montada aqui e enviada ao HTML, para que os botões
    # de filtro sempre reflitam o que o scanner realmente reconhece.
    canais = [
        {'codigo': codigo, 'rotulo': info['rotulo'], 'descricao': info['descricao']}
        for codigo, info in CANAIS.items()
    ]
    canais.append({
        'codigo': CANAL_OUTROS,
        'rotulo': ROTULO_OUTROS,
        'descricao': 'Pastas fora dos canais acima',
    })
    return render_template('index.html', canais=canais)


@app.route('/api/scan')
def api_scan():
    caminho = request.args.get('path', '').strip()

    if not caminho:
        return jsonify({'sucesso': False, 'erro': 'Informe um caminho de pasta.'}), 400

    # 'canais' chega como lista separada por vírgula (ex: "PUSH,IB").
    # Vazio ou ausente = todos os canais.
    canais_bruto = request.args.get('canais', '').strip()
    canais = [parte for parte in canais_bruto.split(',') if parte.strip()] or None

    dados, erro = escanear_pastas(caminho, canais=canais)

    if erro:
        return jsonify({'sucesso': False, 'erro': erro}), 400

    return jsonify({'sucesso': True, **dados})


@app.route('/api/mover', methods=['POST'])
def api_mover():
    """Descontinua peças vencidas: move de Disponíveis para Descontinuadas.

    Espera um JSON com:
        origem   - a pasta que foi pesquisada (ex.: ...\\disponiveis)
        destino  - a pasta Descontinuadas
        pecas    - lista de {caminho, campanha, canal}

    'origem' não é decoração: cada peça recebida precisa estar DENTRO dela.
    Sem essa checagem, uma requisição malformada (ou um clique em uma aba
    antiga, com resultados de outra busca) poderia mandar mover uma pasta
    qualquer da máquina. Como esta rota escreve no disco, ela confere em vez
    de confiar no que chega da tela.
    """
    dados = request.get_json(silent=True) or {}

    origem = str(dados.get('origem', '')).strip()
    destino = str(dados.get('destino', '')).strip()
    pecas = dados.get('pecas') or []

    if not origem:
        return jsonify({'sucesso': False, 'erro': 'Refaça a busca antes de enviar.'}), 400

    if not destino:
        return jsonify({'sucesso': False, 'erro': 'Informe o caminho da pasta Descontinuadas.'}), 400

    if not isinstance(pecas, list) or not pecas:
        return jsonify({'sucesso': False, 'erro': 'Nenhuma peça foi informada.'}), 400

    if not os.path.isdir(origem):
        return jsonify({'sucesso': False, 'erro': f'Pasta de origem não encontrada: {origem}'}), 400

    limpas = []
    for peca in pecas:
        if not isinstance(peca, dict):
            return jsonify({'sucesso': False, 'erro': 'Lista de peças malformada.'}), 400
        limpas.append({
            'caminho': str(peca.get('caminho', '')).strip(),
            'campanha': str(peca.get('campanha', '')).strip(),
            'canal': str(peca.get('canal', '')).strip(),
        })

    fora_da_origem = [
        peca for peca in limpas
        if not peca['caminho'] or not caminho_esta_dentro(peca['caminho'], origem)
    ]
    if fora_da_origem:
        return jsonify({
            'sucesso': False,
            'erro': ('Uma ou mais peças não pertencem à pasta pesquisada. '
                     'Refaça a busca e tente de novo.'),
        }), 400

    try:
        resultado = mover_pecas(limpas, destino)
    except ErroDeMovimentacao as erro:
        # Destino inválido: nada foi movido, e a mensagem já vem pronta.
        return jsonify({'sucesso': False, 'erro': erro.mensagem}), 400

    return jsonify({
        'sucesso': True,
        'usuario': usuario_da_maquina(),
        **resultado,
    })


@app.route('/api/desfazer', methods=['POST'])
def api_desfazer():
    """Desfaz a última descontinuação: devolve as peças ao lugar de origem.

    Espera um JSON com:
        origem     - a pasta que foi pesquisada (Disponíveis)
        destino    - a pasta Descontinuadas
        devolucoes - lista de {atual, original}

    As duas checagens de pertencimento são o que impede esta rota de virar um
    "mova qualquer coisa para qualquer lugar": a peça precisa estar HOJE
    dentro de Descontinuadas, e o lugar de volta precisa estar dentro da pasta
    pesquisada. Sem isso, uma requisição forjada poderia usar o desfazer para
    escrever em qualquer canto da máquina.
    """
    dados = request.get_json(silent=True) or {}

    origem = str(dados.get('origem', '')).strip()
    destino = str(dados.get('destino', '')).strip()
    devolucoes = dados.get('devolucoes') or []

    if not origem or not destino:
        return jsonify({'sucesso': False, 'erro': 'Refaça a busca antes de desfazer.'}), 400

    if not isinstance(devolucoes, list) or not devolucoes:
        return jsonify({'sucesso': False, 'erro': 'Nada para desfazer.'}), 400

    limpas = []
    for item in devolucoes:
        if not isinstance(item, dict):
            return jsonify({'sucesso': False, 'erro': 'Lista de devoluções malformada.'}), 400
        limpas.append({
            'atual': str(item.get('atual', '')).strip(),
            'original': str(item.get('original', '')).strip(),
        })

    invalidas = [
        item for item in limpas
        if not item['atual'] or not item['original']
        or not caminho_esta_dentro(item['atual'], destino)
        or not caminho_esta_dentro(item['original'], origem)
    ]
    if invalidas:
        return jsonify({
            'sucesso': False,
            'erro': ('Uma ou mais peças não pertencem às pastas desta busca. '
                     'Refaça a busca e desfaça manualmente, se for o caso.'),
        }), 400

    try:
        resultado = devolver_pecas(limpas)
    except ErroDeMovimentacao as erro:
        return jsonify({'sucesso': False, 'erro': erro.mensagem}), 400

    return jsonify({
        'sucesso': True,
        'usuario': usuario_da_maquina(),
        **resultado,
    })


if __name__ == '__main__':
    # host='127.0.0.1' = acessível apenas nesta máquina (recomendado).
    # Se precisar acessar de outro computador da rede, use host='0.0.0.0',
    # mas com cautela: isso expõe uma ferramenta de leitura de pastas na rede.
    app.run(debug=True, host='127.0.0.1', port=5000)
