# Verificador de Validade de Pastas

Sistema web simples (HTML + CSS + Python/Flask) que verifica, em uma pasta de
rede, quais subpastas cujo nome começa com **"Val"** têm uma data de validade
**vencida há 3 meses ou mais** — e, a partir da mesma tela, descontinua essas
peças, movendo-as de **Disponíveis** para **Descontinuadas**.

## O que este sistema altera na rede

A **busca é somente leitura**: em nenhum momento cria, altera, move ou exclui
arquivos ou pastas. Ela apenas lê a estrutura de diretórios.

A **descontinuação move pastas** — é a única operação de escrita do programa,
e ela vive isolada em `mover.py`. Compartilhamento de rede não tem lixeira: o
que for movido só volta movendo de volta manualmente. Por isso a tela sempre
pede confirmação, mostrando de onde, para onde e com que nome cada peça vai
ficar.

## Como a busca funciona (importante)

O sistema entra na pasta de rede informada e **percorre automaticamente
todos os níveis de subpastas** dentro dela — não é preciso que as pastas
"Val..." estejam logo no primeiro nível. Por exemplo, essa estrutura funciona
normalmente:

```
\\servidor\rede\
├── Filial_SP\
│   ├── Val_03.24        ← encontrada
│   └── Val_09.26
├── Filial_RJ\
│   ├── Val_ATE_01.25     ← encontrada
│   └── DocumentosGerais\
└── Filial_MG\
    └── Sub_Nivel_2\
        └── Val_05.20    ← encontrada mesmo em um 3º nível
```

Assim que uma pasta "Val..." é identificada, o sistema não entra no conteúdo
dela (não é necessário e evita varredura desnecessária em pastas de rede
grandes).

A leitura das pastas é feita **em paralelo** (várias pastas lidas ao mesmo
tempo, não uma de cada vez), já que em uma pasta de rede o tempo gasto é
principalmente de latência de rede, não de processamento. Isso reduz bastante
o tempo total em compartilhamentos com muitas pastas. O número de leituras
simultâneas pode ser ajustado em `scanner.py`, na constante
`MAX_LEITURAS_PARALELAS` (padrão: 16).

## Canais (PUSH, EMKT, SMS, IB, NET, ATM, MODAL, CARD)

A estrutura da pasta de rede segue o padrão:

```
disponiveis\
└── 12345678 - Nome da Campanha\      ← briefing + nome
    ├── 0.DOCs\    registros do briefing (nunca descontinuada)
    ├── ATM\       atendimento caixa eletrônico
    ├── IB\        internet banking
    ├── NET\       Bradesco Net Empresa
    ├── EMKT\      e-mail marketing
    ├── SMS\
    ├── MODAL\     modais do app
    ├── CARD\      cards do app
    └── PUSH\      mobile push
        └── Val_03.24   ← encontrada, canal = PUSH
```

O reconhecimento não depende da grafia exata: a comparação ignora acentos,
maiúsculas e separadores, então cada canal aceita algumas escritas:

| Canal | Também aceita |
|-------|---------------|
| PUSH  | `Mobile Push`, `App Push` |
| EMKT  | `Email`, `E-mail`, `Email Marketing`, `E-mail Marketing` |
| SMS   | `Torpedo` |
| IB    | `Internet Banking` |
| NET   | `Net Empresa`, `Bradesco Net` |
| ATM   | `Caixa Eletronico`, `Autoatendimento` |
| MODAL | `Modais` |
| CARD  | `Cards` |

Se aparecer uma grafia nova na rede, basta acrescentá-la na constante
`CANAIS`, em `scanner.py` — o restante do sistema (chips, cores, filtros,
exportação) passa a reconhecê-la sozinho.

### Escolher o que será varrido

Na tela de busca há a linha **canais a verificar**. Por padrão todos vêm
marcados; ao desmarcar um canal, ele **nem chega a ser aberto** pelo
servidor. Como o custo de uma pasta de rede é a latência de cada leitura,
buscar só em PUSH é bem mais rápido do que varrer tudo.

A seleção e o último caminho consultado ficam lembrados no navegador, então
a próxima consulta já abre pronta. Se a política do navegador bloquear o
armazenamento local, o programa continua funcionando — só não lembra.

Pastas `Val...` que não estejam dentro de nenhum canal conhecido são
agrupadas em **"Outras pastas"**, que também é selecionável — assim nada
desaparece silenciosamente. (Elas aparecem na lista, mas não podem ser
descontinuadas: sem campanha e canal identificados, não há estrutura para
recriar no destino.)

A `0.DOCs` é a exceção: ela não é um canal e nem chega a ser aberta.

Pela API, o filtro é o parâmetro `canais`, separado por vírgula:

```
/api/scan?path=\\servidor\disponiveis&canais=PUSH,SMS
```

Sem o parâmetro (ou com todos os canais), varre tudo, como antes.

### Filtrar o que já está na tela

Depois da busca, a **barra de distribuição** mostra a proporção de pastas
vencidas em cada canal. Clicar num segmento — ou na legenda abaixo dele —
filtra por aquele canal sem varrer a rede de novo; clicar de novo desfaz.

Ao lado ficam o filtro por texto (atalho `/`, `Esc` limpa), o controle de
gravidade com a contagem de cada faixa e a ordenação (mais vencidas, menos
vencidas, canal, campanha ou nome).

**Exportar Excel**, **Salvar log** e **Copiar caminhos** sempre usam o
recorte que está na tela, e o canal entra no nome do arquivo gerado
(ex.: `pastas-vencidas_push_2026-09-01.xlsx`). Cada resultado traz também a
**campanha** de origem — a pasta de briefing que contém o canal.

### Pastas sem permissão

Quando alguma subpasta não pode ser lida com o seu usuário de rede, a
varredura segue nas demais e os caminhos afetados vão para um bloco
recolhido no **fim da página**, com o total ao lado do título. Ele fica
fechado por padrão: é informação de apoio, não o resultado da busca.

## Descontinuar peças vencidas

Na tela há um segundo campo, **Pasta Descontinuadas**, separado do caminho da
busca. Enquanto ele estiver em branco a descontinuação fica desligada e o
programa se comporta como antes — só busca.

Com o destino preenchido aparecem duas formas de agir:

- **Descontinuar** em cada linha da lista, para uma peça por vez;
- **Descontinuar N peças** na barra de ações, que age sobre todo o recorte
  visível na tela (os mesmos filtros que valem para Exportar e Copiar).

### O que exatamente é movido

Apenas a **peça vencida** — a pasta `Val...` — com tudo que houver dentro dela
(docx, html, xlsx, png...). A pasta da campanha e a do canal **continuam em
Disponíveis**, mesmo que fiquem vazias: elas guardam a `0.DOCs` e as peças que
ainda estão no prazo.

No destino, os três níveis são recriados com os nomes **idênticos** aos da
origem, e a peça ganha a data da descontinuação na frente:

```
Disponiveis\20260904 - Campanha X\PUSH\Val_05.24
    ->  Descontinuadas\20260904 - Campanha X\PUSH\20260905_Val_05.24
```

A pasta da campanha e a do canal são **criadas se não existirem** e
**reaproveitadas se já existirem** — é o "ctrl+c do nome idêntico" feito
automaticamente. Se a peça estiver mais fundo que o canal (por exemplo em
`PUSH\Aprovados\Val_05.24`), ela é achatada para `CAMPANHA\CANAL\`: a
estrutura final tem sempre três níveis.

O prefixo `AAAAMMDD_` é o **dia da descontinuação**, não a validade. Ele tem um
efeito colateral útil: uma peça já descontinuada não começa mais com "Val",
então a varredura nunca mais a encontra — não há como descontinuar duas vezes
a mesma coisa.

### A pasta 0.DOCs

Toda campanha tem uma `0.DOCs` com os registros do briefing. Ela **nunca é
aberta pela varredura**: nada lá dentro aparece na lista e, por consequência,
não há como mover por engano o que nunca foi listado. Por isso "DOCs" também
deixou de ser um canal — não existe mais chip para ele.

O reconhecimento ignora acentos, maiúsculas, separadores e zeros à esquerda —
**inclusive quando o zero está grudado no nome, sem separador nenhum**. Todas
estas variações são tratadas como a mesma pasta protegida: `0.DOCs`,
`0 DOCS`, `DOCs`, `docs`, `0DOCs`, `00DOCS`, `Documentos`, `0Documentos`.

Essa regra é conferida em **dois pontos independentes**, não só um:
1. `scanner.py` nunca entra na pasta — ela simplesmente não aparece na lista.
2. `mover.py` confere a mesma regra de novo, na hora de mover. Mesmo que uma
   pasta "DOCs" chegasse até essa rota por qualquer outro caminho (uma
   requisição malformada, por exemplo), a movimentação é recusada com o erro
   `pasta_protegida` e nada é escrito no disco.

### Desfazer (Ctrl+Z da última operação)

Depois de confirmar, o comprovante ganha um botão **Desfazer**, que devolve as
peças ao lugar exato de onde saíram, com o nome que tinham antes (sem o
prefixo de data).

O alcance é **deliberadamente estreito**: desfaz a **última** operação e só
**enquanto a página estiver aberta**. Recarregou, fez outra busca ou já
desfez uma vez, acabou. É o que dá para prometer com honestidade — depois de
alguns minutos a rede seguiu a vida, e a peça pode ter sido recriada no lugar
de origem por outra pessoa.

Duas observações que valem mais que o botão em si:

- **Um desfazer não substitui a confirmação.** A tendência natural é confirmar
  com menos atenção quando existe um "volta atrás". A confirmação continua
  sendo a trava que de fato protege; o desfazer cobre o caso "percebi o erro
  agora", não é rede de segurança para confiar.
- **Toda movimentação já era reversível na mão.** O log traz origem e destino
  de cada peça, então dá para refazer o caminho de volta pelo Explorer a
  qualquer momento. O botão só automatiza o caso comum.

A devolução usa **a mesma trava do envio**: se já existir algo com aquele nome
no lugar de origem, ela é bloqueada e o motivo aparece na tela — nada é
sobrescrito, e as duas versões continuam separadas para você decidir. A pasta
do canal é recriada se tiver sido apagada nesse meio-tempo.

O desfazer **gera seu próprio log**, com situação `Devolvida` e o sufixo
`-desfeito` no nome do arquivo. O log da descontinuação não é apagado nem
corrigido: ele registra o que aconteceu, e o que aconteceu foi que a operação
existiu e depois foi revertida.

Uma pequena sujeira conhecida: as pastas de campanha e canal criadas em
Descontinuadas continuam lá, vazias, depois de um desfazer. Preferi deixar
assim a apagar pastas automaticamente — pode ser que já existissem antes, e
excluir é a única coisa que este programa não faz.

### Log de auditoria (quem descontinuou o quê)

Toda confirmação **gera e baixa um arquivo de log** na hora, sem perguntar
nada. Ele registra, em uma linha por peça:

| Coluna | Conteúdo |
|--------|----------|
| Data/hora | Momento da descontinuação |
| Usuário | Login do Windows de quem confirmou |
| Situação | `Descontinuada` ou `Bloqueada` |
| Briefing / Campanha | Nome da pasta da campanha |
| Canal | Nome da pasta do canal |
| Peça (nome original) | Ex.: `Val_05.24` |
| Nome em Descontinuadas | Ex.: `20260905_Val_05.24` |
| Validade / Meses vencida | Da própria peça |
| Origem / Destino | Caminhos completos |
| Motivo do bloqueio | Preenchido só nas bloqueadas |

As **bloqueadas entram no log junto com as descontinuadas** — de propósito.
Uma tentativa barrada é exatamente o que alguém vai querer conferir depois
("descontinuei ou não aquela peça?").

O nome do arquivo carrega usuário, data e hora
(`descontinuadas_enrico.lara_2026-09-05_14h30.xlsx`), então dois envios do
mesmo dia não se sobrescrevem na pasta de Downloads. O botão **Baixar log de
novo**, no comprovante, gera a segunda via com a data/hora da operação
original — não a do clique.

O usuário vem do login da máquina (`getpass.getuser()`), sem campo para
digitar: como o servidor roda em `127.0.0.1`, quem abre a página é
necessariamente quem está logado nela.

Se a biblioteca do Excel não carregar (o CDN é bloqueado em algumas redes
corporativas), o log sai em **CSV** com as mesmas colunas — separado por `;` e
com BOM, então o Excel em português abre direto em colunas. Um registro de
auditoria não pode depender de a internet estar liberada.

### Proteções

- **Nada é sobrescrito.** Se a peça já existir no destino com o mesmo nome
  (descontinuar duas vezes no mesmo dia), ela é bloqueada, a origem fica
  intacta e o motivo aparece na tela. A verificação acontece **antes** de
  criar qualquer pasta, então uma peça bloqueada não deixa campanha vazia no
  destino.
- **Uma falha não interrompe o lote.** A peça problemática (alguém com a pasta
  aberta, permissão negada) entra na lista de bloqueadas e as demais seguem.
- **O servidor não confia na tela.** Cada peça precisa estar dentro da pasta
  que foi pesquisada; os nomes de campanha e canal precisam ser um único
  segmento (nada de `..\..\outra`); o destino precisa existir e aceitar
  escrita. Qualquer coisa fora disso é recusada antes de mexer em um byte.
- **Comprovante na tela.** Depois do envio, um bloco lista o que foi movido e
  o que foi bloqueado, com o motivo, até a próxima busca.
- **Desfazer não sobrescreve.** Se a peça foi recriada em Disponíveis nesse
  meio-tempo, a devolução dela é bloqueada — as duas versões ficam separadas
  em vez de uma sumir por baixo da outra.
- **O log nunca derruba o envio.** A geração do arquivo acontece dentro de um
  `try/catch`: nesse ponto as pastas JÁ foram movidas, e deixar uma falha do
  log estourar faria a tela dizer que o envio não deu certo — a pior mentira
  possível, porque a pessoa tentaria de novo achando que nada aconteceu.

Entre compartilhamentos de rede diferentes, mover vira cópia + remoção — em
campanhas grandes, isso demora. O botão mostra "Movendo..." enquanto trabalha.

Pela API:

```
POST /api/mover
{"origem": "\\servidor\disponiveis",
 "destino": "\\servidor\descontinuadas",
 "campanhas": ["\\servidor\disponiveis\12345678 - Campanha X"]}
```

## Regras usadas para identificar as pastas

1. O nome da pasta precisa começar com `Val` (não diferencia maiúsculas de
   minúsculas: `val`, `VAL`, `Val` etc. são aceitos).
2. A validade é a **última ocorrência** de uma data no formato `MM.AA` ou
   `MM.AAAA` encontrada no nome da pasta. Exemplos:
   - `Val_08.26` → validade 08/2026
   - `Val_02.09.26_ATE_11.26` → validade 11/2026 (última ocorrência)
   - `Val_ATE_02.27` → validade 02/2027
3. A pasta só aparece no resultado se a validade estiver vencida há **3 meses
   ou mais**, contando corretamente a virada de ano (ex: validade 11/2025,
   hoje fevereiro/2026 → 3 meses vencida).

## Estrutura do projeto

```
verificador-validade/
├── app.py              # Rotas web e da API (Flask)
├── scanner.py          # Varredura das pastas — SOMENTE LEITURA
├── mover.py            # Descontinuação — único ponto que escreve no disco
├── requirements.txt    # Dependências Python
├── README.md
├── template/           # (ou "templates/" — o app.py aceita os dois nomes)
│   └── index.html      # Página principal
└── static/
    ├── style.css        # Estilo visual
    └── script.js        # Chamada da API e exibição dos resultados
```

## Como executar localmente

### 1. Pré-requisitos
- Python 3.9 ou superior instalado.

### 2. Criar um ambiente virtual (recomendado)

```bash
python -m venv venv
```

Ativar o ambiente:
- **Windows:** `venv\Scripts\activate`
- **Linux/macOS:** `source venv/bin/activate`

### 3. Instalar as dependências

```bash
pip install -r requirements.txt
```

### 4. Executar o sistema

```bash
python app.py
```

### 5. Acessar no navegador

Abra: [http://127.0.0.1:5000](http://127.0.0.1:5000)

Digite o caminho da pasta de rede que deseja verificar, por exemplo:
- Windows: `\\servidor\compartilhamento\pasta`
- Linux/macOS (montagem de rede): `/mnt/rede/pasta`

Clique em **Buscar**. O sistema mostrará uma tabela com nome, validade, meses
vencida e caminho completo de cada pasta encontrada. Os resultados sempre
aparecem na tela; o botão **Salvar log** é opcional e gera, além disso, um
arquivo `.txt` com o mesmo conteúdo, e o botão **Exportar para Excel** gera
uma planilha `.xlsx`.

## Observações importantes

- **Segurança:** por padrão, o servidor roda apenas em `127.0.0.1` (acessível
  só na própria máquina). Não altere para `0.0.0.0` sem necessidade real: além
  de listar caminhos de pastas, esta ferramenta agora **move pastas de rede**,
  e expor isso na rede significa expor essa capacidade a quem alcançar a
  porta. Se precisar mesmo, trate como uma decisão de segurança, não como um
  ajuste de configuração.
- **Erros de acesso:** se alguma subpasta não puder ser lida (permissão
  negada, por exemplo), o sistema continua a varredura nas demais pastas e
  mostra um aviso na tela, em vez de interromper tudo.
- **Caminho inexistente:** se o caminho informado não existir ou não for uma
  pasta, uma mensagem de erro clara é exibida.
