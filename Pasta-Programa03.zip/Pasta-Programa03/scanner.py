"""
Módulo responsável por escanear pastas e identificar aquelas com validade
vencida há 3 meses ou mais.

IMPORTANTE: este módulo continua SOMENTE LEITURA. Em nenhum momento cria,
altera, move ou exclui arquivos/pastas — apenas lê nomes e navega na árvore
de diretórios. A movimentação de campanhas para "Descontinuadas" vive em
`mover.py`, separada de propósito: assim o único ponto do sistema capaz de
escrever em disco fica isolado e fácil de auditar.

Versão com leitura em paralelo: como o gargalo em uma pasta de rede é a
LATÊNCIA de cada chamada (não o processamento), várias pastas são lidas ao
mesmo tempo em vez de uma de cada vez. Isso costuma reduzir bastante o tempo
total em compartilhamentos grandes.

Versão com FILTRO POR CANAL: a estrutura da pasta de rede é
    disponiveis\\<briefing + nome da campanha>\\<CANAL>\\...\\Val_MM.AA
onde <CANAL> é PUSH, EMKT, SMS, IB, NET, ATM, MODAL ou CARD. É possível
escolher quais canais interessam; os canais não escolhidos não são nem lidos
(menos chamadas de rede = busca mais rápida).

A pasta "0.DOCs" de cada campanha é pulada de propósito: é o registro do
briefing, não uma peça, e nunca deve ser descontinuada.
"""

import os
import re
import calendar
import threading
import unicodedata
from datetime import date
from concurrent.futures import ThreadPoolExecutor

# Regex que localiza datas no formato MM.AA ou MM.AAAA dentro do nome da pasta.
# (?<!\d) e (?!\d) garantem que não pegamos pedaços de números maiores.
# Exemplos que casam: 08.26 | 02.09 | 11.2026
PADRAO_DATA = re.compile(r'(?<!\d)(\d{2})\.(\d{4}|\d{2})(?!\d)')

# Quantidade de meses de tolerância antes de considerar a pasta "vencida".
MESES_LIMITE_VENCIMENTO = 3

# Quantas pastas são lidas ao mesmo tempo. Como o gargalo é a rede (e não a
# CPU), esse número pode ser bem maior que a quantidade de núcleos da
# máquina. Ajuste para cima/baixo conforme o comportamento do servidor de
# arquivos (números muito altos podem sobrecarregar um servidor de rede
# lento ou levar a mais erros de "muitas conexões simultâneas").
MAX_LEITURAS_PARALELAS = 16

# ============================================================================
# Canais (pastas de meio dentro de cada campanha)
# ============================================================================
# Código usado para tudo que foi encontrado FORA de uma pasta de canal
# conhecida (ex.: uma "Val..." solta direto na pasta da campanha).
CANAL_OUTROS = 'OUTROS'
ROTULO_OUTROS = 'Outras pastas'

# 'apelidos' são os nomes de pasta aceitos para cada canal, já normalizados
# (sem acento, minúsculo, sem separadores). Assim "E-MAIL MARKETING",
# "Email_Marketing" e "emkt" caem todos em EMKT.
CANAIS = {
    'PUSH': {
        'rotulo': 'PUSH',
        'descricao': 'Mobile Push',
        'apelidos': ('push', 'mobile push', 'mobilepush', 'app push'),
    },
    'EMKT': {
        'rotulo': 'EMKT',
        'descricao': 'E-mail marketing',
        'apelidos': ('emkt', 'email', 'e mail', 'email marketing',
                     'e mail marketing', 'mkt email'),
    },
    'SMS': {
        'rotulo': 'SMS',
        'descricao': 'Mensagem de texto',
        'apelidos': ('sms', 'torpedo'),
    },
    'IB': {
        'rotulo': 'IB',
        'descricao': 'Internet Banking',
        'apelidos': ('ib', 'internet banking', 'internetbanking'),
    },
    'NET': {
        'rotulo': 'NET',
        'descricao': 'Bradesco Net Empresa',
        'apelidos': ('net', 'net empresa', 'netempresa', 'bradesco net'),
    },
    'ATM': {
        'rotulo': 'ATM',
        'descricao': 'Atendimento caixa eletrônico',
        'apelidos': ('atm', 'caixa eletronico', 'autoatendimento'),
    },
    'MODAL': {
        'rotulo': 'MODAL',
        'descricao': 'Modais do app',
        'apelidos': ('modal', 'modais'),
    },
    'CARD': {
        'rotulo': 'CARD',
        'descricao': 'Cards do app',
        'apelidos': ('card', 'cards'),
    },
}

# ------------------------------------------------------------------------------
# Pasta de registro do briefing (a "0.DOCs")
# ------------------------------------------------------------------------------
# Existe em toda campanha e é onde ficam os registros — nunca é descontinuada.
# Por isso ela não é um canal: a varredura simplesmente NÃO ENTRA nela. Assim
# nada lá dentro aparece na lista e não há como mover por engano.
#
# O reconhecimento ignora acentos, maiúsculas, espaços/separadores E zeros à
# esquerda — inclusive quando o zero está GRUDADO no nome, sem separador
# nenhum (ex.: "0DOCs", "00DOCS"). Por isso a comparação usa o nome
# "compactado" (sem nenhum caractere que não seja letra ou número) em vez de
# normalizar separadores para espaço: assim "0.DOCs", "0 DOCS", "0DOCs",
# "DOCs", "doc" e "Documentos" caem todos no mesmo núcleo abaixo.
_NUCLEOS_DE_REGISTRO = frozenset({'docs', 'doc', 'documentos', 'documento'})


def _normalizar(texto: str) -> str:
    """Minúsculo, sem acento e sem separadores — para comparar nomes de pasta."""
    base = unicodedata.normalize('NFKD', texto)
    base = ''.join(c for c in base if not unicodedata.combining(c))
    base = re.sub(r'[^a-z0-9]+', ' ', base.lower())
    return base.strip()


def _normalizar_compacto(texto: str) -> str:
    """
    Como `_normalizar`, mas junta tudo em um único bloco (sem espaços),
    removendo qualquer caractere que não seja letra ou número. É o que
    permite reconhecer "0DOCs" (zero grudado, sem separador) — um simples
    `replace` por espaço não pega esse caso, porque não existe separador
    nenhum entre o zero e o resto do nome.
    """
    base = unicodedata.normalize('NFKD', texto)
    base = ''.join(c for c in base if not unicodedata.combining(c))
    return re.sub(r'[^a-z0-9]', '', base.lower())


def e_pasta_de_registro(nome_pasta: str) -> bool:
    """
    True para a pasta de registro do briefing (0.DOCs) e QUALQUER variante
    dela — é a pasta que a varredura pula e que NUNCA pode ser descontinuada.

    Cobre, por exemplo: "0.DOCs", "0 DOCS", "DOCs", "docs", "0DOCs",
    "00DOCS", "Documentos", "0Documentos". A comparação é por igualdade
    exata do núcleo (depois de tirar acento/caixa/separadores/zeros à
    esquerda) — não por "contém", então uma campanha chamada
    "Teste_Da_0DOCs" não é confundida com a pasta de registro em si.
    """
    nucleo = _normalizar_compacto(nome_pasta).lstrip('0')
    return nucleo in _NUCLEOS_DE_REGISTRO


_MAPA_APELIDOS = {
    apelido: codigo
    for codigo, info in CANAIS.items()
    for apelido in info['apelidos']
}


def identificar_canal(nome_pasta: str):
    """Retorna o código do canal ('PUSH', 'IB'...) ou None se não for canal."""
    return _MAPA_APELIDOS.get(_normalizar(nome_pasta))


def rotulo_do_canal(codigo: str) -> str:
    """Nome amigável do canal, para exibição."""
    if codigo == CANAL_OUTROS:
        return ROTULO_OUTROS
    return CANAIS.get(codigo, {}).get('rotulo', codigo)


def codigos_de_canal() -> list:
    """Todos os códigos aceitos no filtro, incluindo OUTROS."""
    return list(CANAIS.keys()) + [CANAL_OUTROS]


def normalizar_selecao(canais):
    """
    Converte a seleção recebida (lista/set/None) em um conjunto de códigos
    válidos. Retorna None quando nada foi informado ou quando todos os
    canais foram selecionados — nesse caso não há filtro nenhum a aplicar.
    """
    if not canais:
        return None

    validos = set(codigos_de_canal())
    selecao = {str(c).strip().upper() for c in canais if str(c).strip()}
    selecao &= validos

    if not selecao or selecao == validos:
        return None
    return selecao


def pasta_e_candidata(nome_pasta: str) -> bool:
    """True se o nome da pasta começa com 'val' (ignorando maiúsculas/minúsculas)."""
    return nome_pasta.strip().lower().startswith('val')


def extrair_validade(nome_pasta: str):
    """
    Encontra a ÚLTIMA ocorrência de MM.AA ou MM.AAAA no nome da pasta e
    retorna a data correspondente ao último dia daquele mês/ano.

    Retorna None se nenhuma data válida for encontrada.
    """
    ocorrencias = PADRAO_DATA.findall(nome_pasta)
    if not ocorrencias:
        return None

    mes_str, ano_str = ocorrencias[-1]  # última ocorrência encontrada

    mes = int(mes_str)
    ano = int(ano_str)

    # Ano com 2 dígitos -> assume-se 20XX (ex: 26 -> 2026)
    if ano < 100:
        ano += 2000

    if mes < 1 or mes > 12:
        return None

    ultimo_dia_do_mes = calendar.monthrange(ano, mes)[1]
    return date(ano, mes, ultimo_dia_do_mes)


def meses_entre(data_referencia: date, data_validade: date) -> int:
    """
    Quantidade de meses completos já passados desde o fim do mês de validade.
    Considera corretamente a virada de ano (ex: validade 11/2025 e hoje
    fevereiro/2026 = 3 meses).
    """
    return (
        (data_referencia.year - data_validade.year) * 12
        + (data_referencia.month - data_validade.month)
    )


def escanear_pastas(caminho_base: str, data_referencia: date = None, canais=None):
    """
    Percorre recursivamente 'caminho_base' e retorna a tupla (dados, erro).

    - 'canais': lista de códigos ('PUSH', 'IB', 'ATM', 'EMKT', 'DOCS',
      'OUTROS'). None ou lista completa = sem filtro. Os canais fora da
      seleção NÃO são lidos, o que reduz o número de chamadas à rede.
    - 'dados' é um dicionário: {'resultados': [...], 'avisos': [...],
      'resumo_canais': {...}}
    - 'erro' é uma string de erro, ou None se tudo correu bem.

    Nenhum arquivo ou pasta é alterado, movido ou excluído — apenas leitura.
    """
    if data_referencia is None:
        data_referencia = date.today()

    selecao = normalizar_selecao(canais)

    try:
        if not os.path.exists(caminho_base):
            return None, f'Caminho não encontrado ou inacessível: {caminho_base}'

        if not os.path.isdir(caminho_base):
            return None, f'O caminho informado não é uma pasta: {caminho_base}'
    except OSError as erro:
        return None, f'Não foi possível acessar o caminho informado: {erro}'

    resultados = []
    avisos = []
    lock = threading.Lock()  # protege 'resultados' e 'avisos' entre as threads

    def canal_selecionado(codigo) -> bool:
        """True se esse canal deve entrar no resultado (None = ainda fora de canal)."""
        if selecao is None:
            return True
        return (codigo or CANAL_OUTROS) in selecao

    def listar_subpastas(caminho):
        """Lê apenas os NOMES das subpastas diretas de 'caminho' (somente leitura)."""
        try:
            with os.scandir(caminho) as it:
                return [
                    entrada.name for entrada in it
                    if entrada.is_dir(follow_symlinks=False)
                ]
        except OSError:
            with lock:
                avisos.append(f'Sem permissão/acesso para ler: {caminho}')
            return []

    def contexto_inicial(caminho):
        """Cada pasta da fila carrega, além do caminho, onde ela está na
        hierarquia campanha -> canal. É isso que permite recriar
        CAMPANHA\\CANAL no destino sem ter que adivinhar depois."""
        return {
            'caminho': caminho,
            'canal': None,            # código do canal ('PUSH'...) ou None
            'campanha': None,         # nome da pasta da campanha
            'caminho_campanha': None, # caminho completo dela
            'nome_canal': None,       # nome da pasta do canal COMO ESTÁ NO DISCO
            'eh_raiz': True,          # True só para a própria pasta pesquisada
        }

    def processar_pasta(contexto):
        """
        Lê as subpastas diretas de 'contexto'. Cada contexto carrega, além do
        caminho, o canal em que já estamos e a campanha correspondente —
        assim cada resultado sabe de qual canal veio.

        A CAMPANHA é travada assim que descemos um nível a partir da pasta
        pesquisada: cada subpasta direta dela é, por definição, uma
        campanha — independente de mais adiante existir ou não uma pasta de
        canal reconhecida. Isso cobre as duas estruturas:
            Disponíveis\\CAMPANHA\\CANAL\\Val...   (com canal)
            Disponíveis\\CAMPANHA\\Val...           (peça solta, sem canal)
        Sem isso, a segunda estrutura nunca teria campanha identificada, e a
        peça ficaria travada para descontinuar por não "pertencer" a nenhuma
        campanha reconhecida — mesmo pertencendo.

        Para cada subpasta encontrada:
          - se for candidata ("Val...") e estiver vencida, registra no
            resultado (desde que o canal esteja na seleção);
          - se for a pasta de um canal (PUSH/EMKT/SMS/IB/NET/ATM/MODAL/
            CARD/DOCs) e esse canal
            NÃO estiver selecionado, ela é ignorada por completo — não se
            entra nela, o que evita leituras desnecessárias na rede;
          - caso contrário, devolve o caminho para ser lido na próxima rodada.
        Não desce dentro de pastas "Val..." (evita varredura desnecessária).
        """
        caminho = contexto['caminho']
        canal = contexto['canal']
        campanha = contexto['campanha']
        caminho_campanha = contexto['caminho_campanha']
        nome_canal = contexto['nome_canal']
        eh_raiz = contexto['eh_raiz']
        proximas = []

        for nome in listar_subpastas(caminho):
            caminho_filho = os.path.join(caminho, nome)

            if pasta_e_candidata(nome):
                if not canal_selecionado(canal):
                    continue  # canal fora do filtro escolhido

                data_validade = extrair_validade(nome)
                meses_vencida = (
                    meses_entre(data_referencia, data_validade)
                    if data_validade is not None else None
                )
                esta_vencida = (
                    meses_vencida is not None
                    and meses_vencida >= MESES_LIMITE_VENCIMENTO
                )

                if esta_vencida:
                    codigo = canal or CANAL_OUTROS
                    with lock:
                        resultados.append({
                            'nome': nome,
                            'caminho': caminho_filho,
                            'validade': data_validade.strftime('%m/%Y'),
                            'meses_vencida': meses_vencida,
                            'canal': codigo,
                            'canal_rotulo': rotulo_do_canal(codigo),
                            'campanha': campanha or '',
                            'caminho_campanha': caminho_campanha or '',
                            # Nome da pasta do canal exatamente como está no
                            # disco: é ele que será recriado em Descontinuadas,
                            # não o código interno ('PUSH') nem o rótulo.
                            'nome_canal': nome_canal or '',
                        })

                # já classificada como "Val...": não entra dentro dela.
                continue

            # A 0.DOCs é o registro do briefing: nunca é descontinuada, então
            # a varredura nem entra nela. Fazer isso aqui (em vez de filtrar
            # depois) garante que nada lá de dentro chegue à tela — não há como
            # mover por engano o que nunca foi listado.
            if e_pasta_de_registro(nome):
                continue

            # Se estamos exatamente na pasta pesquisada, esta subpasta É a
            # campanha — trava agora, para quem vier depois (com ou sem
            # canal) já herdar o nome certo.
            if eh_raiz:
                campanha_do_filho = nome
                caminho_campanha_do_filho = caminho_filho
            else:
                campanha_do_filho = campanha
                caminho_campanha_do_filho = caminho_campanha

            # Só procuramos pasta de canal enquanto ainda não estamos dentro
            # de um canal — assim uma subpasta chamada "Push" lá no fundo de
            # /IB/ não reclassifica o resultado.
            codigo_canal = identificar_canal(nome) if canal is None else None

            if codigo_canal is not None:
                if selecao is not None and codigo_canal not in selecao:
                    continue  # canal descartado: nem é aberto
                proximas.append({
                    'caminho': caminho_filho,
                    'canal': codigo_canal,
                    'campanha': campanha_do_filho,
                    'caminho_campanha': caminho_campanha_do_filho,
                    'nome_canal': nome,
                    'eh_raiz': False,
                })
            else:
                # Subpasta comum: herda campanha e canal de quem a contém.
                proximas.append({
                    'caminho': caminho_filho,
                    'canal': canal,
                    'campanha': campanha_do_filho,
                    'caminho_campanha': caminho_campanha_do_filho,
                    'nome_canal': nome_canal,
                    'eh_raiz': False,
                })

        return proximas

    # Varredura "por nível" (largura), com cada nível lido em paralelo:
    # primeiro lê a pasta raiz, depois lê TODAS as subpastas encontradas ao
    # mesmo tempo (até MAX_LEITURAS_PARALELAS por vez), depois o próximo
    # nível, e assim por diante — em vez de esperar uma pasta terminar para
    # só então começar a próxima.
    try:
        with ThreadPoolExecutor(max_workers=MAX_LEITURAS_PARALELAS) as executor:
            nivel_atual = [contexto_inicial(caminho_base)]
            while nivel_atual:
                resultados_do_nivel = executor.map(processar_pasta, nivel_atual)
                proximo_nivel = []
                for subpastas_para_ler in resultados_do_nivel:
                    proximo_nivel.extend(subpastas_para_ler)
                nivel_atual = proximo_nivel
    except OSError as erro:
        return None, f'Erro durante a leitura das pastas: {erro}'

    # Mostra primeiro as mais vencidas
    resultados.sort(key=lambda item: item['meses_vencida'], reverse=True)

    # Quantas pastas vencidas em cada canal — usado para montar os contadores
    # do filtro na tela.
    resumo_canais = {}
    for item in resultados:
        resumo_canais[item['canal']] = resumo_canais.get(item['canal'], 0) + 1

    return {
        'resultados': resultados,
        'avisos': avisos,
        'resumo_canais': resumo_canais,
    }, None
