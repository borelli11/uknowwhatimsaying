# Validador de pacotes EMKT

**Bradesco · CRM · Publicação e Orquestração**

Interface web em `app.py` (Flask). Também há uma linha de comando em `cli.py`,
para quem quiser encadear em script.

Substitui o CTRL+F e o bate visual manual na conferência dos pacotes que chegam
do marketing. Confere imagens, código e CONTEUDO.docx e devolve um relatório com
o que precisa ser corrigido antes da publicação.

## O que ele confere

**1. Imagens**
- Nome segue a taxonomia da quebra (`quebra_01.jpg`, `quebra_02.png`, …)
- Numeração sequencial sem furo — `01, 02, 08, 03` reprova
- Toda imagem da pasta é chamada no HTML
- Todo `src` do HTML existe na pasta
- Divergência de maiúscula/minúscula entre pasta e código
- Reaproveitar a mesma imagem no HTML é permitido e não gera apontamento

Cobre `<img src>`, `srcset`, `background=""` de tabela e `background-image` em
CSS inline — os quatro jeitos de chamar imagem que aparecem em HTML de e-mail.

**2. Texto na ordem de leitura**
Percorre o DOM na ordem do código e monta uma fita única:

```
[texto vivo] [texto da img_01] [texto vivo] [texto da img_02] …
```

Essa é a ordem que o leitor de tela entrega ao cliente. A fita é comparada
palavra a palavra com o CONTEUDO.docx, apontando:

| Apontamento | O que significa |
|---|---|
| Falta no docx | está na peça, não foi para o docx — o cliente com deficiência visual não recebe |
| Texto diferente | mesma posição, palavra trocada — oferta divergente |
| Fora de ordem | o trecho existe, mas em posição diferente |
| Sobra no docx | está no docx, não está na peça |

**3. Texto dentro das imagens (OCR)**
Lê o texto das imagens respeitando a ordem visual (topo → esquerda). É o que
pega o caso mais grave: banner escrito "em até 48x" e docx escrito "em até 60x".

**4. Trechos com tratamento especial** (`validador/excecoes.py`)

*Dispensáveis* — o link de fallback do topo ("se não conseguiu visualizar,
clique aqui") é texto de template. Estar no HTML e faltar no docx não gera
apontamento; aparece no relatório como ignorado, para você saber que foi visto.

*Obrigatórios* — disclaimer, opt-out/descadastro e canais de atendimento
(Central, Ouvidoria, SAC). Faltar no docx é apontamento alto, marcado como
**conteúdo obrigatório** no relatório e reprova o pacote. É conteúdo que o
cliente com deficiência visual tem direito de receber.

Um trecho que caia nas duas listas é tratado como obrigatório — na dúvida, o
sistema cobra. As duas listas são regex editáveis em `excecoes.py`.

**5. Pré-header**
Confere se o pré-header do docx de assunto aparece no HTML, normalmente na div
oculta do topo.

## Instalação

```bash
pip install beautifulsoup4 python-docx pillow pytesseract
```

O OCR precisa do binário do Tesseract, que não é pacote Python:

- **Windows:** instalador em `github.com/UB-Mannheim/tesseract/wiki`, marcando
  o idioma **Portuguese** durante a instalação.
- Se o Tesseract estiver fora do PATH, aponte o caminho:
  ```
  set TESSERACT_CMD=C:\Program Files\Tesseract-OCR\tesseract.exe
  ```

**Sem o Tesseract o sistema continua rodando.** As verificações de imagem e de
texto vivo funcionam normalmente e as imagens entram no relatório listadas como
"conferir manualmente". Vale subir assim enquanto a instalação não é liberada.

Sem o pacote de idioma português, ele cai para inglês automaticamente e avisa —
funciona, mas erra acento. Instale `por` para conferência confiável.

## Uso

```bash
# um pacote
python cli.py "C:\pacotes\EMKT_CREDITO_PF"

# informando a quebra em vez de deixar deduzir
python cli.py "C:\pacotes\EMKT_CREDITO_PF" --quebra emkt_credito_pf

# vários pacotes de uma vez, uma subpasta por quebra
python cli.py "C:\pacotes" --lote

# sem ler o texto das imagens
python cli.py "C:\pacotes\EMKT_CREDITO_PF" --sem-ocr

# abrir o relatório ao terminar
python cli.py "C:\pacotes\EMKT_CREDITO_PF" --abrir
```

O relatório sai em `relatorios/conferencia_<quebra>.html` — arquivo único, abre
em qualquer navegador, dá para anexar no chamado como evidência da conferência.

Código de saída: `0` aprovado, `1` reprovado. Serve para encadear em script.

## Semáforo

| Status | Significado |
|---|---|
| APROVADO | sem divergência; pode publicar |
| ATENÇÃO | trecho fora de ordem, sobra no docx ou imagem não lida — olho humano |
| REPROVADO | texto faltando/trocado ou problema de imagem — devolver ao analista |

Trate como triagem, não como carimbo. O sistema tira o volume de cima de você;
o julgamento do que é ATENÇÃO continua sendo seu.

## Estrutura

```
app.py              servidor Flask e API
cli.py              linha de comando
static/style.css    estilo, tokens e modo escuro
static/script.js    interface
templates/index.html
validador/
  normalizacao.py   aspas curvas, NBSP, acento — evita divergência falsa
  ocr.py            leitura das imagens, com fallback quando não há Tesseract
  html_parser.py    percorre o DOM e monta a fita de leitura
  docx_parser.py    lê CONTEUDO e ASSUNTO, inclusive texto em tabela
  imagens.py        taxonomia, sequência e cruzamento pasta × HTML
  excecoes.py       trechos dispensáveis e obrigatórios
  presenca.py       comparação parcial, quando não há leitura de imagem
  correcao_ocr.py   corrige palavra colada e caractere confundido
  serializacao.py   resultado em JSON para a tela
  comparador.py     comparação de sequência e classificação das divergências
  relatorio.py      relatório HTML
```

## Ajustes que você vai querer fazer

- **Taxonomia:** `RE_PADRAO` em `imagens.py` aceita `quebra_01`, `quebra-01` e
  `quebra01`. Aperte a regex se o padrão do time for único.
- **Tolerância do OCR:** `confianca_minima=40` em `ocr.py`. Subir reduz ruído e
  aumenta falso "falta no docx"; descer faz o contrário.
- **Listas de exceção:** `excecoes.py`. Se aparecer outro texto de template
  recorrente que não vai no docx, acrescente em `DISPENSAVEIS`. Se o time tiver
  outro bloco mandatório, acrescente em `OBRIGATORIOS` — ele passa a reprovar
  quando faltar.
