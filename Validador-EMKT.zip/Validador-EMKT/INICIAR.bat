@echo off
title Validador de pacotes EMKT - Bradesco CRM
cd /d "%~dp0"

where python >nul 2>nul
if errorlevel 1 (
  echo.
  echo  Python nao encontrado nesta maquina.
  echo  Instale em python.org e marque "Add Python to PATH" na instalacao.
  echo.
  pause
  exit /b 1
)

python -c "import flask, bs4, docx" >nul 2>nul
if errorlevel 1 (
  echo.
  echo  Instalando o que falta. So acontece na primeira vez, aguarde...
  echo.
  python -m pip install --quiet -r requirements.txt
  if errorlevel 1 (
    echo.
    echo  Nao consegui instalar. Rode manualmente:
    echo     python -m pip install -r requirements.txt
    echo.
    pause
    exit /b 1
  )
)

python app.py
pause
