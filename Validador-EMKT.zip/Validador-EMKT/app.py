"""
Aplicação web que confere pacotes de campanha antes da publicação.

Verifica três coisas no pacote que o marketing envia:
  1. as imagens seguem a taxonomia da quebra e estão em sequência sem furo;
  2. toda imagem da pasta é chamada no HTML, e todo src do HTML existe na pasta;
  3. o CONTEUDO.docx tem as mesmas palavras da peça, na mesma ordem de leitura,
     incluindo o texto que está dentro dos banners.

SOMENTE LEITURA: o programa abre os arquivos do pacote para conferir e não
altera, move ou apaga nada. Os relatórios são gravados na subpasta
"relatorios" do próprio projeto.

Como executar:
    pip install -r requirements.txt
    python app.py

Depois acesse: http://127.0.0.1:5000
"""

import os
import shutil
import socket
import sys
import tempfile
import uuid

# --- Caminhos absolutos ------------------------------------------------------
# Ancorar tudo no arquivo, e não no diretório de trabalho, é o que faz o app
# subir igual pelo VS Code (que costuma usar a raiz do workspace como cwd),
# pelo duplo clique e pelo Prompt aberto em qualquer lugar.
PASTA_DO_PROJETO = os.path.dirname(os.path.abspath(__file__))
if PASTA_DO_PROJETO not in sys.path:
    sys.path.insert(0, PASTA_DO_PROJETO)

# Aceita "templates" (padrão do Flask) e "template" (nome usado em algumas
# cópias dos projetos do time), para não depender de qual das duas está no disco.
PASTA_TEMPLATES = os.path.join(PASTA_DO_PROJETO, "templates")
if not os.path.isdir(PASTA_TEMPLATES):
    PASTA_TEMPLATES = os.path.join(PASTA_DO_PROJETO, "template")
PASTA_STATIC = os.path.join(PASTA_DO_PROJETO, "static")
PASTA_RELATORIOS = os.path.join(PASTA_DO_PROJETO, "relatorios")


def _erro_de_dependencia(erro: ImportError) -> None:
    """
    Explica o que instalar em vez de despejar um traceback.

    Sem isto, rodar pelo VS Code num interpretador diferente do que recebeu o
    pip install mostra só "ModuleNotFoundError" e não fica claro o que fazer.
    """
    faltando = getattr(erro, "name", None) or str(erro)
    equivalentes = {
        "flask": "flask",
        "bs4": "beautifulsoup4",
        "docx": "python-docx",
        "PIL": "pillow",
    }
    pacote = equivalentes.get(faltando, faltando)
    print("\n" + "=" * 66)
    print("  Falta uma biblioteca para o validador rodar:", faltando)
    print()
    print("  Instale com:")
    print(f"      {sys.executable} -m pip install {pacote}")
    print()
    print("  Ou instale tudo de uma vez:")
    print(f"      {sys.executable} -m pip install -r requirements.txt")
    print()
    print("  Se você instalou e mesmo assim aparece esta mensagem, o VS Code")
    print("  está usando outro Python. Ctrl+Shift+P > 'Python: Select")
    print("  Interpreter' e escolha o mesmo interpretador mostrado acima.")
    print("=" * 66 + "\n")
    sys.exit(1)


try:
    from flask import (Flask, Response, abort, jsonify, render_template, request,
                   send_file, send_from_directory)
    from validador import pacote, relatorio, serializacao
except ImportError as erro:  # pragma: no cover - caminho de diagnóstico
    _erro_de_dependencia(erro)


app = Flask(__name__, template_folder=PASTA_TEMPLATES, static_folder=PASTA_STATIC)
app.config["MAX_CONTENT_LENGTH"] = 300 * 1024 * 1024  # 300 MB por pacote
app.config["JSON_AS_ASCII"] = False

os.makedirs(PASTA_RELATORIOS, exist_ok=True)

# pastas temporárias criadas pelo upload, apagadas quando o programa fecha
_temporarias: list[str] = []

# id do relatório -> caminhos do pacote, para o preview lado a lado.
# Fica em memória de propósito: some quando o programa fecha, junto com as
# pastas temporárias do upload.
_previews: dict[str, dict] = {}


def _conferir(caminho_pasta: str, quebra=None, usar_ocr=True) -> dict:
    resultado = pacote.validar(caminho_pasta, quebra=quebra, usar_ocr=usar_ocr)
    id_relatorio = uuid.uuid4().hex[:12]
    relatorio.gerar(resultado, os.path.join(PASTA_RELATORIOS, f"{id_relatorio}.html"))

    if resultado.caminho_html:
        _previews[id_relatorio] = {
            "raiz": os.path.abspath(os.path.dirname(resultado.caminho_html)),
            "html": os.path.abspath(resultado.caminho_html),
            "paragrafos": (resultado.leitura_conteudo.paragrafos
                           if resultado.leitura_conteudo else []),
        }

    dados = serializacao.para_json(resultado, id_relatorio)
    dados["tem_preview"] = id_relatorio in _previews
    return dados


@app.route("/")
def pagina_inicial():
    return render_template("index.html")


@app.route("/api/conferir-upload", methods=["POST"])
def conferir_upload():
    arquivos = request.files.getlist("arquivos")
    if not arquivos:
        return jsonify({"erro": "Nenhum arquivo recebido."}), 400

    destino = tempfile.mkdtemp(prefix="pacote_emkt_")
    _temporarias.append(destino)

    for arquivo in arquivos:
        # o navegador manda o caminho relativo no lugar do nome, o que preserva
        # a subpasta de imagens
        relativo = (arquivo.filename or "").replace("\\", "/")
        partes = [p for p in relativo.split("/") if p not in ("", ".", "..")]
        if not partes:
            continue
        caminho = os.path.join(destino, *partes)
        os.makedirs(os.path.dirname(caminho), exist_ok=True)
        arquivo.save(caminho)

    # o navegador inclui a pasta raiz; entra nela quando é o único item
    conteudo = os.listdir(destino)
    raiz = destino
    if len(conteudo) == 1 and os.path.isdir(os.path.join(destino, conteudo[0])):
        raiz = os.path.join(destino, conteudo[0])

    usar_ocr = request.form.get("usar_ocr", "true") == "true"
    nome_arrastado = (arquivos[0].filename or "").replace("\\", "/").split("/")[0]

    # O usuário arrasta o que tem na mão: pode ser um pacote ou a pasta que
    # guarda vários. Quem decide é a estrutura, não uma opção na tela.
    pastas = pacote.localizar_pacotes(raiz)
    if not pastas:
        return jsonify({
            "erro": "Não encontrei nenhum pacote aqui. A pasta precisa conter o "
                    "HTML da peça, os docx e as imagens — ou ser a pasta que "
                    "guarda vários pacotes assim."
        }), 400

    try:
        resultados = [_conferir(p, None, usar_ocr) for p in pastas]
    except Exception as e:  # noqa: BLE001
        return jsonify({"erro": f"Falha ao conferir: {e}"}), 500

    em_lote = len(pastas) > 1
    for item in resultados:
        item["em_lote"] = em_lote
        if not em_lote and nome_arrastado:
            # pacote único: o nome que vale é o da pasta que a pessoa arrastou
            item["nome_pasta"] = item.get("nome_pasta") or nome_arrastado

    return jsonify({
        "modo": "lote" if em_lote else "unico",
        "origem": nome_arrastado or "pacote enviado",
        "total": len(resultados),
        "resultados": resultados,
    })


@app.route("/relatorio/<id_relatorio>")
def abrir_relatorio(id_relatorio):
    # o id é gerado por uuid4().hex, então só letras e números são válidos:
    # isso barra qualquer tentativa de subir de pasta pelo endereço
    if not id_relatorio.isalnum():
        return "Identificador inválido.", 400
    caminho = os.path.join(PASTA_RELATORIOS, f"{id_relatorio}.html")
    if not os.path.exists(caminho):
        return "Relatório não encontrado. Refaça a conferência.", 404
    return send_file(caminho)


# ----------------------------------------------------------------- preview

def _preview_ou_404(id_relatorio: str) -> dict:
    if not id_relatorio.isalnum() or id_relatorio not in _previews:
        abort(404)
    return _previews[id_relatorio]


@app.route("/preview/<id_relatorio>/peca")
def preview_peca(id_relatorio):
    """
    Serve o HTML do pacote para o iframe do preview.

    O arquivo chama as imagens por caminho relativo ("imagens/banner_01.png").
    Servido de outro endereço, esses caminhos apontariam para o lugar errado e
    a peça apareceria sem nenhuma imagem. A tag <base> injetada no topo faz
    todos eles caírem na rota que serve os arquivos do pacote.
    """
    preview = _preview_ou_404(id_relatorio)
    try:
        with open(preview["html"], "rb") as arquivo:
            codigo = arquivo.read().decode("utf-8", errors="replace")
    except OSError:
        abort(404)

    base = f'<base href="/preview/{id_relatorio}/arquivo/">'
    minusculo = codigo.lower()
    posicao = minusculo.find("<head")
    if posicao >= 0:
        fim = codigo.find(">", posicao)
        codigo = codigo[:fim + 1] + base + codigo[fim + 1:]
    else:
        codigo = base + codigo

    return Response(codigo, mimetype="text/html; charset=utf-8")


@app.route("/preview/<id_relatorio>/arquivo/<path:relativo>")
def preview_arquivo(id_relatorio, relativo):
    """
    Serve as imagens que a peça referencia.

    send_from_directory resolve o caminho dentro da raiz e recusa qualquer
    tentativa de subir de pasta pelo endereço — sem isso, o navegador poderia
    pedir ../../ e ler arquivo fora do pacote.
    """
    preview = _preview_ou_404(id_relatorio)
    try:
        return send_from_directory(preview["raiz"], relativo)
    except Exception:
        abort(404)


@app.route("/api/preview/<id_relatorio>/conteudo")
def preview_conteudo(id_relatorio):
    """Parágrafos do docx, na ordem, para a coluna de texto."""
    return jsonify({"paragrafos": _preview_ou_404(id_relatorio)["paragrafos"]})


@app.route("/api/status-ocr")
def status_ocr():
    from validador.ocr import (diagnosticar, idiomas_instalados, motor_ativo,
                               ocr_disponivel)

    disponivel, motivo = ocr_disponivel()
    ativo = motor_ativo()
    idiomas = idiomas_instalados()
    return jsonify({
        "disponivel": disponivel,
        "motivo": motivo,
        "motor": ativo.nome if ativo else "",
        "descricao": ativo.descricao if ativo else "",
        "motores": diagnosticar(),
        "idiomas": idiomas,
        "portugues": "por" in idiomas,
    })


def _porta_livre(porta: int) -> bool:
    # sem SO_REUSEADDR de propósito: o teste precisa falhar exatamente onde o
    # servidor falharia, senão ele diria "livre" numa porta já em uso
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as teste:
        try:
            teste.bind(("127.0.0.1", porta))
            return True
        except OSError:
            return False


def _escolher_porta(preferida: int = 5000) -> int:
    """
    Deixar o programa aberto numa janela e rodar de novo trava a porta 5000.
    Em vez de morrer com "address already in use", sobe na porta seguinte.
    """
    for porta in range(preferida, preferida + 12):
        if _porta_livre(porta):
            return porta
    return preferida


def limpar_temporarias():
    for pasta in _temporarias:
        shutil.rmtree(pasta, ignore_errors=True)


if __name__ == "__main__":
    import atexit

    atexit.register(limpar_temporarias)

    porta = int(os.environ.get("PORTA") or _escolher_porta())
    endereco = f"http://127.0.0.1:{porta}"

    # O navegador só é aberto no processo principal. Com o reloader ligado o
    # Flask sobe dois processos, e sem esta guarda abriam duas abas.
    if not os.environ.get("WERKZEUG_RUN_MAIN") and os.environ.get("ABRIR_NAVEGADOR", "1") != "0":
        import threading
        import webbrowser

        # webbrowser pode falhar em terminal sem sessão gráfica: se falhar, o
        # endereço continua impresso abaixo e dá para abrir na mão.
        threading.Timer(1.2, lambda: webbrowser.open(endereco)).start()

    print("\n" + "=" * 66)
    print("  Validador de pacotes EMKT · Bradesco CRM")
    print(f"  Abra no navegador: {endereco}")
    if porta != 5000:
        print("  (a porta 5000 estava ocupada, então subi nesta aqui)")
    print("  Para encerrar: Ctrl+C aqui, ou feche esta janela.")
    print("=" * 66 + "\n")

    # host='127.0.0.1' = acessível apenas nesta máquina (recomendado).
    # debug=False de propósito: o debugger do Flask abre um console Python no
    # navegador, e isso não deve existir numa ferramenta que lê pasta de rede.
    app.run(host="127.0.0.1", port=porta, debug=False)
