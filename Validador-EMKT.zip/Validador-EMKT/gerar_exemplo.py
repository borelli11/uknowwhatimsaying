"""
Gera dois pacotes de e-mail marketing para testar o validador.

  PACOTE_APROVADO  — tudo correto, deve sair APROVADO
  PACOTE_ERROS     — sete erros plantados, deve sair REPROVADO

Marca fictícia (Banco Exemplo) de propósito: é material de teste, não pode ser
confundido com peça real em produção.
"""

import os
import shutil

from docx import Document
from PIL import Image, ImageDraw, ImageFont

QUEBRA = "emkt_consignado_pf_setembro"
LARGURA = 900

CORES = {
    "marca": (204, 9, 47),
    "escuro": (28, 31, 35),
    "claro": (255, 255, 255),
    "fundo": (246, 247, 249),
}


def fonte(tamanho, negrito=True):
    caminhos = [
        "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf" if negrito
        else "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
        "C:/Windows/Fonts/arialbd.ttf" if negrito else "C:/Windows/Fonts/arial.ttf",
    ]
    for caminho in caminhos:
        if os.path.exists(caminho):
            return ImageFont.truetype(caminho, tamanho)
    return ImageFont.load_default()


def desenhar(caminho, altura, fundo, linhas, cor_texto, alinhamento="left"):
    """linhas = [(texto, tamanho_da_fonte, negrito)]"""
    img = Image.new("RGB", (LARGURA, altura), fundo)
    d = ImageDraw.Draw(img)

    altura_total = sum(t + 18 for _, t, _ in linhas) - 18
    y = (altura - altura_total) // 2

    for texto, tamanho, negrito in linhas:
        f = fonte(tamanho, negrito)
        largura_texto = d.textlength(texto, font=f)
        x = (LARGURA - largura_texto) / 2 if alinhamento == "center" else 60
        d.text((x, y), texto, fill=cor_texto, font=f)
        y += tamanho + 18

    img.save(caminho)


def gerar_imagens(pasta, prefixo=QUEBRA, com_erro=False):
    os.makedirs(pasta, exist_ok=True)

    # 01 — cabeçalho
    desenhar(
        os.path.join(pasta, f"{prefixo}_01.png"), 190, CORES["marca"],
        [("Banco Exemplo", 40, True),
         ("Credito Consignado", 30, False)],
        CORES["claro"], "center",
    )

    # 02 — oferta principal
    desenhar(
        os.path.join(pasta, f"{prefixo}_02.png"), 300, CORES["claro"],
        [("Ola, seu consignado esta liberado", 34, True),
         ("Ate R$ 50.000,00 na sua conta", 40, True),
         ("Taxa a partir de 1,29% ao mes", 28, False)],
        CORES["escuro"],
    )

    # 03 — condições
    numero_parcelas = "72" if not com_erro else "72"
    desenhar(
        os.path.join(pasta, f"{prefixo}_03.png"), 240, CORES["fundo"],
        [("Parcelas em ate " + numero_parcelas + " meses", 32, True),
         ("Sem consulta ao SPC e Serasa", 26, False),
         ("Dinheiro na conta em ate 1 dia util", 26, False)],
        CORES["escuro"],
    )

    # 04 — botão animado. GIF de propósito: é comum a peça trazer texto só
    # dentro da animação, e o validador precisa ler frame a frame.
    quadros = []
    for texto in ("Simular agora", "Leva 2 minutos", "Simular agora"):
        quadro = Image.new("RGB", (LARGURA, 130), CORES["marca"])
        desenho = ImageDraw.Draw(quadro)
        f = fonte(34, True)
        largura_texto = desenho.textlength(texto, font=f)
        desenho.text(((LARGURA - largura_texto) / 2, 45), texto,
                     fill=CORES["claro"], font=f)
        quadros.append(quadro)
    quadros[0].save(os.path.join(pasta, f"{prefixo}_04.gif"), save_all=True,
                    append_images=quadros[1:], duration=900, loop=0)

    # 05 — rodapé
    desenhar(
        os.path.join(pasta, f"{prefixo}_05.png"), 170, CORES["fundo"],
        [("Central de Atendimento 4002 0022", 24, False),
         ("Ouvidoria 0800 727 9933", 24, False),
         ("Banco Exemplo S.A. CNPJ 00.000.000/0001-00", 20, False)],
        CORES["escuro"], "center",
    )


ASSUNTO_OK = "Seu consignado esta liberado"          # 27 caracteres
PRE_HEADER_OK = "Simule agora e veja seu limite."     # 31, com ponto final

ASSUNTO_LONGO = "Seu credito consignado pre-aprovado ja esta liberado para contratacao"
PRE_HEADER_SEM_PONTO = "Confira as condicoes especiais do seu credito pre-aprovado"

HTML = """<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Banco Exemplo - Credito Consignado</title>
  <style>
    body {{ margin:0; padding:0; background:#eeeeee; font-family: Arial, Helvetica, sans-serif; }}
    img {{ display:block; border:0; }}
  </style>
</head>
<body>
  <div style="display:none; font-size:0; max-height:0; overflow:hidden;">
    {pre_header}
  </div>

  <table width="100%" cellpadding="0" cellspacing="0" border="0">
    <tr><td align="center" style="padding:14px 10px; font-size:12px; color:#555555;">
      Se nao conseguiu visualizar esta mensagem, clique aqui para ver no navegador.
    </td></tr>

    <tr><td align="center">
      <table width="{largura}" cellpadding="0" cellspacing="0" border="0" style="background:#ffffff;">

        <tr><td>
          <img src="imagens/{q}_01.png" width="{largura}" alt="Banco Exemplo - Credito Consignado">
        </td></tr>

        <tr><td>
          <img src="imagens/{q}_02.png" width="{largura}" alt="Seu consignado esta liberado, ate R$ 50.000,00 na sua conta, taxa a partir de 1,29% ao mes">
        </td></tr>

        <tr><td style="padding:26px 60px; font-size:16px; line-height:26px; color:#1c1f23;">
          Voce tem uma proposta de credito consignado disponivel para contratacao.
          A simulacao leva menos de dois minutos e nao compromete seu limite.
        </td></tr>

        <tr><td>
          <img src="imagens/{q}_03.png" width="{largura}" alt="Parcelas em ate 72 meses, sem consulta ao SPC e Serasa, dinheiro na conta em ate 1 dia util">
        </td></tr>

        <tr><td align="center" style="padding:22px 0;">
          <a href="https://exemplo.com.br/redirect?cpi=CONSIGNADO_PF_SET&url=simulador">
            <img src="imagens/{q}_04.gif" width="{largura}" alt="Simular agora">
          </a>
        </td></tr>

        <tr><td style="padding:0 60px 26px; font-size:13px; line-height:22px; color:#5b6570;">
          Sujeito a analise e aprovacao de credito. Consulte as condicoes,
          taxas e o Custo Efetivo Total no momento da contratacao.
          Imagens meramente ilustrativas.
        </td></tr>

        <tr><td>
          <img src="imagens/{q}_05.png" width="{largura}" alt="Central de Atendimento 4002 0022, Ouvidoria 0800 727 9933">
        </td></tr>

        <tr><td align="center" style="padding:20px 40px 34px; font-size:12px; line-height:20px; color:#5b6570;">
          Se nao deseja mais receber nossos e-mails, clique aqui para descadastrar.
        </td></tr>

      </table>
    </td></tr>
  </table>
</body>
</html>"""

# ordem de leitura: texto das imagens intercalado com o texto vivo
CONTEUDO = [
    "Banco Exemplo",
    "Credito Consignado",
    "Ola, seu consignado esta liberado",
    "Ate R$ 50.000,00 na sua conta",
    "Taxa a partir de 1,29% ao mes",
    "Voce tem uma proposta de credito consignado disponivel para contratacao. "
    "A simulacao leva menos de dois minutos e nao compromete seu limite.",
    "Parcelas em ate 72 meses",
    "Sem consulta ao SPC e Serasa",
    "Dinheiro na conta em ate 1 dia util",
    "Simular agora",
    "Leva 2 minutos",
    "Sujeito a analise e aprovacao de credito. Consulte as condicoes, taxas e o "
    "Custo Efetivo Total no momento da contratacao. Imagens meramente ilustrativas.",
    "Central de Atendimento 4002 0022",
    "Ouvidoria 0800 727 9933",
    "Banco Exemplo S.A. CNPJ 00.000.000/0001-00",
    "Se nao deseja mais receber nossos e-mails, clique aqui para descadastrar.",
]


def salvar_docx(caminho, linhas):
    d = Document()
    for linha in linhas:
        d.add_paragraph(linha)
    d.save(caminho)


def salvar_assunto(caminho, assunto=ASSUNTO_OK, pre_header=PRE_HEADER_OK):
    d = Document()
    d.add_paragraph(f"Assunto: {assunto}")
    d.add_paragraph(f"Pré-header: {pre_header}")
    d.save(caminho)


def montar_aprovado(destino):
    pasta = os.path.join(destino, "PACOTE_APROVADO")
    os.makedirs(pasta, exist_ok=True)
    gerar_imagens(os.path.join(pasta, "imagens"))
    with open(os.path.join(pasta, "index.html"), "w", encoding="utf-8") as f:
        f.write(HTML.format(q=QUEBRA, largura=LARGURA, pre_header=PRE_HEADER_OK))
    salvar_docx(os.path.join(pasta, "CONTEUDO.docx"), CONTEUDO)
    salvar_assunto(os.path.join(pasta, "ASSUNTO_PREHEADER.docx"))
    return pasta


def montar_com_erros(destino):
    """
    Erros plantados:
      1. imagem 03 renomeada para 3 sem zero à esquerda -> furo na sequência
      2. imagem 06 na pasta que o HTML não chama
      3. arquivo 'banner_extra.png' fora da taxonomia
      4. HTML chama a imagem 07, que não existe na pasta
      5. docx diz 60 meses; o banner diz 72  -> texto trocado dentro da imagem
      6. bloco de disclaimer removido do docx -> conteúdo obrigatório ausente
      7. dois parágrafos invertidos no docx   -> fora de ordem
      8. nenhum redirect no HTML              -> bloqueia a publicação
      9. pré-header sem ponto final           -> bloqueia a publicação
     10. assunto e pré-header longos          -> alerta
     11. uma imagem acima de 1 MB             -> apontamento
    """
    pasta = os.path.join(destino, "PACOTE_ERROS")
    os.makedirs(pasta, exist_ok=True)
    pasta_imagens = os.path.join(pasta, "imagens")
    gerar_imagens(pasta_imagens)

    # 1. quebra a numeração
    os.rename(os.path.join(pasta_imagens, f"{QUEBRA}_03.png"),
              os.path.join(pasta_imagens, f"{QUEBRA}_3.png"))
    # 2. imagem órfã
    shutil.copy(os.path.join(pasta_imagens, f"{QUEBRA}_01.png"),
                os.path.join(pasta_imagens, f"{QUEBRA}_06.png"))
    # 3. fora da taxonomia
    shutil.copy(os.path.join(pasta_imagens, f"{QUEBRA}_01.png"),
                os.path.join(pasta_imagens, "banner_extra.png"))

    html = HTML.format(q=QUEBRA, largura=LARGURA, pre_header=PRE_HEADER_SEM_PONTO)
    # 4. chamada para arquivo inexistente
    html = html.replace(f"{QUEBRA}_05.png", f"{QUEBRA}_07.png")
    # 8. sem redirect
    html = html.replace("/redirect?cpi=", "/ir?cpi=")

    # 11. imagem acima do limite de peso
    pesada = Image.new("RGB", (2400, 1600))
    ruido = pesada.load()
    for x in range(0, 2400, 3):
        for y in range(0, 1600, 3):
            ruido[x, y] = ((x * 7) % 256, (y * 11) % 256, ((x + y) * 13) % 256)
    pesada.save(os.path.join(pasta_imagens, f"{QUEBRA}_02.png"), compress_level=0)
    with open(os.path.join(pasta, "index.html"), "w", encoding="utf-8") as f:
        f.write(html)

    conteudo = list(CONTEUDO)
    # 5. valor divergente
    conteudo[6] = "Parcelas em ate 60 meses"
    # 6. disclaimer fora do docx
    conteudo.pop(10)
    # 7. inversão de ordem
    conteudo[1], conteudo[2] = conteudo[2], conteudo[1]

    salvar_docx(os.path.join(pasta, "CONTEUDO.docx"), conteudo)
    # 9 e 10
    salvar_assunto(os.path.join(pasta, "ASSUNTO_PREHEADER.docx"),
                   ASSUNTO_LONGO, PRE_HEADER_SEM_PONTO)
    return pasta


if __name__ == "__main__":
    destino = os.path.join(os.path.dirname(os.path.abspath(__file__)), "_exemplo-teste")
    os.makedirs(destino, exist_ok=True)
    print("gerado:", montar_aprovado(destino))
    print("gerado:", montar_com_erros(destino))
