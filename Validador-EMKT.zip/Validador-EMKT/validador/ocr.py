"""
Leitura do texto contido nas imagens.

Três motores, testados em cascata. O sistema usa o primeiro que estiver
disponível na máquina, sem você precisar configurar nada:

  1. windows   — OCR nativo do Windows 10/11. Não instala binário nenhum:
                 o motor já faz parte do sistema operacional e o idioma
                 português normalmente já vem junto. Só precisa do pacote
                 Python `winocr`. É o caminho de menor atrito em máquina
                 corporativa, porque não há software novo para homologar.

  2. rapidocr  — modelos ONNX que vêm dentro do próprio pacote pip (~16 MB).
                 Roda offline depois de instalado, não precisa de binário
                 externo nem de privilégio de administrador. É o plano B
                 quando o item 1 não estiver disponível.

  3. tesseract — o mais conhecido, mas exige instalar um programa separado.
                 Aceita também versão portátil: aponte a variável de ambiente
                 TESSERACT_CMD para o executável e não precisa de instalador.

Para forçar um motor específico, defina a variável OCR_MOTOR com "windows",
"rapidocr" ou "tesseract".
"""

import os
import re
from dataclasses import dataclass, field

from .normalizacao import limpar


@dataclass
class ResultadoOCR:
    arquivo: str
    texto: str = ""
    lido: bool = False
    erro: str = ""
    aviso: str = ""
    motor: str = ""
    confianca_media: float = 0.0
    linhas: list[str] = field(default_factory=list)


# ---------------------------------------------------------------- utilidades

def _preparar(caminho: str, largura_minima: int = 1000):
    """Abre a imagem e melhora o que dá antes de mandar para o motor."""
    from PIL import Image, ImageOps

    img = Image.open(caminho)
    img = ImageOps.exif_transpose(img)
    if img.mode not in ("L", "RGB"):
        img = img.convert("RGB")
    if img.width < largura_minima:
        fator = largura_minima / img.width
        # LANCZOS de propósito: o padrão do resize borra a borda das letras e o
        # motor passa a inventar caractere — "Simular agora" virava "Simular a
        # agora" num upscale de apenas 1,1x.
        img = img.resize(
            (int(img.width * fator), int(img.height * fator)), Image.LANCZOS
        )
    return img


MAXIMO_FRAMES_LIDOS = 10
# Fração mínima de pixels que precisa mudar para o frame contar como cena nova.
# Média de diferença não serve aqui: em banner de fundo claro, trocar a frase
# inteira mexe em poucos por cento dos pixels e a média mal se move.
MUDANCA_MINIMA_ENTRE_FRAMES = 0.01   # 1% dos pixels
DIFERENCA_POR_PIXEL = 40             # 0-255: o quanto um pixel precisa mudar


def _assinatura(imagem):
    """Miniatura em cinza usada só para comparar frames entre si."""
    from PIL import Image
    return list(imagem.convert("L").resize((64, 64), Image.BILINEAR).getdata())


def _frames_relevantes(caminho: str) -> list:
    """
    Escolhe quais frames de um GIF vale a pena ler.

    Um GIF de peça costuma ter dezenas de frames para poucas cenas de texto:
    ler todos custaria mais de um minuto por imagem sem acrescentar nada. Aqui
    só entram os frames que mudaram de verdade em relação ao último lido, e no
    máximo dez — o suficiente para pegar todas as cenas de uma peça de e-mail.
    """
    from PIL import Image, ImageSequence

    imagem = Image.open(caminho)
    total = getattr(imagem, "n_frames", 1)
    if total <= 1:
        return [imagem.convert("RGB")]

    escolhidos, ultima = [], None
    for quadro in ImageSequence.Iterator(imagem):
        atual = quadro.convert("RGB")
        assinatura = _assinatura(atual)
        if ultima is not None:
            mudados = sum(
                1 for a, b in zip(assinatura, ultima)
                if abs(a - b) > DIFERENCA_POR_PIXEL
            )
            if mudados / len(assinatura) < MUDANCA_MINIMA_ENTRE_FRAMES:
                continue
        escolhidos.append(atual.copy())
        ultima = assinatura
        if len(escolhidos) >= MAXIMO_FRAMES_LIDOS:
            break
    return escolhidos or [imagem.convert("RGB")]


def _juntar_textos(blocos: list[str]) -> str:
    """
    Junta o texto das cenas do GIF sem repetir o que já apareceu.

    Frames vizinhos costumam compartilhar a mesma frase; repetir isso na fita
    de leitura criaria divergência falsa contra o docx.
    """
    from .normalizacao import tokenizar

    vistos, saida = set(), []
    for bloco in blocos:
        for linha in bloco.splitlines():
            chave = " ".join(tokenizar(linha))
            if not chave or chave in vistos:
                continue
            vistos.add(chave)
            saida.append(linha.strip())
    return "\n".join(saida)


def _ordenar_linhas(itens: list[dict]) -> list[str]:
    """
    Reconstrói a ordem visual de leitura: de cima para baixo, da esquerda para
    a direita.

    Os motores devolvem caixas soltas, e duas palavras da mesma linha vêm
    separadas. Agrupar por faixa de altura fixa não funciona — título grande e
    rodapé miúdo precisam de tolerâncias diferentes. Aqui duas caixas entram na
    mesma linha quando se sobrepõem verticalmente em mais da metade da altura
    da menor delas, que é o critério que uma pessoa usaria olhando a peça.
    """
    validos = [i for i in itens if i["texto"].strip()]
    if not validos:
        return []

    for item in validos:
        item.setdefault("base", item["topo"] + item.get("altura", 10))
        item.setdefault("direita", item["esquerda"])

    validos.sort(key=lambda r: (r["topo"], r["esquerda"]))

    linhas: list[list[dict]] = []
    for item in validos:
        encaixou = False
        # Chamada de nota é uma caixa minúscula e assentada acima da linha:
        # ela mal encosta no texto ao lado. Com o mesmo critério das palavras
        # normais ela virava uma linha só dela, e o "2" de "36x²" acabava
        # solto, longe da palavra a que pertence.
        curta = len(item["texto"].strip()) <= 2
        for linha in linhas:
            topo_linha = min(c["topo"] for c in linha)
            base_linha = max(c["base"] for c in linha)
            sobreposicao = min(base_linha, item["base"]) - max(topo_linha, item["topo"])
            menor_altura = min(base_linha - topo_linha, item["base"] - item["topo"])
            # A ordenação é por topo, e a chamada de nota fica ACIMA da linha:
            # ela chega primeiro e vira âncora. Por isso o limiar reduzido vale
            # também quando é a linha existente que é só a marca de nota.
            linha_curta = all(len(c["texto"].strip()) <= 2 for c in linha)
            limiar = 0.15 if (curta or linha_curta) else 0.5
            if menor_altura > 0 and sobreposicao > menor_altura * limiar:
                linha.append(item)
                encaixou = True
                break
        if not encaixou:
            linhas.append([item])

    linhas.sort(key=lambda l: min(c["topo"] for c in l))
    saida = []
    for linha in linhas:
        linha.sort(key=lambda c: c["esquerda"])
        saida.append(_montar_linha(linha))
    return saida


RE_CHAMADA_DE_NOTA = re.compile(r"^[0-9]{1,2}$|^\*{1,3}$")


def _montar_linha(caixas: list[dict]) -> str:
    """
    Junta as caixas de uma linha, colando a chamada de nota na palavra anterior.

    O motor devolve o "2" de "CDB²" como uma caixa separada, e juntar tudo com
    espaço produziria "CDB 2". O docx traz "CDB2", porque o Word cola o
    sobrescrito — a diferença viraria apontamento em toda peça com nota de
    rodapé, que em banco é praticamente toda peça.

    O que identifica a chamada: texto de um ou dois dígitos (ou asterisco),
    caixa visivelmente menor que a anterior e assentada mais alto que ela.
    """
    partes = []
    anterior = None
    for caixa in caixas:
        texto = caixa["texto"].strip()
        if not texto:
            continue
        colar = False
        if anterior is not None and RE_CHAMADA_DE_NOTA.match(texto):
            altura = caixa["base"] - caixa["topo"]
            altura_anterior = anterior["base"] - anterior["topo"]
            distancia = caixa["esquerda"] - anterior.get("direita", anterior["esquerda"])
            mais_alta = caixa["topo"] < anterior["topo"]
            menor = altura_anterior > 0 and altura < altura_anterior * 0.8
            perto = distancia < altura_anterior * 0.8
            colar = menor and mais_alta and perto
        partes.append(("" if colar else " ") + texto if partes else texto)
        anterior = caixa
    return "".join(partes)


# ------------------------------------------------------------------- motores

class MotorBase:
    nome = ""
    descricao = ""

    def disponivel(self) -> tuple[bool, str]:
        raise NotImplementedError

    def ler(self, caminho: str, idioma: str, confianca_minima: int) -> ResultadoOCR:
        raise NotImplementedError


class MotorWindows(MotorBase):
    """OCR embutido no Windows. Nenhum programa novo para instalar."""

    nome = "windows"
    descricao = "OCR nativo do Windows"

    def disponivel(self):
        if os.name != "nt":
            return False, "só funciona no Windows"
        try:
            import winocr  # noqa: F401
        except ImportError:
            return False, "falta o pacote Python: pip install winocr"
        return True, "ok"

    def ler(self, caminho, idioma="por", confianca_minima=40):
        import winocr

        nome_arquivo = os.path.basename(caminho)
        # o Windows usa código de idioma BCP-47
        tag = {"por": "pt-BR", "eng": "en-US"}.get(idioma, idioma)
        try:
            img = _preparar(caminho)
            try:
                resultado = winocr.recognize_pil_sync(img, tag)
            except Exception:
                # idioma não instalado no Windows: cai para o padrão do sistema
                resultado = winocr.recognize_pil_sync(img)
        except Exception as e:
            return ResultadoOCR(arquivo=nome_arquivo, erro=str(e), motor=self.nome)

        linhas_brutas = resultado.get("lines") if isinstance(resultado, dict) else \
            getattr(resultado, "lines", None)

        itens = []
        for linha in (linhas_brutas or []):
            if isinstance(linha, dict):
                texto = linha.get("text", "")
                palavras = linha.get("words", []) or []
                caixa = palavras[0].get("bounding_rect", {}) if palavras else {}
                topo, esquerda = caixa.get("y", 0), caixa.get("x", 0)
                altura = caixa.get("height", 10)
            else:
                texto = getattr(linha, "text", "") or ""
                palavras = getattr(linha, "words", []) or []
                topo = esquerda = 0
                altura = 10
                largura = 10
                if palavras:
                    caixa = getattr(palavras[0], "bounding_rect", None)
                    if caixa is not None:
                        topo = getattr(caixa, "y", 0)
                        esquerda = getattr(caixa, "x", 0)
                        altura = getattr(caixa, "height", 10)
            itens.append({"texto": texto, "topo": topo, "esquerda": esquerda,
                          "base": topo + altura, "direita": esquerda + 200})

        linhas = _ordenar_linhas(itens)
        return ResultadoOCR(
            arquivo=nome_arquivo, texto=limpar("\n".join(linhas)),
            lido=True, linhas=linhas, motor=self.nome,
        )


class MotorRapidOCR(MotorBase):
    """Modelos ONNX que vêm no próprio pacote pip. Offline, sem binário."""

    nome = "rapidocr"
    descricao = "RapidOCR (modelos embutidos, sem instalar programa)"
    _motor = None

    def disponivel(self):
        try:
            import rapidocr_onnxruntime  # noqa: F401
        except ImportError:
            return False, "falta o pacote Python: pip install rapidocr-onnxruntime"
        return True, "ok"

    def _obter(self):
        if MotorRapidOCR._motor is None:
            from rapidocr_onnxruntime import RapidOCR
            MotorRapidOCR._motor = RapidOCR()
        return MotorRapidOCR._motor

    def ler(self, caminho, idioma="por", confianca_minima=40):
        import numpy as np

        nome_arquivo = os.path.basename(caminho)
        try:
            img = _preparar(caminho).convert("RGB")
            saida, _ = self._obter()(np.array(img))
        except Exception as e:
            return ResultadoOCR(arquivo=nome_arquivo, erro=str(e), motor=self.nome)

        if not saida:
            return ResultadoOCR(arquivo=nome_arquivo, lido=True, motor=self.nome)

        limite = confianca_minima / 100
        itens, confiancas = [], []
        for caixa, texto, confianca in saida:
            if confianca < limite:
                continue
            pontos = list(caixa)
            itens.append({
                "texto": texto,
                "topo": min(p[1] for p in pontos),
                "base": max(p[1] for p in pontos),
                "esquerda": min(p[0] for p in pontos),
                "direita": max(p[0] for p in pontos),
            })
            confiancas.append(confianca * 100)

        linhas = _ordenar_linhas(itens)
        return ResultadoOCR(
            arquivo=nome_arquivo, texto=limpar("\n".join(linhas)),
            lido=True, linhas=linhas, motor=self.nome,
            confianca_media=round(sum(confiancas) / len(confiancas), 1) if confiancas else 0.0,
        )


class MotorTesseract(MotorBase):
    """Tesseract. Aceita instalação normal ou versão portátil via TESSERACT_CMD."""

    nome = "tesseract"
    descricao = "Tesseract"

    def disponivel(self):
        try:
            import pytesseract
        except ImportError:
            return False, "falta o pacote Python: pip install pytesseract"
        if os.environ.get("TESSERACT_CMD"):
            pytesseract.pytesseract.tesseract_cmd = os.environ["TESSERACT_CMD"]
        try:
            pytesseract.get_tesseract_version()
        except Exception:
            return False, "o programa Tesseract não foi encontrado na máquina"
        return True, "ok"

    def idiomas(self):
        try:
            import pytesseract
            return list(pytesseract.get_languages(config=""))
        except Exception:
            return []

    def ler(self, caminho, idioma="por", confianca_minima=40):
        import pytesseract
        from PIL import ImageOps

        nome_arquivo = os.path.basename(caminho)
        aviso = ""
        disponiveis = self.idiomas()
        if disponiveis and idioma not in disponiveis:
            if "eng" in disponiveis:
                aviso = (f"idioma '{idioma}' não instalado no Tesseract; usando 'eng'. "
                         "Acentos saem imprecisos.")
                idioma = "eng"
            else:
                idioma = disponiveis[0]

        try:
            img = ImageOps.autocontrast(ImageOps.grayscale(_preparar(caminho)))
            dados = pytesseract.image_to_data(
                img, lang=idioma, output_type=pytesseract.Output.DICT, config="--psm 6"
            )
        except Exception as e:
            return ResultadoOCR(arquivo=nome_arquivo, erro=str(e), motor=self.nome)

        agrupadas: dict[tuple, dict] = {}
        confiancas = []
        for i, palavra in enumerate(dados["text"]):
            palavra = palavra.strip()
            if not palavra:
                continue
            try:
                confianca = float(dados["conf"][i])
            except (ValueError, TypeError):
                confianca = -1
            if confianca < confianca_minima:
                continue
            chave = (dados["block_num"][i], dados["par_num"][i], dados["line_num"][i])
            registro = agrupadas.setdefault(chave, {
                "texto": "", "topo": dados["top"][i], "esquerda": dados["left"][i],
                "base": dados["top"][i] + dados["height"][i],
                "direita": dados["left"][i] + dados["width"][i],
            })
            registro["texto"] = (registro["texto"] + " " + palavra).strip()
            registro["esquerda"] = min(registro["esquerda"], dados["left"][i])
            registro["base"] = max(registro["base"], dados["top"][i] + dados["height"][i])
            registro["direita"] = max(registro["direita"],
                                      dados["left"][i] + dados["width"][i])
            confiancas.append(confianca)

        linhas = _ordenar_linhas(list(agrupadas.values()))
        return ResultadoOCR(
            arquivo=nome_arquivo, texto=limpar("\n".join(linhas)),
            lido=True, linhas=linhas, motor=self.nome, aviso=aviso,
            confianca_media=round(sum(confiancas) / len(confiancas), 1) if confiancas else 0.0,
        )


MOTORES = [MotorWindows(), MotorRapidOCR(), MotorTesseract()]
_ESCOLHIDO = None
_DIAGNOSTICO = None


def diagnosticar() -> list[dict]:
    """Estado de cada motor, para a tela mostrar o que falta instalar."""
    global _DIAGNOSTICO
    if _DIAGNOSTICO is None:
        _DIAGNOSTICO = []
        for motor in MOTORES:
            ok, motivo = motor.disponivel()
            _DIAGNOSTICO.append({
                "nome": motor.nome, "descricao": motor.descricao,
                "disponivel": ok, "motivo": motivo,
            })
    return _DIAGNOSTICO


def motor_ativo():
    """Escolhe o motor: o forçado por variável de ambiente, ou o primeiro que houver."""
    global _ESCOLHIDO
    if _ESCOLHIDO is not None:
        return _ESCOLHIDO or None

    forcado = (os.environ.get("OCR_MOTOR") or "").strip().lower()
    candidatos = [m for m in MOTORES if m.nome == forcado] if forcado else MOTORES

    for motor in candidatos:
        ok, _ = motor.disponivel()
        if ok:
            _ESCOLHIDO = motor
            return motor
    _ESCOLHIDO = False
    return None


def ocr_disponivel() -> tuple[bool, str]:
    motor = motor_ativo()
    if motor:
        return True, f"{motor.descricao} ativo"
    faltas = "; ".join(f"{d['nome']}: {d['motivo']}" for d in diagnosticar())
    return False, f"nenhum motor de leitura disponível ({faltas})"


def idiomas_instalados() -> list[str]:
    motor = motor_ativo()
    if isinstance(motor, MotorTesseract):
        return motor.idiomas()
    if motor:
        return ["por"]  # Windows e RapidOCR cobrem o alfabeto latino
    return []


def _e_gif_animado(caminho: str) -> bool:
    if not caminho.lower().endswith(".gif"):
        return False
    try:
        from PIL import Image
        with Image.open(caminho) as imagem:
            return getattr(imagem, "n_frames", 1) > 1
    except Exception:
        return False


def ler_imagem(caminho: str, idioma: str = "por",
               confianca_minima: int = 40) -> ResultadoOCR:
    motor = motor_ativo()
    nome = os.path.basename(caminho)
    if not motor:
        return ResultadoOCR(arquivo=nome, erro=ocr_disponivel()[1])

    if not _e_gif_animado(caminho):
        return motor.ler(caminho, idioma, confianca_minima)

    # GIF animado: cada cena pode trazer texto próprio, e é comum a oferta
    # inteira estar espalhada entre os frames.
    import tempfile

    textos, confiancas, frames_lidos = [], [], 0
    try:
        quadros = _frames_relevantes(caminho)
    except Exception as e:
        return ResultadoOCR(arquivo=nome, erro=f"não consegui abrir o GIF: {e}",
                            motor=motor.nome)

    with tempfile.TemporaryDirectory(prefix="frames_") as pasta:
        for indice, quadro in enumerate(quadros):
            destino = os.path.join(pasta, f"frame_{indice:02d}.png")
            try:
                quadro.save(destino)
            except Exception:
                continue
            parcial = motor.ler(destino, idioma, confianca_minima)
            if parcial.texto:
                textos.append(parcial.texto)
                frames_lidos += 1
            if parcial.confianca_media:
                confiancas.append(parcial.confianca_media)

    texto = _juntar_textos(textos)
    return ResultadoOCR(
        arquivo=nome, texto=texto, lido=True, motor=motor.nome,
        linhas=texto.splitlines(),
        confianca_media=round(sum(confiancas) / len(confiancas), 1) if confiancas else 0.0,
        aviso=(f"GIF animado: {frames_lidos} cena(s) lida(s) de "
               f"{len(quadros)} frame(s) distintos"),
    )


class CacheOCR:
    """A mesma imagem pode aparecer várias vezes no HTML. Lê uma vez, reaproveita."""

    def __init__(self, idioma: str = "por", confianca_minima: int = 40):
        self.idioma = idioma
        self.confianca_minima = confianca_minima
        self.aviso_idioma = ""
        self._cache: dict[str, ResultadoOCR] = {}

    def ler(self, caminho: str) -> ResultadoOCR:
        chave = os.path.normcase(os.path.abspath(caminho))
        if chave not in self._cache:
            resultado = ler_imagem(caminho, self.idioma, self.confianca_minima)
            if resultado.aviso and not self.aviso_idioma:
                self.aviso_idioma = resultado.aviso
            self._cache[chave] = resultado
        return self._cache[chave]

    @property
    def lidas(self) -> int:
        return sum(1 for r in self._cache.values() if r.lido)
