"""
Leitura dos .docx do pacote.

Dois papéis diferentes:
  CONTEUDO.docx  -> todo o texto legível da peça, na ordem de leitura
  ASSUNTO.docx   -> assunto e pré-header

A identificação é por nome de arquivo, com heurística por conteúdo quando o
analista nomeia fora do padrão.
"""

import os
import re
from dataclasses import dataclass, field

from .normalizacao import limpar

RE_ASSUNTO = re.compile(r"assunto|subject|pre.?header|preheader", re.IGNORECASE)
RE_CONTEUDO = re.compile(r"conte.?do|content|texto|alt", re.IGNORECASE)


@dataclass
class LeituraDocx:
    caminho: str
    papel: str = "indefinido"       # "conteudo" | "assunto" | "indefinido"
    paragrafos: list[str] = field(default_factory=list)
    assunto: str = ""
    pre_header: str = ""
    erros: list[str] = field(default_factory=list)

    def texto_completo(self) -> str:
        return "\n".join(self.paragrafos)


def _extrair_paragrafos(caminho: str) -> tuple[list[str], list[str]]:
    """Lê parágrafos e também o texto dentro de tabelas, que o Word esconde do iterador padrão."""
    from docx import Document

    erros = []
    try:
        documento = Document(caminho)
    except Exception as e:
        return [], [f"não foi possível abrir: {e}"]

    linhas = []
    for paragrafo in documento.paragraphs:
        texto = limpar(paragrafo.text)
        if texto:
            linhas.append(texto)

    for tabela in documento.tables:
        for linha in tabela.rows:
            for celula in linha.cells:
                texto = limpar(celula.text)
                if texto and texto not in linhas[-3:]:
                    linhas.append(texto)

    return linhas, erros


def ler_docx(caminho: str, papel: str | None = None) -> LeituraDocx:
    leitura = LeituraDocx(caminho=caminho)
    nome = os.path.basename(caminho)

    if papel:
        leitura.papel = papel
    elif RE_ASSUNTO.search(nome):
        leitura.papel = "assunto"
    elif RE_CONTEUDO.search(nome):
        leitura.papel = "conteudo"

    leitura.paragrafos, leitura.erros = _extrair_paragrafos(caminho)

    # heurística: arquivo curto com rótulo de assunto provavelmente é o de assunto
    if leitura.papel == "indefinido":
        corpo = " ".join(leitura.paragrafos).lower()
        if len(leitura.paragrafos) <= 8 and ("assunto" in corpo or "header" in corpo):
            leitura.papel = "assunto"
        else:
            leitura.papel = "conteudo"

    if leitura.papel == "assunto":
        leitura.assunto, leitura.pre_header = _separar_assunto(leitura.paragrafos)

    return leitura


def _separar_assunto(paragrafos: list[str]) -> tuple[str, str]:
    """Separa assunto e pré-header, aceitando tanto 'Assunto: x' quanto linhas soltas."""
    assunto, pre_header = "", ""
    pendente = None
    for linha in paragrafos:
        minuscula = linha.lower()
        if minuscula.startswith("assunto"):
            valor = re.sub(r"^assunto\s*[:\-–]?\s*", "", linha, flags=re.IGNORECASE)
            if valor.strip():
                assunto = valor.strip()
            else:
                pendente = "assunto"
            continue
        if re.match(r"^pr[eé].?header|^preheader", minuscula):
            valor = re.sub(r"^pr[eé].?header\s*[:\-–]?\s*", "", linha, flags=re.IGNORECASE)
            if valor.strip():
                pre_header = valor.strip()
            else:
                pendente = "pre_header"
            continue
        if pendente == "assunto":
            assunto, pendente = linha, None
        elif pendente == "pre_header":
            pre_header, pendente = linha, None

    if not assunto and paragrafos:
        assunto = paragrafos[0]
    if not pre_header and len(paragrafos) > 1:
        pre_header = paragrafos[1]
    return assunto, pre_header


def localizar_docx(pasta: str) -> list[str]:
    encontrados = []
    for raiz, _, arquivos in os.walk(pasta):
        for arquivo in arquivos:
            if arquivo.lower().endswith(".docx") and not arquivo.startswith("~$"):
                encontrados.append(os.path.join(raiz, arquivo))
    return sorted(encontrados)
