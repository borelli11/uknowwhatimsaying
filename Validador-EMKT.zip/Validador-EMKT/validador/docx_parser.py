"""
Leitura dos .docx do pacote.

Dois papéis diferentes:
  CONTEUDO.docx  -> todo o texto legível da peça, na ordem de leitura
  ASSUNTO.docx   -> assunto e pré-header

A identificação é por nome de arquivo, com heurística por conteúdo quando o
analista nomeia fora do padrão.
"""

import os
import re
from dataclasses import dataclass, field

from .normalizacao import limpar

RE_ASSUNTO = re.compile(r"assunto|subject|pre.?header|preheader", re.IGNORECASE)
RE_CONTEUDO = re.compile(r"conte.?do|content|texto|alt", re.IGNORECASE)


@dataclass
class LeituraDocx:
    caminho: str
    papel: str = "indefinido"       # "conteudo" | "assunto" | "indefinido"
    paragrafos: list[str] = field(default_factory=list)
    assunto: str = ""
    pre_header: str = ""
    erros: list[str] = field(default_factory=list)

    def texto_completo(self) -> str:
        return "\n".join(self.paragrafos)


def _extrair_paragrafos(caminho: str) -> tuple[list[str], list[str]]:
    """Lê parágrafos e também o texto dentro de tabelas, que o Word esconde do iterador padrão."""
    from docx import Document

    erros = []
    try:
        documento = Document(caminho)
    except Exception as e:
        return [], [f"não foi possível abrir: {e}"]

    linhas = []
    for paragrafo in documento.paragraphs:
        texto = limpar(paragrafo.text)
        if texto:
            linhas.append(texto)

    for tabela in documento.tables:
        for linha in tabela.rows:
            for celula in linha.cells:
                texto = limpar(celula.text)
                if texto and texto not in linhas[-3:]:
                    linhas.append(texto)

    return linhas, erros


def ler_docx(caminho: str, papel: str | None = None) -> LeituraDocx:
    """Lê o arquivo. O papel, quando não informado, é decidido em identificar_papeis()."""
    leitura = LeituraDocx(caminho=caminho)
    leitura.paragrafos, leitura.erros = _extrair_paragrafos(caminho)
    if papel:
        leitura.papel = papel
        if papel == "assunto":
            leitura.assunto, leitura.pre_header = _separar_assunto(leitura.paragrafos)
    return leitura


def _pontuar_como_assunto(leitura: LeituraDocx) -> int:
    """
    O quanto este arquivo se parece com o docx de assunto e pré-header.

    O nome do arquivo não serve de critério: em pacote real ele costuma ser a
    quebra, o CPI ou a ação, e não "ASSUNTO" ou "CONTEUDO". O que distingue os
    dois é o conteúdo — o de assunto é curto e traz os rótulos; o de conteúdo é
    a peça inteira transcrita.
    """
    corpo = " ".join(leitura.paragrafos).lower()
    palavras = len(corpo.split())
    pontos = 0

    if RE_ASSUNTO.search(os.path.basename(leitura.caminho)):
        pontos += 3
    if re.search(r"\bassunto\b", corpo):
        pontos += 4
    if re.search(r"pr[eé].?header|preheader", corpo):
        pontos += 4
    if palavras <= 40:
        pontos += 3
    elif palavras <= 80:
        pontos += 1
    if len(leitura.paragrafos) <= 6:
        pontos += 2
    if palavras > 150:
        pontos -= 5
    return pontos


def identificar_papeis(caminhos: list[str]) -> tuple[LeituraDocx | None, LeituraDocx | None]:
    """
    Decide qual docx é o de conteúdo e qual é o de assunto.

    Devolve (conteudo, assunto). Regra, na ordem:
      - lê todos e pontua cada um pela cara de "assunto"
      - o melhor pontuado vira assunto, desde que passe do limiar
      - entre os restantes, o de maior corpo vira o conteúdo
      - com um arquivo só, ele é conteúdo, a menos que seja claramente assunto
    """
    leituras = [ler_docx(caminho) for caminho in caminhos]
    leituras = [l for l in leituras if l.paragrafos or not l.erros]
    if not leituras:
        return None, None

    pontuados = sorted(
        ((_pontuar_como_assunto(l), -len(" ".join(l.paragrafos)), l) for l in leituras),
        key=lambda t: (-t[0], t[1]),
    )

    assunto = None
    melhor_pontos, _, melhor = pontuados[0]
    # limiar 6: exige pelo menos dois sinais fortes (um rótulo + ser curto),
    # para não promover a assunto um conteúdo que por acaso é pequeno
    if melhor_pontos >= 6:
        assunto = melhor
        assunto.papel = "assunto"
        assunto.assunto, assunto.pre_header = _separar_assunto(assunto.paragrafos)

    candidatos = [l for l in leituras if l is not assunto]
    conteudo = None
    if candidatos:
        conteudo = max(candidatos, key=lambda l: len(" ".join(l.paragrafos)))
        conteudo.papel = "conteudo"
    elif assunto is not None and len(leituras) == 1:
        # arquivo único com cara de assunto: sem material para comparar o texto
        conteudo = None

    return conteudo, assunto


def _separar_assunto(paragrafos: list[str]) -> tuple[str, str]:
    """Separa assunto e pré-header, aceitando tanto 'Assunto: x' quanto linhas soltas."""
    assunto, pre_header = "", ""
    pendente = None
    for linha in paragrafos:
        minuscula = linha.lower()
        if minuscula.startswith("assunto"):
            valor = re.sub(r"^assunto\s*[:\-–]?\s*", "", linha, flags=re.IGNORECASE)
            if valor.strip():
                assunto = valor.strip()
            else:
                pendente = "assunto"
            continue
        if re.match(r"^pr[eé].?header|^preheader", minuscula):
            valor = re.sub(r"^pr[eé].?header\s*[:\-–]?\s*", "", linha, flags=re.IGNORECASE)
            if valor.strip():
                pre_header = valor.strip()
            else:
                pendente = "pre_header"
            continue
        if pendente == "assunto":
            assunto, pendente = linha, None
        elif pendente == "pre_header":
            pre_header, pendente = linha, None

    if not assunto and paragrafos:
        assunto = paragrafos[0]
    if not pre_header and len(paragrafos) > 1:
        pre_header = paragrafos[1]
    return assunto, pre_header


def localizar_docx(pasta: str) -> list[str]:
    encontrados = []
    for raiz, _, arquivos in os.walk(pasta):
        for arquivo in arquivos:
            if arquivo.lower().endswith(".docx") and not arquivo.startswith("~$"):
                encontrados.append(os.path.join(raiz, arquivo))
    return sorted(encontrados)
