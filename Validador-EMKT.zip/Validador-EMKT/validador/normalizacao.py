"""
Normalização de texto.

Tudo que vem de HTML, docx e OCR passa por aqui antes de qualquer comparação.
Sem isso, aspas curvas do Word contra aspas retas do HTML viram divergência falsa
e o relatório fica cheio de erro que não é erro.
"""

import re
import unicodedata
from dataclasses import dataclass

# Substituições de caracteres que o Word, o HTML e o OCR escrevem de formas diferentes
SUBSTITUICOES = {
    "\u00a0": " ",   # espaço não-quebrável (&nbsp;)
    "\u2007": " ",
    "\u202f": " ",
    "\u200b": "",    # zero-width space
    "\ufeff": "",    # BOM
    "\u2018": "'",   # aspas simples curvas
    "\u2019": "'",
    "\u201a": "'",
    "\u201c": '"',   # aspas duplas curvas
    "\u201d": '"',
    "\u201e": '"',
    "\u2013": "-",   # en dash
    "\u2014": "-",   # em dash
    "\u2212": "-",   # sinal de menos
    "\u2026": "...",  # reticências
    "\u00ad": "",    # hífen suave
    "\u2022": " ",   # bullet
    "\u00b7": " ",
}

# Erros clássicos do OCR em fonte de peça de e-mail
CORRECOES_OCR = {
    "|": "l",
    "¦": "l",
}


def limpar(texto: str) -> str:
    """Aplica substituições de caracteres e colapsa espaços. Preserva o caso."""
    if not texto:
        return ""
    texto = unicodedata.normalize("NFC", texto)
    for de, para in SUBSTITUICOES.items():
        texto = texto.replace(de, para)
    texto = re.sub(r"[ \t\r\f\v]+", " ", texto)
    texto = re.sub(r"\n{2,}", "\n", texto)
    return texto.strip()


def sem_acento(texto: str) -> str:
    decomposto = unicodedata.normalize("NFD", texto)
    return "".join(c for c in decomposto if unicodedata.category(c) != "Mn")


def tokenizar(texto: str, ignorar_acentos: bool = True,
              ignorar_pontuacao: bool = True) -> list[str]:
    """
    Quebra o texto em palavras comparáveis.

    A comparação de sequência trabalha em cima desta lista. Manter tokens em vez
    de caracteres deixa o diff legível: o relatório aponta "palavra X virou Y",
    não "caractere 4.871 divergente".
    """
    texto = limpar(texto).lower()
    for de, para in CORRECOES_OCR.items():
        texto = texto.replace(de, para)
    if ignorar_acentos:
        texto = sem_acento(texto)
    if ignorar_pontuacao:
        # mantém R$, %, dígitos e letras — o resto vira separador
        # & entra junto com % e $: em peça de banco ele carrega sentido
        # ("Crédito & Financiamento"), não é pontuação descartável
        texto = re.sub(r"[^\w\s%$&]", " ", texto)
    tokens = [t for t in texto.split() if t]
    return tokens


# O CONTEUDO.docx costuma marcar botão entre colchetes — "[Simular crédito]".
# É convenção de escrita do documento, não pontuação da peça: comparar isso
# geraria um apontamento em todo botão de toda campanha.
RE_MARCACAO_DE_BOTAO = re.compile(r"^[\[\](){}<>]+|[\[\](){}<>]+$")


@dataclass
class Par:
    """
    Uma palavra em três formas, porque cada uma serve a um propósito.

      chave    -> compara: sem acento, sem pontuação, minúscula.
                  É o que decide se a palavra é a mesma.
      sensivel -> compara acento e pontuação: minúscula, mas com acento e com
                  a pontuação que vem colada. Separa "Olá," de "Ola".
      texto    -> aparece no relatório: exatamente como está no arquivo.
    """
    chave: str
    sensivel: str
    texto: str
    inicio: int = 0
    fim: int = 0


# um token é uma sequência de letras, dígitos, % ou $; a pontuação colada nele
# é capturada à parte, para conseguirmos apontar vírgula divergente
RE_TOKEN = re.compile(r"[\w%$&]+")
RE_PONTUACAO_COLADA = re.compile(r"^[.,;:!?)\]}\"'…]+")


def tokenizar_pares(texto: str, ignorar_acentos: bool = True) -> list[Par]:
    """
    Mesma segmentação de tokenizar(), mas devolve as três formas de cada palavra.

    Manter as três juntas é o que permite dizer "a palavra confere, só o acento
    que não" em vez de tratar tudo como divergência de conteúdo.
    """
    base = limpar(texto)
    minuscula = base.lower()
    for de, para in CORRECOES_OCR.items():
        minuscula = minuscula.replace(de, para)

    pares = []
    for achado in RE_TOKEN.finditer(minuscula):
        bruto = achado.group()
        chave = sem_acento(bruto) if ignorar_acentos else bruto
        if not chave:
            continue
        # pontuação imediatamente depois da palavra, ainda sem espaço no meio
        depois = minuscula[achado.end():achado.end() + 4]
        sufixo = ""
        encontrado = RE_PONTUACAO_COLADA.match(depois)
        if encontrado:
            sufixo = encontrado.group()
        pares.append(Par(
            chave=chave,
            sensivel=RE_MARCACAO_DE_BOTAO.sub("", bruto + sufixo),
            texto=base[achado.start():achado.end() + len(sufixo)],
            inicio=achado.start(),
            fim=achado.end() + len(sufixo),
        ))
    return pares


def texto_para_exibicao(texto: str) -> str:
    """Versão limpa mas legível, usada no relatório (preserva caso e acento)."""
    return limpar(texto)
