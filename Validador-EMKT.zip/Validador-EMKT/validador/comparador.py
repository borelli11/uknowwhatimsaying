"""
Comparação entre a fita de leitura do HTML e o CONTEUDO.docx.

Trabalha com sequência, não com conjunto: além de acusar palavra faltando ou
trocada, detecta trecho fora de ordem — o caso de a imagem 03 aparecer antes da
02 no HTML, ou de o redator ter digitado os blocos na ordem errada no docx.

Cada token carrega a origem (texto vivo ou nome do arquivo de imagem), então o
apontamento diz onde olhar em vez de só dizer que não bateu.
"""

from dataclasses import dataclass, field
from difflib import SequenceMatcher

from . import correcao_ocr, excecoes, ordenacao
from .normalizacao import tokenizar, tokenizar_pares


@dataclass
class Token:
    valor: str                # forma de comparação: sem acento nem pontuação
    origem: str               # "texto vivo" ou nome do arquivo
    indice_bloco: int
    classificacao: str = ""   # "dispensavel" | "obrigatorio:<rótulo>" | ""
    sensivel: str = ""        # minúscula, com acento e pontuação colada
    texto: str = ""           # exatamente como está no arquivo


@dataclass
class Divergencia:
    tipo: str            # "faltando" | "sobrando" | "trocado" | "fora_de_ordem"
    origem: str
    trecho_html: str = ""
    trecho_docx: str = ""
    contexto_antes: str = ""
    contexto_depois: str = ""
    posicao: int = 0
    obrigatorio: str = ""     # rótulo do bloco: disclaimer, opt-out, atendimento
    tolerado: bool = False    # bloco onde a diferença é esperada (redes sociais)
    citacao_html: str = ""    # trecho literal, como está na peça
    citacao_docx: str = ""    # trecho literal, como está no docx

    @property
    def gravidade(self) -> str:
        """
        Só "alta" reprova o pacote. As outras duas faixas notificam.

        Acento, vírgula e espaçamento nunca reprovam: existe margem de
        tolerância neles e a decisão é do analista, não da ferramenta. Isso
        vale em qualquer trecho, inclusive nos blocos de disclaimer, opt-out e
        atendimento — a marcação de bloco serve para localizar o trecho, não
        para endurecer o critério.
        """
        if self.tolerado:
            # bloco de redes sociais: a peça traz o ícone, o docx traz a frase.
            # A diferença é informação, não erro.
            return "media"
        if self.tipo in ("acento_pontuacao", "espacamento", "fora_de_ordem"):
            return "media"
        if self.tipo in ("faltando", "trocado", "sobrando"):
            return "alta"
        return "baixa"


@dataclass
class ResultadoComparacao:
    similaridade: float = 0.0
    total_tokens_html: int = 0
    total_tokens_docx: int = 0
    tokens_iguais: int = 0
    divergencias: list[Divergencia] = field(default_factory=list)
    blocos_sem_ocr: list[str] = field(default_factory=list)
    comparacao_parcial: bool = False
    trechos_dispensados: list[str] = field(default_factory=list)
    obrigatorios_ausentes: list[str] = field(default_factory=list)
    correcoes_ocr: list[str] = field(default_factory=list)
    imagens_reordenadas: list[str] = field(default_factory=list)

    @property
    def aprovado(self) -> bool:
        return not self.divergencias and not self.comparacao_parcial

    @property
    def status(self) -> str:
        # gravidade vem antes de completude: uma divergência alta reprova mesmo
        # quando parte das imagens não pôde ser lida
        if any(d.gravidade == "alta" for d in self.divergencias):
            return "reprovado"
        if self.comparacao_parcial:
            return "parcial"
        if not self.divergencias:
            return "aprovado"
        return "atencao"

    def por_gravidade(self, nivel: str) -> list[Divergencia]:
        return [d for d in self.divergencias if d.gravidade == nivel]


def _alinhar_imagens(fita, paragrafos_docx: list[str]) -> list[str]:
    """
    Põe a leitura de cada imagem na ordem em que o docx escreveu.

    Dentro de um banner com layout em blocos não existe ordem de leitura única,
    e qualquer critério automático erra em alguma peça. A ordem que vale é a de
    quem escreveu, e ela está no docx.

    Só acontece quando todas as linhas da imagem foram encontradas lá: assim a
    reordenação silencia ruído de diagramação sem silenciar erro de conteúdo.
    """
    ajustadas = []
    for bloco in fita:
        if bloco.tipo != "imagem" or not bloco.conteudo or not bloco.ocr_lido:
            continue
        resultado = ordenacao.alinhar_por_referencia(bloco.conteudo, paragrafos_docx)
        if resultado.reordenou:
            bloco.conteudo = "\n".join(resultado.linhas)
            bloco.reordenado = True
            ajustadas.append(bloco.referencia or "imagem")
    return ajustadas


def _remover_dispensaveis(fita, vocabulario: set[str]):
    """
    Tira da comparação o texto de template que não precisa constar no docx.

    O link de fallback do topo — "se não conseguir abrir esse e-mail, clique
    aqui" — é obrigatório no HTML e opcional no docx. Marcá-lo e deixar na fita
    não bastava: o alinhamento juntava esses tokens com os da frase seguinte
    num apontamento só, e a dispensa deixava de valer justamente ali.

    A remoção só acontece quando o trecho REALMENTE não está no docx. Se o
    analista escreveu o fallback lá, ele fica e é comparado como qualquer outro
    texto.
    """
    limpa, removidos = [], []
    for bloco in fita:
        if bloco.classificacao != "dispensavel":
            limpa.append(bloco)
            continue
        palavras = tokenizar(bloco.conteudo)
        if not palavras:
            continue
        presentes = sum(1 for p in palavras if correcao_ocr.canonizar(p) in vocabulario)
        if presentes / len(palavras) >= 0.6:
            limpa.append(bloco)      # está nos dois: compara normalmente
        else:
            removidos.append(bloco.conteudo)
    return limpa, removidos


def _tokens_da_fita(fita, vocabulario: set[str] | None = None
                    ) -> tuple[list[Token], list[str], list[str]]:
    tokens, sem_ocr, corrigidos = [], [], []
    for indice, bloco in enumerate(fita):
        if bloco.oculto:
            continue
        if bloco.tipo == "imagem":
            origem = bloco.referencia or "imagem"
            if not bloco.ocr_lido:
                if bloco.ocr_erro or not bloco.conteudo:
                    # a mesma imagem pode aparecer várias vezes; avisa uma só
                    aviso = f"{origem}: {bloco.ocr_erro or 'sem leitura'}"
                    if aviso not in sem_ocr:
                        sem_ocr.append(aviso)
                    continue
        else:
            origem = "texto vivo"
        pares = tokenizar_pares(bloco.conteudo)
        # texto vindo de OCR passa pela correção; texto do código, não
        if bloco.tipo == "imagem" and vocabulario:
            chaves = [p.chave for p in pares]
            corrigidas, separados = correcao_ocr.corrigir(chaves, vocabulario)
            corrigidos.extend(separados)
            if corrigidas != chaves:
                # a correção quebra ou remove tokens, então o vínculo 1 para 1
                # com o texto original se perde; nesse caso o bloco inteiro vira
                # a citação e cada token guarda só a forma de comparação
                pares = [
                    type(pares[0])(chave=c, sensivel=c, texto=c) if pares else None
                    for c in corrigidas
                ]
                pares = [p for p in pares if p]
        for par in pares:
            tokens.append(Token(
                valor=par.chave, origem=origem, indice_bloco=indice,
                classificacao=bloco.classificacao,
                sensivel=par.sensivel, texto=par.texto,
            ))
    return tokens, sem_ocr, corrigidos


def _tokens_do_docx(paragrafos: list[str]) -> list[Token]:
    tokens = []
    for indice, paragrafo in enumerate(paragrafos):
        # o docx também é classificado: o bloco de redes sociais costuma vir
        # completo só deste lado, e é por aqui que ele é reconhecido
        classificacao = excecoes.classificar(paragrafo)
        for par in tokenizar_pares(paragrafo):
            tokens.append(Token(
                valor=par.chave, origem="docx", indice_bloco=indice,
                sensivel=par.sensivel, texto=par.texto,
                classificacao=classificacao,
            ))
    return tokens


def _citar(tokens: list[Token], inicio: int, fim: int, origens: list[str],
           folga: int = 6, limite: int = 60) -> str:
    """
    Monta a citação literal do trecho, com o texto exatamente como está no
    arquivo — acento, pontuação e maiúscula preservados.

    Cita com uma folga de palavras em volta: um apontamento isolado ("prazo")
    não diz nada a quem vai ler o report. A frase em volta diz.
    """
    if not origens:
        return ""
    inicio_folga = max(0, inicio - folga)
    fim_folga = min(len(tokens), fim + folga)
    fatia = tokens[inicio_folga:fim_folga]
    if not fatia:
        return ""

    partes, bloco_atual = [], None
    for token in fatia[:limite]:
        palavra = token.texto or token.valor
        if bloco_atual is None:
            bloco_atual = token.indice_bloco
        elif token.indice_bloco != bloco_atual:
            partes.append("\n")
            bloco_atual = token.indice_bloco
        partes.append(palavra)

    texto = ""
    for parte in partes:
        if parte == "\n":
            texto = texto.rstrip() + "\n"
        else:
            texto += ("" if texto.endswith("\n") or not texto else " ") + parte
    reticencia_inicio = "… " if inicio_folga > 0 else ""
    reticencia_fim = " …" if fim_folga < len(tokens) else ""
    return (reticencia_inicio + texto.strip() + reticencia_fim).strip()


def _texto(tokens: list[Token], inicio: int, fim: int, limite: int = 25) -> str:
    trecho = [(t.texto or t.valor) for t in tokens[inicio:fim]]
    if len(trecho) > limite:
        trecho = trecho[:limite] + ["..."]
    return " ".join(trecho)


def _origem_dominante(tokens: list[Token], inicio: int, fim: int) -> str:
    fatia = tokens[inicio:fim]
    if not fatia:
        return "—"
    contagem: dict[str, int] = {}
    for token in fatia:
        contagem[token.origem] = contagem.get(token.origem, 0) + 1
    return max(contagem, key=contagem.get)


def _so_muda_espacamento(tokens_html, tokens_docx, i1, i2, j1, j2) -> bool:
    """
    Diz se os dois trechos têm exatamente o mesmo conteúdo, só quebrado em
    palavras de forma diferente.

    Comparar sem os espaços é o teste: se as sequências de caracteres coincidem,
    o que mudou foi onde o espaço caiu, não o que está escrito.
    """
    lado_html = "".join(t.valor for t in tokens_html[i1:i2])
    lado_docx = "".join(t.valor for t in tokens_docx[j1:j2])
    return bool(lado_html) and lado_html == lado_docx


def _diferencas_de_forma(tokens_html, tokens_docx, i1, i2, j1, j2) -> list[Divergencia]:
    """
    Compara acento e pontuação dentro de um trecho que já casou palavra a palavra.

    Agrupa diferenças vizinhas num apontamento só: uma frase com quatro acentos
    trocados é um problema, não quatro.
    """
    achados, atual = [], None
    for deslocamento in range(i2 - i1):
        alvo_html = tokens_html[i1 + deslocamento]
        alvo_docx = tokens_docx[j1 + deslocamento]
        # Só texto escrito no código entra aqui. OCR erra acento e pontuação
        # por natureza — lê 0 como o, come vírgula, junta ponto de milhar.
        # Cobrar acento de uma leitura de imagem seria inventar divergência.
        if alvo_html.origem != "texto vivo":
            atual = None
            continue
        if alvo_html.sensivel == alvo_docx.sensivel:
            atual = None
            continue
        if atual is not None and deslocamento - atual["ultimo"] <= 3:
            atual["ultimo"] = deslocamento
            atual["pares"].append((alvo_html, alvo_docx))
            continue
        atual = {"inicio": deslocamento, "ultimo": deslocamento,
                 "pares": [(alvo_html, alvo_docx)]}
        achados.append(atual)

    divergencias = []
    for achado in achados:
        inicio = i1 + achado["inicio"]
        fim = i1 + achado["ultimo"] + 1
        desloc_j = j1 + achado["inicio"]
        fim_j = j1 + achado["ultimo"] + 1
        divergencias.append(Divergencia(
            tipo="acento_pontuacao",
            origem=_origem_dominante(tokens_html, inicio, fim),
            trecho_html=" ".join(h.texto for h, _ in achado["pares"]),
            trecho_docx=" ".join(d.texto for _, d in achado["pares"]),
            posicao=inicio,
            citacao_html=_citar(tokens_html, inicio, fim, tokens_html),
            citacao_docx=_citar(tokens_docx, desloc_j, fim_j, tokens_docx),
        ))
    return divergencias


def comparar(fita, paragrafos_docx: list[str],
             janela_contexto: int = 6) -> ResultadoComparacao:
    resultado = ResultadoComparacao()

    vocabulario = correcao_ocr.construir_vocabulario(paragrafos_docx)
    reordenadas = _alinhar_imagens(fita, paragrafos_docx)
    fita, dispensados = _remover_dispensaveis(fita, vocabulario)
    tokens_html, sem_ocr, corrigidos = _tokens_da_fita(fita, vocabulario)
    tokens_docx = _tokens_do_docx(paragrafos_docx)

    resultado.blocos_sem_ocr = sem_ocr
    resultado.correcoes_ocr = corrigidos
    resultado.trechos_dispensados = dispensados
    resultado.imagens_reordenadas = reordenadas
    resultado.comparacao_parcial = bool(sem_ocr)
    resultado.total_tokens_html = len(tokens_html)
    resultado.total_tokens_docx = len(tokens_docx)

    # a comparação usa a forma canônica, que trata confusões de caractere do
    # OCR; o relatório continua exibindo o texto original
    valores_html = [correcao_ocr.canonizar(t.valor) for t in tokens_html]
    valores_docx = [correcao_ocr.canonizar(t.valor) for t in tokens_docx]

    matcher = SequenceMatcher(None, valores_html, valores_docx, autojunk=False)
    resultado.similaridade = round(matcher.ratio() * 100, 1)

    faltando, sobrando = [], []

    for operacao, i1, i2, j1, j2 in matcher.get_opcodes():
        if operacao == "equal":
            resultado.tokens_iguais += i2 - i1
            # A palavra confere, mas pode diferir no acento ou na vírgula.
            # Vira apontamento próprio, de gravidade média: aqui existe margem
            # de tolerância e quem decide é o analista, não a ferramenta.
            resultado.divergencias.extend(
                _diferencas_de_forma(tokens_html, tokens_docx, i1, i2, j1, j2)
            )
            continue

        divergencia = Divergencia(
            tipo="",
            origem=_origem_dominante(tokens_html, i1, i2) if i2 > i1 else "docx",
            trecho_html=_texto(tokens_html, i1, i2),
            trecho_docx=_texto(tokens_docx, j1, j2),
            contexto_antes=_texto(tokens_html, max(0, i1 - janela_contexto), i1, 10),
            contexto_depois=_texto(tokens_html, i2, i2 + janela_contexto, 10),
            posicao=i1,
            citacao_html=_citar(tokens_html, i1, i2, tokens_html),
            citacao_docx=_citar(tokens_docx, j1, j2, tokens_docx),
        )

        classificacoes = {t.classificacao for t in tokens_html[i1:i2] if t.classificacao}
        classificacoes_docx = {t.classificacao for t in tokens_docx[j1:j2] if t.classificacao}
        obrigatorio = next(
            (c.split(":", 1)[1] for c in classificacoes if c.startswith("obrigatorio")), ""
        )
        divergencia.obrigatorio = obrigatorio
        # o bloco tolerado pode estar de qualquer um dos lados: no HTML é só o
        # rótulo com os ícones, no docx é a frase inteira
        divergencia.tolerado = ("tolerado" in classificacoes
                                or "tolerado" in classificacoes_docx)

        # Rede de segurança: o grosso do texto de template já saiu da fita em
        # _remover_dispensaveis; aqui pega o que tenha escapado.
        if (operacao == "delete" and not obrigatorio
                and classificacoes == {"dispensavel"}):
            resultado.trechos_dispensados.append(divergencia.trecho_html)
            continue

        if operacao == "delete" and obrigatorio:
            resultado.obrigatorios_ausentes.append(
                f"{obrigatorio}: {divergencia.trecho_html}"
            )

        if operacao == "delete":
            divergencia.tipo = "faltando"      # está no HTML, não está no docx
            faltando.append(divergencia)
        elif operacao == "insert":
            divergencia.tipo = "sobrando"      # está no docx, não está no HTML
            sobrando.append(divergencia)
        elif _so_muda_espacamento(tokens_html, tokens_docx, i1, i2, j1, j2):
            # "36x" contra "36 x", "R$50,00" contra "R$ 50,00": as mesmas
            # letras e dígitos, só o espaço em lugar diferente. Notifica, mas
            # não reprova — espaço a mais ou a menos não muda o que o cliente
            # com deficiência visual escuta.
            divergencia.tipo = "espacamento"
            resultado.divergencias.append(divergencia)
        else:
            divergencia.tipo = "trocado"
            resultado.divergencias.append(divergencia)

    # Um mesmo trecho que some de um ponto e reapareça em outro é inversão de
    # ordem, não falta de conteúdo. Reclassificar evita dois apontamentos graves
    # para um problema que é só de posição.
    consumidos_sobrando = set()
    for ausente in faltando:
        chave = " ".join(sorted(ausente.trecho_html.split()))
        casou = False
        for indice, excedente in enumerate(sobrando):
            if indice in consumidos_sobrando:
                continue
            if " ".join(sorted(excedente.trecho_docx.split())) == chave and chave:
                ausente.tipo = "fora_de_ordem"
                ausente.trecho_docx = excedente.trecho_docx
                consumidos_sobrando.add(indice)
                casou = True
                break
        resultado.divergencias.append(ausente)
        if not casou:
            continue

    for indice, excedente in enumerate(sobrando):
        if indice not in consumidos_sobrando:
            resultado.divergencias.append(excedente)

    resultado.divergencias.sort(key=lambda d: d.posicao)
    return resultado


def comparar_assunto(leitura_assunto, leitura_html) -> list[Divergencia]:
    """
    Confere se o pré-header do docx aparece no HTML — normalmente em div oculta.
    Diferente do conteúdo, aqui basta conter, porque a ordem não importa.
    """
    apontamentos = []
    if not leitura_assunto or not leitura_assunto.pre_header:
        return apontamentos

    alvo = set(tokenizar(leitura_assunto.pre_header))
    if not alvo:
        return apontamentos

    universo = set()
    for texto in leitura_html.texto_oculto:
        universo.update(tokenizar(texto))
    for bloco in leitura_html.fita:
        universo.update(tokenizar(bloco.conteudo))

    faltantes = alvo - universo
    if len(faltantes) > len(alvo) * 0.3:
        apontamentos.append(
            Divergencia(
                tipo="faltando",
                origem="pré-header",
                trecho_docx=leitura_assunto.pre_header,
                trecho_html="não localizado no HTML",
            )
        )
    return apontamentos
