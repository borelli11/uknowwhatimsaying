"""
Trechos com tratamento especial na comparação.

Dois grupos, com efeitos opostos:

DISPENSÁVEIS — texto de template que não precisa constar no CONTEUDO.docx.
  Hoje: o link de fallback do topo ("se não conseguiu visualizar, clique aqui").
  Estar no HTML e faltar no docx não é erro. Se o analista incluir no docx,
  também não é erro — a comparação continua casando normalmente.

OBRIGATÓRIOS — disclaimer, opt-out e canais de atendimento.
  Faltar no docx é apontamento de gravidade alta e sinalizado como obrigatório
  no relatório, porque é conteúdo que o cliente com deficiência visual tem
  direito de receber.

Ajuste as listas conforme o padrão das peças. Um trecho que case com as duas
listas é tratado como obrigatório — na dúvida, o sistema cobra.
"""

import re

# --- texto de template, dispensável no CONTEUDO.docx ---
DISPENSAVEIS = [
    # o verbo aparece em todas as conjugações que já vimos em pacote real:
    # conseguiu, consegue, conseguir, conseguindo, consiga
    r"n[ãa]o\s+(est[áa]\s+)?conseg(uiu|ue|uir|uindo)",
    r"n[ãa]o\s+(consiga|conseguiu|consegue|conseguir)",
    r"(problemas?|dificuldade)\s+(para|ao|em)\s+(visualizar|ver|abrir)",
    r"caso\s+n[ãa]o\s+(consiga|esteja|visualize)",
    r"visualiz(e|ar|ando)\s+(no|em seu|pelo)\s+navegador",
    r"vers[ãa]o\s+(online|web)\s+(deste|do|desta)",
    r"clique\s+aqui\s+para\s+(visualizar|ver|abrir|acessar)",
    r"abrir\s+ess[ea]\s+e-?\s?mail",
    r"n[ãa]o\s+(está|esta)\s+(vendo|visualizando)",
]

# --- conteúdo que precisa estar no docx ---
OBRIGATORIOS = {
    "opt-out": [
        r"descadastr",
        r"cancelar\s+(o\s+)?(recebimento|inscri)",
        r"n[ãa]o\s+(desejo|quero|deseja)\s+(mais\s+)?receber",
        r"sair\s+da\s+lista",
        r"opt.?out",
        r"deixar\s+de\s+receber",
    ],
    "disclaimer": [
        r"sujeito\s+[àa]\s+(an[áa]lise|aprova[çc][ãa]o)",
        r"consulte\s+(as\s+)?condi[çc][õo]es",
        r"cet\b|custo\s+efetivo\s+total",
        r"taxa\s+de\s+juros",
        r"v[áa]lid[ao]\s+(at[ée]|para)",
        r"imagens?\s+meramente\s+ilustrativ",
        r"regulamento",
        r"cnpj",
    ],
    "atendimento": [
        r"ouvidoria",
        r"central\s+de\s+atendimento",
        r"sac\b",
        r"deficiente\s+auditiv|fala\s+e\s+audi[çc][ãa]o",
        r"procon",
    ],
}

_RE_DISPENSAVEIS = [re.compile(p, re.IGNORECASE) for p in DISPENSAVEIS]
_RE_OBRIGATORIOS = {
    rotulo: [re.compile(p, re.IGNORECASE) for p in padroes]
    for rotulo, padroes in OBRIGATORIOS.items()
}


def classificar(texto: str) -> str:
    """
    Devolve "obrigatorio:<rótulo>", "dispensavel" ou "" para um trecho de texto.
    Obrigatório vence dispensável quando os dois casam.
    """
    if not texto:
        return ""
    for rotulo, padroes in _RE_OBRIGATORIOS.items():
        if any(p.search(texto) for p in padroes):
            return f"obrigatorio:{rotulo}"
    if any(p.search(texto) for p in _RE_DISPENSAVEIS):
        return "dispensavel"
    return ""
