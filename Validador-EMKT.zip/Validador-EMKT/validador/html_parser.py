"""
Leitura do HTML da peça.

A ideia central do sistema está aqui: percorrer o DOM na ordem do código e montar
uma "fita" única de leitura, intercalando o texto vivo com o texto das imagens na
posição exata em que cada imagem aparece. Essa fita é a ordem que o leitor de tela
entrega ao cliente — e é contra ela que o CONTEUDO.docx precisa bater.
"""

import os
import re
from dataclasses import dataclass, field
from urllib.parse import unquote, urlparse

from bs4 import (BeautifulSoup, CData, Comment, Declaration, Doctype,
                 NavigableString, ProcessingInstruction, Tag)

# nós que o parser entrega como texto mas não são conteúdo lido pelo cliente
NAO_E_TEXTO = (Comment, Doctype, Declaration, CData, ProcessingInstruction)

from . import excecoes, regras
from .normalizacao import limpar

TAGS_IGNORADAS = {"script", "style", "head", "meta", "title", "link", "noscript"}

# formatos que valem a pena tentar ler
EXTENSOES_IMAGEM = {".jpg", ".jpeg", ".png", ".gif", ".webp", ".bmp"}

RE_URL_CSS = re.compile(r"url\(\s*['\"]?(.*?)['\"]?\s*\)", re.IGNORECASE)

# Pixel de rastreio: não é peça, é medição. Entra no HTML da versão publicada
# (abertura, remarketing, parceiro de mídia) e não tem nada a conferir — nem
# nome de taxonomia, nem texto, nem arquivo na pasta.
RE_PIXEL_DE_RASTREIO = re.compile(
    r"open\.aspx|1x1|beacon|pixel|impression|usermatch|/track|utm_|\.aspx\b",
    re.IGNORECASE,
)


def _e_pixel_de_rastreio(url: str, elemento) -> bool:
    if RE_PIXEL_DE_RASTREIO.search(url or ""):
        return True
    # imagem declarada com 1 pixel também é medição
    try:
        largura = int(str(elemento.get("width", "")).strip() or 0)
        altura = int(str(elemento.get("height", "")).strip() or 0)
    except ValueError:
        return False
    return 0 < largura <= 2 and 0 < altura <= 2
# Elementos que separam um parágrafo do outro. Texto dentro de <b>, <span>,
# <a> e afins continua sendo a MESMA frase e precisa ser lido junto.
# Chamada de nota: no HTML vem em <sup>, e o Word entrega o sobrescrito colado
# na palavra. Colar dos dois lados é o que faz "CDB<sup>2</sup>" bater com o
# "CDB2" do docx em vez de virar divergência em toda peça com nota de rodapé.
TAGS_COLADAS = {"sup", "sub"}

TAGS_DE_BLOCO = {
    "p", "div", "td", "th", "tr", "table", "li", "ul", "ol",
    "h1", "h2", "h3", "h4", "h5", "h6", "section", "article", "body",
}

# <br> quebra a linha, mas NÃO encerra o parágrafo.
#
# Disclaimer real vem num <td> só, com <br> a cada linha visual. Tratando cada
# <br> como bloco novo, o disclaimer virava 45 pedaços soltos: nenhum deles
# casava com os padrões de disclaimer, e a regra do hyperlink deixava de rodar
# justamente onde ela existe para rodar.
TAGS_DE_QUEBRA = {"br"}

# Espaço duplicado entre palavras na MESMA linha, e espaço solto antes de
# pontuação. Precisa ser na mesma linha: quebra de linha seguida de indentação
# é como o HTML é escrito, não sobra de digitação.
RE_ESPACO_DUPLO = re.compile(r"\S[^\S\n\r]{2,}\S")
RE_ESPACO_ANTES_PONTUACAO = re.compile(r"\S[^\S\n\r]+[,.;:!?](?:\s|$)")

RE_OCULTO = re.compile(
    r"display\s*:\s*none|visibility\s*:\s*hidden|max-height\s*:\s*0|font-size\s*:\s*0",
    re.IGNORECASE,
)


@dataclass
class BlocoFita:
    """Um pedaço da leitura da peça, na ordem em que aparece."""
    tipo: str                 # "texto" | "imagem"
    conteudo: str = ""        # texto vivo, ou texto lido da imagem
    referencia: str = ""      # nome do arquivo, quando for imagem
    alt: str = ""
    origem: str = ""          # "src", "background", "style", "srcset"
    oculto: bool = False
    bruto: str = ""       # texto sem limpeza: preserva os invisíveis anti-link
    tem_link: bool = False
    textos_de_link: list = field(default_factory=list)
    remota: bool = False  # imagem servida por URL, não pelo pacote
    ocr_lido: bool = False
    ocr_confianca: float = 0.0
    ocr_erro: str = ""
    ocr_aviso: str = ""
    reordenado: bool = False
    classificacao: str = ""   # "dispensavel" | "obrigatorio:<rótulo>" | ""


@dataclass
class LeituraHTML:
    caminho: str
    fita: list[BlocoFita] = field(default_factory=list)
    imagens_referenciadas: list[str] = field(default_factory=list)  # com repetição
    imagens_remotas: list[str] = field(default_factory=list)
    pixels_de_rastreio: list[str] = field(default_factory=list)
    texto_oculto: list[str] = field(default_factory=list)
    alts_vazios: list[str] = field(default_factory=list)
    erros: list[str] = field(default_factory=list)
    redirects: int = 0
    pagina_de_email: bool = False
    ruido_de_cliente: list[str] = field(default_factory=list)
    espacos_irregulares: list[str] = field(default_factory=list)

    @property
    def imagens_unicas(self) -> list[str]:
        vistos, saida = set(), []
        for nome in self.imagens_referenciadas:
            chave = nome.lower()
            if chave not in vistos:
                vistos.add(chave)
                saida.append(nome)
        return saida

    def texto_completo(self) -> str:
        return "\n".join(b.conteudo for b in self.fita if b.conteudo and not b.oculto)


# Marcas de página salva de cliente de e-mail. Quem recebe a peça por e-mail e
# usa "salvar como" leva junto a interface inteira do Gmail ou do Outlook — e
# o que interessa, a peça, fica enterrado no meio.
MARCAS_DE_CLIENTE = [
    r'class="[^"]*\ba3s\b',          # corpo da mensagem no Gmail
    r"gmail_quote|gmail_attr",
    r"cb=gapi\.loaded|cleardot\.gif",
    r"In[íi]cio da mensagem encaminhada",
    r'class="[^"]*\\bWordSection1\\b',   # Outlook
]

RE_MARCAS_DE_CLIENTE = [re.compile(p, re.IGNORECASE) for p in MARCAS_DE_CLIENTE]


# Sobras da interface e do encaminhamento. Vêm junto no "salvar como" e não
# fazem parte da peça: cabeçalho de quem encaminhou, assinatura do celular e
# os botões que o próprio Gmail desenha sobre as imagens.
# Estes não existem em peça nenhuma: são controle do webmail ou cabeçalho de
# encaminhamento. Saem sempre, mesmo quando a página não foi reconhecida como
# salva do Gmail — o corpo extraído continua trazendo esses botões junto.
RUIDO_SEMPRE = [
    r"^fazer o download$",
    r"^enviado do meu\b",
    r"^in[íi]cio da mensagem encaminhada",
    r"^mensagem encaminhada$",
    r"^(de|para|data|cc|cco|enviada em)\s*:",
]

# Estes são ambíguos. "Baixar" pode ser o botão do Gmail ou o CTA da peça
# ("Baixe o app"), então só saem quando o arquivo é reconhecidamente uma
# página salva de webmail.
RUIDO_SO_EM_WEBMAIL = [
    r"^baixar$|^salvar no drive$|^adicionar ao drive$",
    r"^\d+ anexos?$",
    r"^assunto\s*:",
]

RE_RUIDO_SEMPRE = [re.compile(p, re.IGNORECASE) for p in RUIDO_SEMPRE]
RE_RUIDO_SO_EM_WEBMAIL = [re.compile(p, re.IGNORECASE) for p in RUIDO_SO_EM_WEBMAIL]


def e_ruido_de_cliente(texto: str, webmail: bool = False) -> bool:
    limpo = (texto or "").strip()
    if not limpo:
        return False
    padroes = list(RE_RUIDO_SEMPRE)
    if webmail:
        padroes += RE_RUIDO_SO_EM_WEBMAIL
    for linha in limpo.splitlines():
        if any(p.search(linha.strip()) for p in padroes):
            return True
    return False


def parece_pagina_de_email(codigo: str) -> bool:
    """Diz se o arquivo é a tela do webmail em vez do código da peça."""
    encontradas = sum(1 for p in RE_MARCAS_DE_CLIENTE if p.search(codigo or ""))
    return encontradas >= 2


def isolar_corpo_da_mensagem(soup):
    """
    Recorta só o corpo da mensagem dentro da página do webmail.

    Sem isso, o validador leria menu, barra lateral e assinatura do Gmail como
    se fossem parte da peça. Pega o maior bloco de corpo: numa conversa com
    resposta ou encaminhamento existe mais de um, e a peça é o mais longo.
    """
    candidatos = soup.select('div[class*="a3s"], div.WordSection1, div[class*="ii gt"]')
    if not candidatos:
        return None
    return max(candidatos, key=lambda e: len(e.get_text()))


def _e_remota(url: str) -> bool:
    """
    Diz se a imagem é servida por URL em vez de vir no pacote.

    Peça já hospedada — o link de teste que o time abre no navegador — aponta
    para o servidor, não para a pasta. Cobrar esses arquivos na pasta encheria
    o relatório de "chamada sem arquivo" para a peça inteira.
    """
    return bool(url) and url.strip().lower().startswith(("http://", "https://", "//"))


def _nome_arquivo_da_url(url: str) -> str:
    """Extrai só o nome do arquivo de um src, ignorando querystring e caminho."""
    if not url:
        return ""
    url = url.strip()
    if url.startswith("data:"):
        return ""
    caminho = urlparse(url).path or url
    nome = os.path.basename(unquote(caminho))
    return nome.strip()


def _esta_oculto(no: Tag) -> bool:
    atual = no
    while isinstance(atual, Tag):
        estilo = atual.get("style") or ""
        if RE_OCULTO.search(estilo):
            return True
        if atual.get("hidden") is not None:
            return True
        atual = atual.parent
    return False


def _urls_de_imagem(no: Tag) -> list[tuple[str, str]]:
    """Devolve [(url, origem)] de um elemento — cobre src, background e CSS inline."""
    achados = []
    if no.name == "img":
        src = no.get("src") or no.get("data-src") or ""
        if src:
            achados.append((src, "src"))
        srcset = no.get("srcset") or ""
        for parte in srcset.split(","):
            url = parte.strip().split(" ")[0]
            if url:
                achados.append((url, "srcset"))
    # e-mail usa muito background em <td> e <table>
    bg = no.get("background")
    if bg:
        achados.append((bg, "background"))
    estilo = no.get("style") or ""
    for url in RE_URL_CSS.findall(estilo):
        achados.append((url, "style"))
    # fallback do Outlook (VML)
    if no.name and no.name.lower().endswith("image"):
        src = no.get("src")
        if src:
            achados.append((src, "vml"))
    return achados


def ler_html(caminho_html: str, pasta_imagens: str | None = None,
             cache_ocr=None, incluir_ocultos: bool = False) -> LeituraHTML:
    """
    Monta a fita de leitura.

    pasta_imagens: onde procurar o arquivo físico para rodar o OCR.
    cache_ocr:     instância de CacheOCR; se None, as imagens entram sem texto.
    """
    leitura = LeituraHTML(caminho=caminho_html)

    try:
        with open(caminho_html, "rb") as f:
            bruto = f.read()
        texto_html = bruto.decode("utf-8", errors="replace")
    except OSError as e:
        leitura.erros.append(f"não foi possível abrir o HTML: {e}")
        return leitura

    # A contagem roda no código bruto, antes de qualquer limpeza: o redirect
    # aparece tanto em href quanto dentro de AMPScript ou atributo de rastreio.
    leitura.redirects = regras.contar_redirects(texto_html)

    soup = BeautifulSoup(texto_html, "html.parser")

    # arquivo salvo do webmail: trabalha só com o corpo da mensagem
    if parece_pagina_de_email(texto_html):
        leitura.pagina_de_email = True
        corpo = isolar_corpo_da_mensagem(soup)
        if corpo is not None:
            soup = corpo

    for comentario in soup.find_all(string=lambda s: isinstance(s, Comment)):
        comentario.extract()

    base = pasta_imagens or os.path.dirname(os.path.abspath(caminho_html))
    ja_registrado: set[int] = set()

    # Acumulador de texto do parágrafo em curso.
    #
    # Sem isto, "<b>nova taxa</b>, confira" vira três nós separados e a vírgula
    # fica sozinha num deles — como pontuação solta não forma palavra, ela some
    # da leitura e o sistema acusa vírgula divergente contra o docx, que tem a
    # frase inteira. Negrito, link e span são formatação, não fim de frase.
    acumulado: list[tuple[str, bool]] = []   # (texto, cola na palavra anterior)
    acumulado_bruto: list[str] = []
    acumulado_oculto = False
    acumulado_com_link = False
    acumulado_links: list[str] = []

    def _e_chamada_de_nota(no_texto):
        atual = no_texto.parent
        while isinstance(atual, Tag):
            if atual.name in TAGS_COLADAS:
                return True
            if atual.name in TAGS_DE_BLOCO:
                return False
            atual = atual.parent
        return False

    def _dentro_de_link(no_texto):
        atual = no_texto.parent
        while isinstance(atual, Tag):
            if atual.name == "a" and atual.get("href"):
                return True
            if atual.name in TAGS_DE_BLOCO:
                return False
            atual = atual.parent
        return False

    def _ancestral_de_bloco(no_texto):
        atual = no_texto.parent
        while isinstance(atual, Tag):
            if atual.name in TAGS_DE_BLOCO:
                return id(atual)
            atual = atual.parent
        return None

    def fechar_paragrafo():
        """Fecha o parágrafo acumulado e o coloca na fita."""
        nonlocal acumulado, acumulado_oculto, acumulado_bruto, acumulado_com_link
        nonlocal acumulado_links
        if not acumulado:
            return
        texto = ""
        for pedaco, colado in acumulado:
            if not texto:
                texto = pedaco
            elif pedaco == "\n" or texto.endswith("\n"):
                texto = texto.rstrip(" ") + pedaco if pedaco == "\n" else texto + pedaco
            elif colado or pedaco[0] in ".,;:!?)]}%" or texto[-1] in "([{":
                texto += pedaco          # nota de rodapé e pontuação colam
            else:
                texto += " " + pedaco
        texto = limpar(texto)
        # cabeçalho de encaminhamento e botão do webmail não são peça
        if texto and e_ruido_de_cliente(texto, leitura.pagina_de_email):
            leitura.ruido_de_cliente.append(texto[:90])
            texto = ""
        if texto:
            if acumulado_oculto:
                leitura.texto_oculto.append(texto)
            if not acumulado_oculto or incluir_ocultos:
                leitura.fita.append(BlocoFita(
                    tipo="texto", conteudo=texto, oculto=acumulado_oculto,
                    classificacao=excecoes.classificar(texto),
                    bruto="".join(acumulado_bruto),
                    tem_link=acumulado_com_link,
                    textos_de_link=list(acumulado_links),
                ))
        acumulado = []
        acumulado_bruto = []
        acumulado_oculto = False
        acumulado_com_link = False
        acumulado_links = []
    acumulado_links: list[str] = []

    bloco_corrente = None

    for no in soup.descendants:
        # --- texto vivo ---
        if isinstance(no, NavigableString):
            if isinstance(no, NAO_E_TEXTO):
                continue
            if no.parent and no.parent.name in TAGS_IGNORADAS:
                continue
            bruto = str(no)
            conteudo = limpar(bruto)
            if not conteudo:
                continue
            _registrar_espacos(leitura, bruto)
            oculto = _esta_oculto(no.parent) if no.parent else False
            ancestral = _ancestral_de_bloco(no)
            if (bloco_corrente is not None and ancestral != bloco_corrente) or \
                    (acumulado and oculto != acumulado_oculto):
                fechar_paragrafo()
            bloco_corrente = ancestral
            acumulado_oculto = oculto
            acumulado.append((conteudo, _e_chamada_de_nota(no)))
            # o bruto guarda os invisíveis (&#xFEFF;) que impedem o cliente de
            # e-mail de criar link sozinho — limpar() os remove
            acumulado_bruto.append(str(no))
            if _dentro_de_link(no):
                acumulado_com_link = True
                acumulado_links.append(conteudo)
            continue

        if not isinstance(no, Tag) or no.name in TAGS_IGNORADAS:
            continue

        if no.name in TAGS_DE_QUEBRA:
            if acumulado:
                acumulado.append(("\n", True))
                acumulado_bruto.append("\n")
            continue

        # --- imagens ---
        urls = _urls_de_imagem(no)
        if not urls:
            continue

        # a imagem encerra o parágrafo em curso: o que vier depois dela é lido
        # depois pelo leitor de tela
        fechar_paragrafo()
        bloco_corrente = None
        if id(no) in ja_registrado:
            continue
        ja_registrado.add(id(no))

        vistas_no_elemento = set()
        for url, origem in urls:
            nome = _nome_arquivo_da_url(url)
            if not nome or nome.lower() in vistas_no_elemento:
                continue
            vistas_no_elemento.add(nome.lower())
            if _e_pixel_de_rastreio(url, no):
                leitura.pixels_de_rastreio.append(nome)
                continue
            remota = _e_remota(url)
            if remota:
                if nome not in leitura.imagens_remotas:
                    leitura.imagens_remotas.append(nome)
            else:
                leitura.imagens_referenciadas.append(nome)

            alt = limpar(no.get("alt") or "")
            if no.name == "img" and not alt:
                leitura.alts_vazios.append(nome)

            bloco = BlocoFita(
                tipo="imagem", referencia=nome, alt=alt, origem=origem,
                oculto=_esta_oculto(no), remota=remota,
            )

            extensao = os.path.splitext(nome)[1].lower()
            if cache_ocr is not None and extensao in EXTENSOES_IMAGEM:
                caminho_fisico = _localizar_arquivo(base, nome)
                if caminho_fisico:
                    resultado = cache_ocr.ler(caminho_fisico)
                    bloco.conteudo = resultado.texto
                    bloco.ocr_lido = resultado.lido
                    bloco.ocr_confianca = resultado.confianca_media
                    bloco.ocr_erro = resultado.erro
                    bloco.ocr_aviso = resultado.aviso
                else:
                    bloco.ocr_erro = "arquivo não encontrado na pasta de imagens"

            bloco.classificacao = excecoes.classificar(bloco.conteudo or bloco.alt)
            leitura.fita.append(bloco)

    fechar_paragrafo()
    return leitura


def _registrar_espacos(leitura: LeituraHTML, bruto: str) -> None:
    """
    Anota espaço duplicado ou espaço antes de pontuação no texto da peça.

    Não vira divergência: a comparação já ignora espaçamento, e isso não muda
    o que o leitor de tela entrega. Fica como observação porque é o tipo de
    detalhe que passa batido na revisão e aparece feio na caixa de entrada.
    """
    for linha in bruto.splitlines():
        if len(leitura.espacos_irregulares) >= 8:
            return
        trecho = linha.strip()
        if len(trecho) < 4:
            continue
        if RE_ESPACO_DUPLO.search(trecho) or RE_ESPACO_ANTES_PONTUACAO.search(trecho):
            amostra = re.sub(r"[^\S\n\r]{2,}", " ␣ ", trecho)[:90]
            if amostra not in leitura.espacos_irregulares:
                leitura.espacos_irregulares.append(amostra)


def _localizar_arquivo(pasta: str, nome: str) -> str | None:
    """Procura o arquivo na pasta ignorando maiúscula/minúscula e subpastas."""
    alvo = nome.lower()
    for raiz, _, arquivos in os.walk(pasta):
        for arquivo in arquivos:
            if arquivo.lower() == alvo:
                return os.path.join(raiz, arquivo)
    return None
