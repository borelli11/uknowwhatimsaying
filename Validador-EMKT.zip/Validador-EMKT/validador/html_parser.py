"""
Leitura do HTML da peça.

A ideia central do sistema está aqui: percorrer o DOM na ordem do código e montar
uma "fita" única de leitura, intercalando o texto vivo com o texto das imagens na
posição exata em que cada imagem aparece. Essa fita é a ordem que o leitor de tela
entrega ao cliente — e é contra ela que o CONTEUDO.docx precisa bater.
"""

import os
import re
from dataclasses import dataclass, field
from urllib.parse import unquote, urlparse

from bs4 import (BeautifulSoup, CData, Comment, Declaration, Doctype,
                 NavigableString, ProcessingInstruction, Tag)

# nós que o parser entrega como texto mas não são conteúdo lido pelo cliente
NAO_E_TEXTO = (Comment, Doctype, Declaration, CData, ProcessingInstruction)

from . import excecoes, regras
from .normalizacao import limpar

TAGS_IGNORADAS = {"script", "style", "head", "meta", "title", "link", "noscript"}

# formatos que valem a pena tentar ler
EXTENSOES_IMAGEM = {".jpg", ".jpeg", ".png", ".gif", ".webp", ".bmp"}

RE_URL_CSS = re.compile(r"url\(\s*['\"]?(.*?)['\"]?\s*\)", re.IGNORECASE)
RE_OCULTO = re.compile(
    r"display\s*:\s*none|visibility\s*:\s*hidden|max-height\s*:\s*0|font-size\s*:\s*0",
    re.IGNORECASE,
)


@dataclass
class BlocoFita:
    """Um pedaço da leitura da peça, na ordem em que aparece."""
    tipo: str                 # "texto" | "imagem"
    conteudo: str = ""        # texto vivo, ou texto lido da imagem
    referencia: str = ""      # nome do arquivo, quando for imagem
    alt: str = ""
    origem: str = ""          # "src", "background", "style", "srcset"
    oculto: bool = False
    ocr_lido: bool = False
    ocr_confianca: float = 0.0
    ocr_erro: str = ""
    classificacao: str = ""   # "dispensavel" | "obrigatorio:<rótulo>" | ""


@dataclass
class LeituraHTML:
    caminho: str
    fita: list[BlocoFita] = field(default_factory=list)
    imagens_referenciadas: list[str] = field(default_factory=list)  # com repetição
    texto_oculto: list[str] = field(default_factory=list)
    alts_vazios: list[str] = field(default_factory=list)
    erros: list[str] = field(default_factory=list)
    redirects: int = 0

    @property
    def imagens_unicas(self) -> list[str]:
        vistos, saida = set(), []
        for nome in self.imagens_referenciadas:
            chave = nome.lower()
            if chave not in vistos:
                vistos.add(chave)
                saida.append(nome)
        return saida

    def texto_completo(self) -> str:
        return "\n".join(b.conteudo for b in self.fita if b.conteudo and not b.oculto)


def _nome_arquivo_da_url(url: str) -> str:
    """Extrai só o nome do arquivo de um src, ignorando querystring e caminho."""
    if not url:
        return ""
    url = url.strip()
    if url.startswith("data:"):
        return ""
    caminho = urlparse(url).path or url
    nome = os.path.basename(unquote(caminho))
    return nome.strip()


def _esta_oculto(no: Tag) -> bool:
    atual = no
    while isinstance(atual, Tag):
        estilo = atual.get("style") or ""
        if RE_OCULTO.search(estilo):
            return True
        if atual.get("hidden") is not None:
            return True
        atual = atual.parent
    return False


def _urls_de_imagem(no: Tag) -> list[tuple[str, str]]:
    """Devolve [(url, origem)] de um elemento — cobre src, background e CSS inline."""
    achados = []
    if no.name == "img":
        src = no.get("src") or no.get("data-src") or ""
        if src:
            achados.append((src, "src"))
        srcset = no.get("srcset") or ""
        for parte in srcset.split(","):
            url = parte.strip().split(" ")[0]
            if url:
                achados.append((url, "srcset"))
    # e-mail usa muito background em <td> e <table>
    bg = no.get("background")
    if bg:
        achados.append((bg, "background"))
    estilo = no.get("style") or ""
    for url in RE_URL_CSS.findall(estilo):
        achados.append((url, "style"))
    # fallback do Outlook (VML)
    if no.name and no.name.lower().endswith("image"):
        src = no.get("src")
        if src:
            achados.append((src, "vml"))
    return achados


def ler_html(caminho_html: str, pasta_imagens: str | None = None,
             cache_ocr=None, incluir_ocultos: bool = False) -> LeituraHTML:
    """
    Monta a fita de leitura.

    pasta_imagens: onde procurar o arquivo físico para rodar o OCR.
    cache_ocr:     instância de CacheOCR; se None, as imagens entram sem texto.
    """
    leitura = LeituraHTML(caminho=caminho_html)

    try:
        with open(caminho_html, "rb") as f:
            bruto = f.read()
        texto_html = bruto.decode("utf-8", errors="replace")
    except OSError as e:
        leitura.erros.append(f"não foi possível abrir o HTML: {e}")
        return leitura

    # A contagem roda no código bruto, antes de qualquer limpeza: o redirect
    # aparece tanto em href quanto dentro de AMPScript ou atributo de rastreio.
    leitura.redirects = regras.contar_redirects(texto_html)

    soup = BeautifulSoup(texto_html, "html.parser")

    for comentario in soup.find_all(string=lambda s: isinstance(s, Comment)):
        comentario.extract()

    base = pasta_imagens or os.path.dirname(os.path.abspath(caminho_html))
    ja_registrado: set[int] = set()

    for no in soup.descendants:
        # --- texto vivo ---
        if isinstance(no, NavigableString):
            if isinstance(no, NAO_E_TEXTO):
                continue
            if no.parent and no.parent.name in TAGS_IGNORADAS:
                continue
            conteudo = limpar(str(no))
            if not conteudo:
                continue
            oculto = _esta_oculto(no.parent) if no.parent else False
            if oculto:
                leitura.texto_oculto.append(conteudo)
                if not incluir_ocultos:
                    continue
            leitura.fita.append(
                BlocoFita(tipo="texto", conteudo=conteudo, oculto=oculto,
                          classificacao=excecoes.classificar(conteudo))
            )
            continue

        if not isinstance(no, Tag) or no.name in TAGS_IGNORADAS:
            continue

        # --- imagens ---
        urls = _urls_de_imagem(no)
        if not urls:
            continue
        if id(no) in ja_registrado:
            continue
        ja_registrado.add(id(no))

        vistas_no_elemento = set()
        for url, origem in urls:
            nome = _nome_arquivo_da_url(url)
            if not nome or nome.lower() in vistas_no_elemento:
                continue
            vistas_no_elemento.add(nome.lower())
            leitura.imagens_referenciadas.append(nome)

            alt = limpar(no.get("alt") or "")
            if no.name == "img" and not alt:
                leitura.alts_vazios.append(nome)

            bloco = BlocoFita(
                tipo="imagem", referencia=nome, alt=alt, origem=origem,
                oculto=_esta_oculto(no),
            )

            extensao = os.path.splitext(nome)[1].lower()
            if cache_ocr is not None and extensao in EXTENSOES_IMAGEM:
                caminho_fisico = _localizar_arquivo(base, nome)
                if caminho_fisico:
                    resultado = cache_ocr.ler(caminho_fisico)
                    bloco.conteudo = resultado.texto
                    bloco.ocr_lido = resultado.lido
                    bloco.ocr_confianca = resultado.confianca_media
                    bloco.ocr_erro = resultado.erro
                else:
                    bloco.ocr_erro = "arquivo não encontrado na pasta de imagens"

            bloco.classificacao = excecoes.classificar(bloco.conteudo or bloco.alt)
            leitura.fita.append(bloco)

    return leitura


def _localizar_arquivo(pasta: str, nome: str) -> str | None:
    """Procura o arquivo na pasta ignorando maiúscula/minúscula e subpastas."""
    alvo = nome.lower()
    for raiz, _, arquivos in os.walk(pasta):
        for arquivo in arquivos:
            if arquivo.lower() == alvo:
                return os.path.join(raiz, arquivo)
    return None
