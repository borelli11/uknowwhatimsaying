"""
Ordem de leitura dentro de uma imagem, usando o CONTEUDO.docx como referência.

O problema: peça de banco usa layout em blocos. "50%" fica num cartão à
esquerda, "de desconto" embaixo dele, e três itens numa lista à direita. Não
existe uma ordem de leitura única aí — ler por linha horizontal junta o "50%"
com o item que estiver na mesma altura; ler por coluna separa o número do
desconto do que ele qualifica. Qualquer critério que a máquina escolha é um
chute, e o chute vira apontamento de "ordem diferente" em quase toda peça.

Quem sabe a ordem certa é quem escreveu a peça, e isso está no docx.

A regra aqui é conservadora de propósito: a reordenação só acontece quando
TODAS as linhas lidas da imagem são encontradas no docx. Se uma linha não
aparece lá — porque tem palavra trocada, porque o docx esqueceu um trecho —
nada é reordenado e a divergência aparece normalmente. Ou seja: isso silencia
ruído de diagramação, não silencia erro de conteúdo.

Vale só DENTRO de cada imagem. A ordem entre os blocos da peça (o banner 01
vem antes do 02, o texto do código vem onde está no HTML) continua sendo
conferida como sempre.
"""

from dataclasses import dataclass, field
from difflib import SequenceMatcher

from . import correcao_ocr
from .normalizacao import limpar, tokenizar, tokenizar_pares

# Quanto de uma linha precisa ser encontrado no docx para considerarmos que ela
# está lá. Abaixo disso é coincidência de palavra comum ("de", "no", "em").
COBERTURA_MINIMA = 0.6


@dataclass
class ResultadoOrdenacao:
    linhas: list[str] = field(default_factory=list)
    reordenou: bool = False
    motivo: str = ""


def _posicao_no_docx(tokens_linha: list[str], tokens_docx: list[str]) -> int | None:
    """
    Onde esta linha aparece no docx.

    Devolve o índice do trecho correspondente, ou None se a linha não estiver
    lá. Usa o maior bloco em comum em vez de igualdade: leitura de imagem erra
    caractere, e exigir texto idêntico faria a busca falhar justamente nas
    imagens que mais precisam de ajuda.
    """
    if not tokens_linha or not tokens_docx:
        return None

    matcher = SequenceMatcher(None, tokens_docx, tokens_linha, autojunk=False)
    bloco = matcher.find_longest_match(0, len(tokens_docx), 0, len(tokens_linha))
    if bloco.size == 0:
        return None
    if bloco.size / len(tokens_linha) < COBERTURA_MINIMA:
        return None
    return bloco.a


def _partir_linha(linha: str, paragrafos_docx: list[list[str]]) -> list[tuple] | None:
    """
    Quebra a linha nos pedaços que existem no docx, cada um com sua posição.

    O motor agrupa por faixa horizontal, então dois cartões lado a lado viram
    uma linha só: "03/09: 24/09:" e "Minha Melhor Amiga A Ilha Esquecida" são
    quatro trechos de dois cartões diferentes. Exigir que a linha inteira
    exista no docx faria o alinhamento desistir justamente nas peças de layout
    mais complexo, que são as que mais precisam dele.

    Devolve None quando sobra algum pedaço sem correspondência — aí existe
    divergência de conteúdo e nada deve ser reordenado.
    """
    # os pares mantêm o texto como está na peça ao lado da forma de comparação:
    # a busca usa a canônica, o resultado exibe a original
    pares = tokenizar_pares(linha)
    if not pares:
        return None
    tokens = [correcao_ocr.canonizar(p.chave) for p in pares]
    base = limpar(linha)

    pedacos, inicio = [], 0
    while inicio < len(tokens):
        melhor_tamanho, melhor_posicao = 0, None
        # procura o maior pedaço, a partir daqui, que exista no docx
        for fim in range(len(tokens), inicio, -1):
            posicao = _posicao_exata(tokens[inicio:fim], paragrafos_docx)
            if posicao is not None:
                melhor_tamanho, melhor_posicao = fim - inicio, posicao
                break
        if not melhor_tamanho:
            return None
        # recorta direto do texto original em vez de juntar os tokens: assim a
        # barra de "03/09:" e os parênteses de "(pipoca...)" sobrevivem
        primeiro = pares[inicio]
        ultimo = pares[inicio + melhor_tamanho - 1]
        pedacos.append((melhor_posicao, base[primeiro.inicio:ultimo.fim].strip()))
        inicio += melhor_tamanho
    return pedacos


def _posicao_exata(sub: list[str], paragrafos: list[list[str]]) -> int | None:
    """
    Posição da sequência no docx, respeitando a fronteira dos parágrafos.

    Procurar num texto corrido deixava o trecho casar atravessando o fim de um
    parágrafo e o começo do outro: "de desconto no" casava com o fim de "50% de
    desconto" somado ao início de "no ingresso", e o alinhamento saía torto.
    Cada parágrafo é uma unidade — o redator quebrou ali de propósito.

    A posição devolvida é global (parágrafo e deslocamento juntos), só para
    ordenar.
    """
    if not sub:
        return None
    for indice, tokens in enumerate(paragrafos):
        if len(sub) > len(tokens):
            continue
        primeiro = sub[0]
        for i in range(len(tokens) - len(sub) + 1):
            if tokens[i] == primeiro and tokens[i:i + len(sub)] == sub:
                return indice * 10000 + i
    return None


def alinhar_por_referencia(texto_da_imagem: str,
                           paragrafos_docx: list[str]) -> ResultadoOrdenacao:
    """
    Reordena o que foi lido da imagem na ordem em que o docx escreveu.
    """
    linhas = [l for l in (texto_da_imagem or "").splitlines() if l.strip()]
    if len(linhas) < 2:
        return ResultadoOrdenacao(linhas=linhas)

    por_paragrafo = []
    for paragrafo in paragrafos_docx:
        tokens = [correcao_ocr.canonizar(t) for t in tokenizar(paragrafo)]
        if tokens:
            por_paragrafo.append(tokens)
    if not por_paragrafo:
        return ResultadoOrdenacao(linhas=linhas)

    trechos = []
    for indice, linha in enumerate(linhas):
        pedacos = _partir_linha(linha, por_paragrafo)
        if pedacos is None:
            # trecho fora do docx significa divergência de conteúdo:
            # reordenar aqui esconderia justamente o que precisa aparecer
            return ResultadoOrdenacao(
                linhas=linhas,
                motivo=f"trecho não encontrado no docx: {linha[:60]}",
            )
        for ordem_interna, (posicao, texto) in enumerate(pedacos):
            trechos.append((posicao, indice, ordem_interna, texto))

    ordenados = [t for _, _, _, t in sorted(trechos, key=lambda x: (x[0], x[1], x[2]))]
    if ordenados == linhas:
        return ResultadoOrdenacao(linhas=linhas)

    return ResultadoOrdenacao(
        linhas=ordenados,
        reordenou=True,
        motivo="ordem ajustada pela sequência do CONTEUDO.docx",
    )
