"""
Relatório de conferência em HTML — arquivo único, abre em qualquer navegador,
sem servidor e sem dependência externa. Serve como evidência da conferência.
"""

import html
import os
from datetime import datetime

CSS = """
:root{
  --tinta:#1c1f23; --tinta-fraca:#5b6570; --linha:#dfe3e8;
  --fundo:#f6f7f9; --papel:#ffffff;
  --marca:#cc092f; --ok:#12734f; --atencao:#a86400; --erro:#b3122c;
  --ok-fundo:#e8f4ee; --atencao-fundo:#fdf3e0; --erro-fundo:#fdeaed;
}
*{box-sizing:border-box}
body{margin:0;padding:32px 20px 72px;background:var(--fundo);color:var(--tinta);
  font-family:"Segoe UI",Roboto,Helvetica,Arial,sans-serif;font-size:15px;line-height:1.55}
.folha{max-width:960px;margin:0 auto}
header{border-left:5px solid var(--marca);padding:4px 0 4px 18px;margin-bottom:28px}
header h1{margin:0;font-size:25px;font-weight:650;letter-spacing:-.2px}
header .quebra{font-size:15px;color:var(--tinta-fraca);margin-top:2px}
header .meta{font-size:13px;color:var(--tinta-fraca);margin-top:8px}

.veredito{display:flex;align-items:center;gap:16px;background:var(--papel);
  border:1px solid var(--linha);border-radius:10px;padding:20px 22px;margin-bottom:26px}
.veredito .selo{font-size:19px;font-weight:700;padding:7px 16px;border-radius:6px;white-space:nowrap}
.selo.aprovado{background:var(--ok-fundo);color:var(--ok)}
.selo.atencao{background:var(--atencao-fundo);color:var(--atencao)}
.selo.reprovado,.selo.erro{background:var(--erro-fundo);color:var(--erro)}
.veredito p{margin:0;color:var(--tinta-fraca);font-size:14px}

.numeros{display:flex;gap:28px;flex-wrap:wrap;margin-top:14px;padding-top:14px;
  border-top:1px solid var(--linha)}
.numeros div{min-width:92px}
.numeros b{display:block;font-size:21px;font-weight:650;font-variant-numeric:tabular-nums}
.numeros span{font-size:12.5px;color:var(--tinta-fraca)}

section{background:var(--papel);border:1px solid var(--linha);border-radius:10px;
  padding:22px 24px;margin-bottom:18px}
section h2{margin:0 0 4px;font-size:17px;font-weight:650}
section h2 .contagem{font-weight:400;color:var(--tinta-fraca);font-size:14px}
section .resumo{margin:0 0 16px;color:var(--tinta-fraca);font-size:13.5px}

ul.itens{list-style:none;margin:0;padding:0}
ul.itens li{padding:9px 0 9px 14px;border-left:3px solid var(--linha);margin-bottom:7px;
  background:#fbfcfd;border-radius:0 5px 5px 0;font-size:14px}
li.alta{border-left-color:var(--erro)}
li.media{border-left-color:var(--atencao)}
li.baixa{border-left-color:var(--tinta-fraca)}
li.ok{border-left-color:var(--ok)}
li .rotulo{font-weight:650;margin-right:7px}
.obrigatorio{background:#eef1f4;color:var(--tinta-fraca);font-size:11.5px;
  padding:2px 8px;border-radius:4px;margin-left:8px;font-weight:600}
.citacoes{display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-top:11px}
.citacao{display:flex;flex-direction:column;gap:4px;min-width:0}
.citacao-fonte{font-size:11px;font-weight:700;letter-spacing:.05em;
  text-transform:uppercase;color:var(--tinta-fraca)}
.citacao blockquote{margin:0;padding:10px 13px;border:1px solid var(--linha);
  border-radius:6px;background:#fff;font-family:Consolas,"Courier New",monospace;
  font-size:13px;line-height:1.6;white-space:pre-wrap;word-break:break-word}
.citacao blockquote::before,.citacao blockquote::after{content:\'"\';color:var(--tinta-fraca)}
@media(max-width:700px){.citacoes{grid-template-columns:1fr}}
li .arquivo{font-family:Consolas,"Courier New",monospace;font-size:13px;
  background:#eef1f4;padding:1px 6px;border-radius:4px}

.diff{margin-top:8px;border:1px solid var(--linha);border-radius:6px;overflow:hidden}
.diff div{padding:8px 12px;font-size:13.5px}
.diff .lado{display:flex;gap:10px;border-bottom:1px solid var(--linha)}
.diff .lado:last-child{border-bottom:none}
.diff .tag{flex:0 0 74px;color:var(--tinta-fraca);font-size:12px;padding-top:1px}
.diff .html{background:#fff}
.diff .docx{background:#fafbfc}
.contexto{font-size:12.5px;color:var(--tinta-fraca);margin-top:6px}
.contexto code{background:#eef1f4;padding:1px 5px;border-radius:3px;font-size:12px}

.vazio{color:var(--ok);font-size:14px;margin:0}
.aviso{background:var(--atencao-fundo);border-left:3px solid var(--atencao);
  padding:11px 14px;border-radius:0 5px 5px 0;margin-bottom:9px;font-size:14px}
footer{margin-top:26px;font-size:12.5px;color:var(--tinta-fraca);text-align:center}
@media print{body{background:#fff;padding:0}section,.veredito{break-inside:avoid}}
"""

# Descritivo, não prescritivo: a ferramenta relata a divergência entre os dois
# arquivos e não opina sobre o que a peça deveria conter.
FRASES_STATUS = {
    "aprovado": "Nenhuma divergência entre o HTML e o CONTEUDO.docx.",
    "atencao": "Pontos para o analista avaliar.",
    "reprovado": "Divergências encontradas entre o HTML e o CONTEUDO.docx.",
    "erro": "Não foi possível concluir a conferência.",
}


def _e(texto) -> str:
    return html.escape(str(texto), quote=False)


def _secao_imagens(r) -> str:
    if not r:
        return ""
    itens = []

    for nome, motivo in r.fora_da_taxonomia:
        itens.append(("alta", "Fora da taxonomia",
                      f'<span class="arquivo">{_e(nome)}</span> — {_e(motivo)}'))
    if r.numeros_faltando:
        numeros = ", ".join(f"{n:02d}" for n in r.numeros_faltando)
        itens.append(("alta", "Sequência com furo",
                      f"faltam os números {numeros} na pasta"))
    if r.nao_comeca_em_um:
        itens.append(("media", "Sequência não inicia em 01", "primeiro número da pasta não é 01"))
    if r.numeros_duplicados:
        numeros = ", ".join(f"{n:02d}" for n in r.numeros_duplicados)
        itens.append(("alta", "Número repetido", f"o número {numeros} aparece em mais de um arquivo"))
    for nome in r.extensao_invalida:
        itens.append(("media", "Extensão fora do padrão", _e(nome)))
    for nome in r.no_html_fora_da_pasta:
        itens.append(("alta", "Chamada sem arquivo",
                      f'o HTML chama <span class="arquivo">{_e(nome)}</span>, que não existe na pasta'))
    for nome in r.na_pasta_fora_do_html:
        itens.append(("alta", "Imagem não utilizada",
                      f'<span class="arquivo">{_e(nome)}</span> está na pasta, mas não é chamada no HTML'))
    for na_pasta, no_html in r.divergencia_de_caixa:
        itens.append(("alta", "Caixa divergente",
                      f'pasta: <span class="arquivo">{_e(na_pasta)}</span> · '
                      f'HTML: <span class="arquivo">{_e(no_html)}</span>'))
    for nome in r.sem_numeracao_zero_a_esquerda:
        itens.append(("baixa", "Numeração sem zero à esquerda",
                      f'<span class="arquivo">{_e(nome)}</span> — o padrão é 01, 02, 03'))

    corpo = "".join(
        f'<li class="{classe}"><span class="rotulo">{_e(rotulo)}</span>{texto}</li>'
        for classe, rotulo, texto in itens
    )
    if not corpo:
        corpo = '<p class="vazio">Nomes seguem a quebra, sequência sem furo e todas as imagens aparecem no HTML.</p>'
    else:
        corpo = f'<ul class="itens">{corpo}</ul>'

    repetidas = ""
    if r.repeticoes_no_html:
        lista = ", ".join(f"{_e(n)} ({q}x)" for n, q in sorted(r.repeticoes_no_html.items()))
        repetidas = f"<p class='contexto'>Reaproveitadas no HTML (permitido): {lista}</p>"

    return f"""
    <section>
      <h2>Imagens <span class="contagem">· {len(r.arquivos)} na pasta · {r.total_referencias_html} chamadas no HTML</span></h2>
      <p class="resumo">Taxonomia, sequência numérica e cruzamento entre a pasta e o código.</p>
      {corpo}{repetidas}
    </section>"""


def _secao_texto(r, modo="sequencia") -> str:
    if not r:
        return ""
    blocos = []
    for d in r.divergencias:
        rotulos = {
            "faltando": "Está no HTML, não está no CONTEUDO",
            "trocado": "Escrito de forma diferente nos dois",
            "sobrando": "Está no CONTEUDO, não está no HTML",
            "fora_de_ordem": "Mesmas palavras, ordem diferente",
            "acento_pontuacao": "Acento ou pontuação diferente",
        }
        nomes_de_bloco = {"disclaimer": "no bloco de disclaimer",
                          "opt-out": "no bloco de descadastro",
                          "atendimento": "no bloco de atendimento"}
        classe = d.gravidade
        rotulo = rotulos.get(d.tipo, d.tipo)
        marca = ""
        if d.obrigatorio:
            marca = (f'<span class="obrigatorio">'
                     f'{_e(nomes_de_bloco.get(d.obrigatorio, ""))}</span>')
        diff = ""
        if d.trecho_html or d.trecho_docx:
            diff = f"""<div class="diff">
              <div class="lado html"><span class="tag">HTML</span><span>{_e(d.trecho_html) or "—"}</span></div>
              <div class="lado docx"><span class="tag">CONTEUDO</span><span>{_e(d.trecho_docx) or "—"}</span></div>
            </div>"""
        contexto = ""
        if d.contexto_antes.startswith("palavras ausentes:"):
            contexto = (f'<p class="contexto"><b>Palavras que faltam no docx:</b> '
                        f'<code>{_e(d.contexto_antes.replace("palavras ausentes: ", ""))}</code></p>')
        elif d.contexto_antes or d.contexto_depois:
            contexto = (f'<p class="contexto">Contexto: '
                        f'<code>{_e(d.contexto_antes)}</code> … '
                        f'<code>{_e(d.contexto_depois)}</code></p>')
        citacoes = ""
        if getattr(d, "citacao_html", "") or getattr(d, "citacao_docx", ""):
            citacoes = (
                '<div class="citacoes">'
                '<div class="citacao"><span class="citacao-fonte">Como está no HTML</span>'
                f'<blockquote>{_e(d.citacao_html) or "—"}</blockquote></div>'
                '<div class="citacao">'
                '<span class="citacao-fonte">Como está no CONTEUDO.docx</span>'
                f'<blockquote>{_e(d.citacao_docx) or "—"}</blockquote></div>'
                '</div>'
            )
        blocos.append(
            f'<li class="{classe}"><span class="rotulo">{rotulo}</span>'
            f'em <span class="arquivo">{_e(d.origem)}</span>{marca}{diff}{contexto}'
            f'{citacoes}</li>'
        )

    corpo = f'<ul class="itens">{"".join(blocos)}</ul>' if blocos else (
        '<p class="vazio">O CONTEUDO.docx e a leitura do HTML têm as mesmas palavras, na mesma ordem.</p>'
    )

    dispensados = ""
    if r.trechos_dispensados:
        lista = "; ".join(_e(t) for t in r.trechos_dispensados[:4])
        dispensados = (f'<p class="contexto">Ignorado por ser texto de template: '
                       f'{lista}</p>')

    parcial = ""
    if r.blocos_sem_ocr:
        lista = " ".join(f'<span class="arquivo">{_e(i)}</span>' for i in r.blocos_sem_ocr)
        parcial = ('<div class="aviso" style="margin-top:16px">O texto dentro destas '
                   f'imagens não foi conferido. Confira no olho: {lista}</div>')

    if modo == "presenca":
        descricao = ("Conferência parcial: sem a leitura de imagens, comparei apenas o "
                     "texto escrito no código do HTML contra o CONTEUDO.docx, palavra a "
                     "palavra. O que está dentro dos banners não entrou na conta.")
    else:
        descricao = ("Comparação palavra a palavra entre a ordem de leitura do HTML "
                     "(texto vivo + texto dentro das imagens) e o CONTEUDO.docx.")

    return f"""
    <section>
      <h2>Texto <span class="contagem">· {r.similaridade}%</span></h2>
      <p class="resumo">{descricao}</p>
      {corpo}{dispensados}{parcial}
    </section>"""


def _secao_bloqueios(resultado) -> str:
    """Regras de publicação que a peça não cumpre. Abre o relatório."""
    bloqueios = list(getattr(resultado, "bloqueios", []))
    alertas = list(getattr(resultado, "alertas", []))
    if not bloqueios and not alertas:
        return ""

    partes = ""
    if bloqueios:
        itens = "".join(
            f'<li class="alta"><span class="rotulo">Impede a publicação</span>{_e(b)}</li>'
            for b in bloqueios
        )
        partes += f'<ul class="itens">{itens}</ul>'
    if alertas:
        partes += ('<p class="contexto" style="margin-top:12px">'
                   + " · ".join(_e(a) for a in alertas) + "</p>")

    return f"""
    <section>
      <h2>Regras de publicação</h2>
      <p class="resumo">Requisitos do banco para a peça subir.</p>
      {partes}
    </section>"""


def _secao_avisos(resultado) -> str:
    itens = list(resultado.avisos)
    for a in resultado.apontamentos_assunto:
        itens.append(f"Pré-header do docx não localizado no HTML: “{a.trecho_docx}”")
    if resultado.leitura_html and resultado.leitura_html.alts_vazios:
        nomes = ", ".join(resultado.leitura_html.alts_vazios[:8])
        itens.append(f"Imagens sem atributo alt no HTML: {nomes}")
    if not itens:
        return ""
    corpo = "".join(f'<div class="aviso">{_e(i)}</div>' for i in itens)
    return f'<section><h2>Observações</h2>{corpo}</section>'


def gerar(resultado, caminho_saida: str) -> str:
    status = resultado.status
    rt = resultado.resultado_texto
    ri = resultado.resultado_imagens

    if resultado.erros:
        conteudo = "".join(f'<div class="aviso">{_e(e)}</div>' for e in resultado.erros)
        corpo = f'<section><h2>Erros</h2>{conteudo}</section>'
        numeros = ""
    else:
        corpo = (_secao_bloqueios(resultado) + _secao_imagens(ri)
                 + _secao_texto(rt, getattr(resultado, "modo_texto", "sequencia"))
                 + _secao_avisos(resultado))
        numeros = f"""
        <div class="numeros">
          <div><b>{len(ri.arquivos) if ri else 0}</b><span>imagens</span></div>
          <div><b>{rt.similaridade if rt else 0}%</b><span>aderência</span></div>
          <div><b>{len(rt.divergencias) if rt else 0}</b><span>divergências</span></div>
          <div><b>{"sim" if resultado.ocr_ativo else "não"}</b><span>leitura de imagem</span></div>
        </div>"""

    agora = datetime.now().strftime("%d/%m/%Y às %H:%M")
    documento = f"""<!DOCTYPE html>
<html lang="pt-BR"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Conferência · {_e(resultado.quebra or os.path.basename(resultado.pasta))}</title>
<style>{CSS}</style></head><body><div class="folha">
  <header>
    <h1>Conferência de pacote</h1>
    <div class="quebra">{_e(resultado.quebra or os.path.basename(resultado.pasta))}</div>
    <div class="meta">{_e(resultado.pasta)} · {agora}</div>
  </header>
  <div class="veredito">
    <div>
      <div style="display:flex;align-items:center;gap:14px">
        <span class="selo {status}">{status.upper()}</span>
        <p>{FRASES_STATUS.get(status, "")}</p>
      </div>
      {numeros}
    </div>
  </div>
  {corpo}
  <footer>Validador de pacotes · Orquestração e Ativação de Campanhas</footer>
</div></body></html>"""

    os.makedirs(os.path.dirname(os.path.abspath(caminho_saida)), exist_ok=True)
    with open(caminho_saida, "w", encoding="utf-8") as f:
        f.write(documento)
    return caminho_saida
