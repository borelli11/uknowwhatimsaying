"""Validador de pacotes de campanha — Orquestração e Ativação."""
__version__ = "1.0.0"
