"""
Orquestração da conferência de um pacote.

Recebe a pasta que o analista de marketing enviou, descobre sozinho onde está o
HTML, os dois docx e as imagens, e roda as três verificações.
"""

import os
from dataclasses import dataclass, field

from . import (comparador, docx_parser, html_parser, imagens as mod_imagens,
               presenca, regras)
from .ocr import CacheOCR, ocr_disponivel

NOMES_PASTA_IMAGENS = ("imagens", "images", "img", "imgs", "assets", "peças", "pecas")


@dataclass
class ResultadoPacote:
    pasta: str
    quebra: str = ""
    caminho_html: str = ""
    caminho_conteudo: str = ""
    caminho_assunto: str = ""
    pasta_imagens: str = ""
    leitura_html: object = None
    leitura_conteudo: object = None
    leitura_assunto: object = None
    resultado_imagens: object = None
    resultado_texto: object = None
    apontamentos_assunto: list = field(default_factory=list)
    bloqueios: list[str] = field(default_factory=list)   # impedem a publicação
    alertas: list[str] = field(default_factory=list)     # o analista precisa saber
    avisos: list[str] = field(default_factory=list)
    erros: list[str] = field(default_factory=list)
    ocr_ativo: bool = False
    motivo_ocr: str = ""
    modo_texto: str = "sequencia"   # "sequencia" (com OCR) | "presenca" (sem OCR)
    nome_pasta: str = ""            # como o pacote chegou: briefing+CPI+ação

    @property
    def status(self) -> str:
        if self.erros:
            return "erro"
        if self.bloqueios:
            return "reprovado"
        problemas_imagem = self.resultado_imagens and not self.resultado_imagens.aprovado
        status_texto = self.resultado_texto.status if self.resultado_texto else "erro"
        if problemas_imagem or status_texto == "reprovado":
            return "reprovado"
        if status_texto in ("atencao", "parcial") or self.apontamentos_assunto:
            return "atencao"
        return "aprovado"


def _localizar_html(pasta: str) -> list[str]:
    encontrados = []
    for raiz, _, arquivos in os.walk(pasta):
        for arquivo in arquivos:
            if arquivo.lower().endswith((".html", ".htm")):
                encontrados.append(os.path.join(raiz, arquivo))
    # index.html primeiro; depois o arquivo mais pesado, que costuma ser a peça
    encontrados.sort(
        key=lambda c: (
            0 if os.path.basename(c).lower().startswith("index") else 1,
            -os.path.getsize(c),
        )
    )
    return encontrados


def _localizar_pasta_imagens(pasta: str, caminho_html: str) -> str:
    for raiz, diretorios, _ in os.walk(pasta):
        for diretorio in diretorios:
            if diretorio.lower() in NOMES_PASTA_IMAGENS:
                return os.path.join(raiz, diretorio)
    # sem subpasta dedicada, as imagens costumam estar ao lado do HTML
    return os.path.dirname(caminho_html) if caminho_html else pasta


def validar(pasta: str, quebra: str | None = None, usar_ocr: bool = True,
            idioma_ocr: str = "por") -> ResultadoPacote:
    resultado = ResultadoPacote(pasta=pasta)
    resultado.nome_pasta = os.path.basename(os.path.normpath(pasta))

    if not os.path.isdir(pasta):
        resultado.erros.append(f"pasta não encontrada: {pasta}")
        return resultado

    # --- localizar arquivos ---
    htmls = _localizar_html(pasta)
    if not htmls:
        resultado.erros.append("nenhum arquivo .html encontrado no pacote")
        return resultado
    resultado.caminho_html = htmls[0]
    if len(htmls) > 1:
        outros = ", ".join(os.path.basename(h) for h in htmls[1:])
        resultado.avisos.append(
            f"mais de um HTML no pacote; usando '{os.path.basename(htmls[0])}'. Outros: {outros}"
        )

    documentos = docx_parser.localizar_docx(pasta)
    if not documentos:
        resultado.erros.append("nenhum .docx encontrado no pacote")
        return resultado

    for caminho in documentos:
        leitura = docx_parser.ler_docx(caminho)
        if leitura.papel == "assunto" and not resultado.leitura_assunto:
            resultado.leitura_assunto = leitura
            resultado.caminho_assunto = caminho
        elif leitura.papel == "conteudo" and not resultado.leitura_conteudo:
            resultado.leitura_conteudo = leitura
            resultado.caminho_conteudo = caminho

    if not resultado.leitura_conteudo:
        resultado.erros.append(
            "não identifiquei o docx de CONTEÚDO. Renomeie o arquivo incluindo "
            "'CONTEUDO' no nome, ou informe o caminho manualmente."
        )
        return resultado
    if not resultado.leitura_assunto:
        resultado.avisos.append("docx de assunto/pré-header não encontrado no pacote")

    resultado.pasta_imagens = _localizar_pasta_imagens(pasta, resultado.caminho_html)

    # --- OCR ---
    cache = None
    if usar_ocr:
        disponivel, motivo = ocr_disponivel()
        resultado.ocr_ativo = disponivel
        resultado.motivo_ocr = motivo
        if disponivel:
            cache = CacheOCR(idioma=idioma_ocr)
            if cache.aviso_idioma:
                resultado.avisos.append(cache.aviso_idioma)
        else:
            resultado.avisos.append(
                f"OCR indisponível ({motivo}). O texto dentro das imagens não foi "
                "conferido; as demais verificações rodaram normalmente."
            )
    else:
        resultado.motivo_ocr = "desativado por parâmetro"

    # --- leitura do HTML e montagem da fita ---
    resultado.leitura_html = html_parser.ler_html(
        resultado.caminho_html, resultado.pasta_imagens, cache_ocr=cache
    )
    resultado.erros.extend(resultado.leitura_html.erros)
    if resultado.erros:
        return resultado

    # --- verificação 1: imagens ---
    resultado.resultado_imagens = mod_imagens.verificar(
        resultado.pasta_imagens,
        resultado.leitura_html.imagens_referenciadas,
        quebra=quebra,
    )
    resultado.quebra = resultado.resultado_imagens.quebra

    # --- verificação 2 e 3: texto ---
    # Com OCR, a fita está completa e vale comparar sequência. Sem OCR, o texto
    # das imagens falta na fita mas sobra no docx: comparar sequência aí inventa
    # divergência. Nesse caso só perguntamos se o texto vivo consta no docx.
    imagens_sem_leitura = any(
        b.tipo == "imagem" and not b.ocr_lido and not b.oculto
        for b in resultado.leitura_html.fita
    )
    resultado.modo_texto = "presenca" if imagens_sem_leitura else "sequencia"
    if imagens_sem_leitura:
        resultado.resultado_texto = presenca.comparar(
            resultado.leitura_html.fita, resultado.leitura_conteudo.paragrafos
        )
    else:
        resultado.resultado_texto = comparador.comparar(
            resultado.leitura_html.fita, resultado.leitura_conteudo.paragrafos
        )

    # --- verificação 4: pré-header ---
    if resultado.leitura_assunto:
        resultado.apontamentos_assunto = comparador.comparar_assunto(
            resultado.leitura_assunto, resultado.leitura_html
        )

    # --- verificação 5: regras de publicação ---
    _aplicar_regras(resultado)

    return resultado


def _aplicar_regras(resultado: ResultadoPacote) -> None:
    """
    Regras do banco, separadas do restante da conferência.

    O que impede a publicação vira bloqueio e reprova o pacote. O que só merece
    atenção vira alerta e não muda o veredito — assunto longo não é erro, é
    informação para o analista decidir.
    """
    # Redirect: sem nenhum no código, a peça não sobe.
    if resultado.leitura_html and resultado.leitura_html.redirects == 0:
        resultado.bloqueios.append(
            "Nenhum redirect encontrado no HTML. A publicação exige pelo menos um."
        )

    leitura = resultado.leitura_assunto
    if not leitura:
        return

    # Pré-header sem ponto final não passa na publicação.
    if leitura.pre_header:
        if not regras.pre_header_tem_ponto_final(leitura.pre_header):
            resultado.bloqueios.append(
                "O pré-header não termina em ponto final: "
                f"\u201c{leitura.pre_header}\u201d"
            )
        excedente = regras.excedeu(leitura.pre_header, regras.LIMITE_PRE_HEADER)
        if excedente:
            resultado.alertas.append(
                f"Pré-header com {len(leitura.pre_header.strip())} caracteres, "
                f"{excedente} acima dos {regras.LIMITE_PRE_HEADER} de referência."
            )

    if leitura.assunto:
        excedente = regras.excedeu(leitura.assunto, regras.LIMITE_ASSUNTO)
        if excedente:
            resultado.alertas.append(
                f"Assunto com {len(leitura.assunto.strip())} caracteres, "
                f"{excedente} acima dos {regras.LIMITE_ASSUNTO} de referência."
            )


def _tem_html_direto(pasta: str) -> bool:
    """HTML solto na própria pasta é o sinal de que ela é o pacote, não a caixa."""
    try:
        return any(
            item.lower().endswith((".html", ".htm"))
            and os.path.isfile(os.path.join(pasta, item))
            for item in os.listdir(pasta)
        )
    except OSError:
        return False


def _tem_html_em_algum_lugar(pasta: str) -> bool:
    for _, _, arquivos in os.walk(pasta):
        if any(a.lower().endswith((".html", ".htm")) for a in arquivos):
            return True
    return False


def localizar_pacotes(raiz: str) -> list[str]:
    """
    Descobre se o que foi arrastado é UM pacote ou uma caixa com vários.

    Não dá para exigir que a pessoa escolha o modo certo antes de arrastar: ela
    tem a pasta na mão, não a estrutura na cabeça. A regra é simples e casa com
    o jeito que os pacotes chegam do marketing:

      - HTML solto na pasta          -> a pasta é o pacote
      - subpastas que são pacotes    -> a pasta é uma caixa de pacotes
      - HTML só lá no fundo          -> trata como um pacote e deixa o
                                        localizador do HTML resolver
    """
    if not os.path.isdir(raiz):
        return []

    if _tem_html_direto(raiz):
        return [raiz]

    filhos = []
    for item in sorted(os.listdir(raiz)):
        caminho = os.path.join(raiz, item)
        if not os.path.isdir(caminho):
            continue
        if _tem_html_direto(caminho) or _tem_html_em_algum_lugar(caminho):
            filhos.append(caminho)

    if filhos:
        return filhos
    if _tem_html_em_algum_lugar(raiz):
        return [raiz]
    return []


def validar_lote(pasta_raiz: str, **kwargs) -> list[ResultadoPacote]:
    """Confere cada pacote encontrado dentro da pasta."""
    return [validar(caminho, **kwargs) for caminho in localizar_pacotes(pasta_raiz)]
