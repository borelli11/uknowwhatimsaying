"""
Regras de publicação de EMKT.

Ficam separadas do resto de propósito: são as regras do banco, mudam por
decisão de processo e não por mudança técnica. Quando o padrão do time mudar,
é aqui que se mexe — sem tocar em parser, comparador ou tela.

Três níveis:
  BLOQUEIO  — impede a publicação. Ex.: HTML sem nenhum redirect.
  ALERTA    — não impede, mas o analista precisa saber. Ex.: assunto longo.
  LIMITE    — número usado nas contas acima.
"""

import re

# ------------------------------------------------------------------ limites

# Assunto e pré-header: passar do limite não proíbe a publicação, mas corta na
# caixa de entrada de vários clientes. Vira alerta discreto, não apontamento.
LIMITE_ASSUNTO = 35
LIMITE_PRE_HEADER = 40

# Peso de imagem: acima disso a peça fica pesada para abrir no e-mail.
LIMITE_IMAGEM_KB = 1024  # 1 MB


# ----------------------------------------------------------------- redirect

# Pelo menos um redirect é obrigatório no HTML. Os padrões abaixo cobrem as
# formas mais comuns de escrever a chamada; acrescente aqui se o time usar
# outra. A busca é feita no código inteiro, não só nos links, porque o redirect
# às vezes aparece dentro de AMPScript ou de atributo de rastreio.
PADROES_REDIRECT = [
    r"redirect",
    r"\bredir\b",
    r"redirecionamento",
]

_RE_REDIRECT = [re.compile(p, re.IGNORECASE) for p in PADROES_REDIRECT]


def contar_redirects(codigo_html: str) -> int:
    """Quantas ocorrências de redirect existem no código."""
    if not codigo_html:
        return 0
    total = 0
    for padrao in _RE_REDIRECT:
        total += len(padrao.findall(codigo_html))
    return total


# ------------------------------------------------------- assunto e pré-header

# Um pré-header sem ponto final não passa na publicação. Aceita também os
# fechamentos que já contêm o ponto: reticências e ponto dentro de aspas.
RE_TERMINA_EM_PONTO = re.compile(r"[.…](?:[\"'\u201d\u2019)\]]*)\s*$")


def pre_header_tem_ponto_final(texto: str) -> bool:
    if not texto or not texto.strip():
        return False
    return bool(RE_TERMINA_EM_PONTO.search(texto.strip()))


def excedeu(texto: str, limite: int) -> int:
    """Quantos caracteres passaram do limite. Zero quando está dentro."""
    if not texto:
        return 0
    return max(0, len(texto.strip()) - limite)


# ------------------------------------------- hyperlink automático no disclaimer

# Cliente de e-mail transforma sozinho qualquer coisa com cara de endereço em
# link clicável. No disclaimer isso não pode acontecer, então a peça separa os
# caracteres com um invisível — normalmente &#xFEFF; (zero-width no-break
# space), às vezes &zwnj; ou &#8203; — bem no ponto onde o cliente procuraria o
# padrão de domínio. Sem esse código, o link é gerado e a peça não sobe.
INVISIVEIS_ANTI_LINK = ["\ufeff", "\u200b", "\u200c", "\u200d", "\u2060"]

RE_ENDERECO = re.compile(
    r"(?:https?://|www\.)[^\s<>\"']{4,}"                    # URL explícita
    r"|[a-z0-9][a-z0-9\-]{1,}\.(?:com|br|net|org|gov)\b[^\s<>\"']*"  # domínio
    r"|[a-z0-9][a-z0-9\-]{1,}\.[a-z]{2,}/[^\s<>\"']+"        # banco.bradesco/algo
    r"|[\w.\-]+@[\w\-]+\.[a-z]{2,}",                        # e-mail
    re.IGNORECASE,
)


def enderecos_sem_protecao(texto_bruto: str) -> list[str]:
    """
    Acha endereços dentro de um trecho que virariam link clicável.

    Recebe o texto BRUTO, com os invisíveis preservados: é justamente a
    presença deles que diz se a proteção foi aplicada. Depois da limpeza eles
    somem e não há mais como saber.
    """
    if not texto_bruto:
        return []

    # o invisível fica no meio do endereço; para achar o padrão é preciso
    # olhar o texto sem ele, e depois conferir o trecho original
    sem_invisiveis = texto_bruto
    for marca in INVISIVEIS_ANTI_LINK:
        sem_invisiveis = sem_invisiveis.replace(marca, "")

    desprotegidos = []
    for achado in RE_ENDERECO.finditer(sem_invisiveis):
        endereco = achado.group().rstrip(".,;:)")
        if len(endereco) < 6:
            continue
        # o endereço está protegido se o original traz algum invisível entre
        # os caracteres dele
        trecho_original = _trecho_original(texto_bruto, endereco)
        if not any(marca in trecho_original for marca in INVISIVEIS_ANTI_LINK):
            desprotegidos.append(endereco)
    return desprotegidos


def _trecho_original(texto_bruto: str, endereco: str) -> str:
    """Recorta no texto bruto a região que corresponde ao endereço encontrado."""
    letras = [c for c in endereco]
    posicao, inicio = 0, None
    for indice, caractere in enumerate(texto_bruto):
        if caractere in INVISIVEIS_ANTI_LINK:
            continue
        if posicao < len(letras) and caractere == letras[posicao]:
            if inicio is None:
                inicio = indice
            posicao += 1
            if posicao == len(letras):
                return texto_bruto[inicio:indice + 1]
        else:
            posicao, inicio = 0, None
            if caractere == letras[0]:
                inicio, posicao = indice, 1
    return ""


# ------------------------------------------------------------ datas vencidas

MESES = {
    "janeiro": 1, "fevereiro": 2, "marco": 3, "março": 3, "abril": 4,
    "maio": 5, "junho": 6, "julho": 7, "agosto": 8, "setembro": 9,
    "outubro": 10, "novembro": 11, "dezembro": 12,
}

RE_DATA_NUMERICA = re.compile(r"\b(\d{1,2})[/.\-](\d{1,2})[/.\-](\d{2,4})\b")
RE_DATA_POR_EXTENSO = re.compile(
    r"\b(\d{1,2})\s+de\s+([a-zç]+)\s+de\s+(\d{4})\b", re.IGNORECASE
)


def datas_vencidas(texto: str, hoje=None) -> list[str]:
    """
    Devolve as datas do texto que já passaram.

    Prazo de campanha aparece no disclaimer, no banner e no texto do código, e
    peça reaproveitada de mês anterior costuma trazer a data antiga junto. Vira
    aviso, não bloqueio: às vezes a data passada é proposital (início de
    vigência, data de contrato), e quem decide isso é o analista.
    """
    from datetime import date

    hoje = hoje or date.today()
    vencidas = []

    for dia, mes, ano in RE_DATA_NUMERICA.findall(texto or ""):
        try:
            ano_cheio = int(ano)
            if ano_cheio < 100:
                ano_cheio += 2000
            achada = date(ano_cheio, int(mes), int(dia))
        except ValueError:
            continue
        # datas muito antigas são ano de fundação, CNPJ, número solto
        if achada < hoje and (hoje - achada).days < 900:
            texto_data = f"{int(dia):02d}/{int(mes):02d}/{ano_cheio}"
            if texto_data not in vencidas:
                vencidas.append(texto_data)

    for dia, nome_mes, ano in RE_DATA_POR_EXTENSO.findall(texto or ""):
        numero = MESES.get(nome_mes.lower())
        if not numero:
            continue
        try:
            achada = date(int(ano), numero, int(dia))
        except ValueError:
            continue
        if achada < hoje and (hoje - achada).days < 900:
            texto_data = f"{dia} de {nome_mes} de {ano}"
            if texto_data not in vencidas:
                vencidas.append(texto_data)

    return vencidas
