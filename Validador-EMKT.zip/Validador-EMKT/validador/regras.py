"""
Regras de publicação de EMKT.

Ficam separadas do resto de propósito: são as regras do banco, mudam por
decisão de processo e não por mudança técnica. Quando o padrão do time mudar,
é aqui que se mexe — sem tocar em parser, comparador ou tela.

Três níveis:
  BLOQUEIO  — impede a publicação. Ex.: HTML sem nenhum redirect.
  ALERTA    — não impede, mas o analista precisa saber. Ex.: assunto longo.
  LIMITE    — número usado nas contas acima.
"""

import re

# ------------------------------------------------------------------ limites

# Assunto e pré-header: passar do limite não proíbe a publicação, mas corta na
# caixa de entrada de vários clientes. Vira alerta discreto, não apontamento.
LIMITE_ASSUNTO = 35
LIMITE_PRE_HEADER = 40

# Peso de imagem: acima disso a peça fica pesada para abrir no e-mail.
LIMITE_IMAGEM_KB = 1024  # 1 MB


# ----------------------------------------------------------------- redirect

# Pelo menos um redirect é obrigatório no HTML. Os padrões abaixo cobrem as
# formas mais comuns de escrever a chamada; acrescente aqui se o time usar
# outra. A busca é feita no código inteiro, não só nos links, porque o redirect
# às vezes aparece dentro de AMPScript ou de atributo de rastreio.
PADROES_REDIRECT = [
    r"redirect",
    r"\bredir\b",
    r"redirecionamento",
]

_RE_REDIRECT = [re.compile(p, re.IGNORECASE) for p in PADROES_REDIRECT]


def contar_redirects(codigo_html: str) -> int:
    """Quantas ocorrências de redirect existem no código."""
    if not codigo_html:
        return 0
    total = 0
    for padrao in _RE_REDIRECT:
        total += len(padrao.findall(codigo_html))
    return total


# ------------------------------------------------------- assunto e pré-header

# Um pré-header sem ponto final não passa na publicação. Aceita também os
# fechamentos que já contêm o ponto: reticências e ponto dentro de aspas.
RE_TERMINA_EM_PONTO = re.compile(r"[.…](?:[\"'\u201d\u2019)\]]*)\s*$")


def pre_header_tem_ponto_final(texto: str) -> bool:
    if not texto or not texto.strip():
        return False
    return bool(RE_TERMINA_EM_PONTO.search(texto.strip()))


def excedeu(texto: str, limite: int) -> int:
    """Quantos caracteres passaram do limite. Zero quando está dentro."""
    if not texto:
        return 0
    return max(0, len(texto.strip()) - limite)
