"""
Conferência do pacote de imagens.

Substitui o CTRL+F. Responde três perguntas:
  1. Os nomes seguem a taxonomia da quebra?
  2. A numeração é sequencial, sem furo (01, 02, 08, 03 reprova)?
  3. Toda imagem da pasta está no HTML, e todo src do HTML existe na pasta?

Repetição da mesma imagem dentro do HTML é permitida e não gera apontamento.
"""

import os
import re

from . import regras
from collections import Counter
from dataclasses import dataclass, field

EXTENSOES_VALIDAS = {".jpg", ".jpeg", ".png", ".gif"}

# Nomes que denunciam material de apoio: a arte do e-mail inteiro que a agência
# manda junto para conferência visual.
RE_APOIO = re.compile(
    r"preview|layout|mockup|arte|final|completo|full|montagem|aprova[cç][aã]o|"
    r"refer[eê]ncia|amostra",
    re.IGNORECASE,
)

# Uma peça inteira em imagem única é muito mais alta que larga. Banner de
# seção raramente passa disso.
PROPORCAO_DE_PECA_INTEIRA = 2.5

# quebra + separador opcional + número + extensão
RE_PADRAO = re.compile(
    r"^(?P<quebra>.+?)[_\-\s]?(?P<numero>\d{1,3})$"
)


@dataclass
class ImagemPasta:
    nome: str
    caminho: str
    quebra_detectada: str = ""
    numero: int | None = None
    extensao: str = ""
    tamanho_kb: float = 0.0
    largura: int = 0
    altura: int = 0
    apoio: bool = False


@dataclass
class ResultadoImagens:
    quebra: str = ""
    quebra_inferida: bool = False
    arquivos: list[ImagemPasta] = field(default_factory=list)
    fora_da_taxonomia: list[tuple[str, str]] = field(default_factory=list)
    numeros_faltando: list[int] = field(default_factory=list)
    numeros_duplicados: list[int] = field(default_factory=list)
    nao_comeca_em_um: bool = False
    sem_numeracao_zero_a_esquerda: list[str] = field(default_factory=list)
    extensao_invalida: list[str] = field(default_factory=list)
    acima_do_peso: list[tuple[str, float]] = field(default_factory=list)
    na_pasta_fora_do_html: list[str] = field(default_factory=list)
    no_html_fora_da_pasta: list[str] = field(default_factory=list)
    divergencia_de_caixa: list[tuple[str, str]] = field(default_factory=list)
    material_de_apoio: list[tuple[str, str]] = field(default_factory=list)
    repeticoes_no_html: dict = field(default_factory=dict)
    total_referencias_html: int = 0

    @property
    def aprovado(self) -> bool:
        return not (
            self.acima_do_peso
            or self.fora_da_taxonomia
            or self.numeros_faltando
            or self.numeros_duplicados
            or self.extensao_invalida
            or self.na_pasta_fora_do_html
            or self.no_html_fora_da_pasta
            or self.divergencia_de_caixa
            or self.nao_comeca_em_um
        )


def _inferir_quebra(nomes: list[str]) -> str:
    """
    Deduz a quebra pelo prefixo mais comum quando ela não é informada.
    Usar a moda em vez do prefixo comum a todos evita que um arquivo com nome
    errado — justamente o que queremos flagrar — contamine a referência.
    """
    candidatos = []
    for nome in nomes:
        base = os.path.splitext(nome)[0]
        m = RE_PADRAO.match(base)
        if m:
            candidatos.append(m.group("quebra").strip())
    if not candidatos:
        return ""
    return Counter(candidatos).most_common(1)[0][0]


def listar_pasta(pasta_imagens: str) -> list[ImagemPasta]:
    itens = []
    if not os.path.isdir(pasta_imagens):
        return itens
    for raiz, _, arquivos in os.walk(pasta_imagens):
        for arquivo in sorted(arquivos):
            if arquivo.startswith(("~$", ".")):
                continue
            extensao = os.path.splitext(arquivo)[1].lower()
            if extensao not in EXTENSOES_VALIDAS and extensao not in {".webp", ".bmp", ".svg"}:
                continue
            caminho = os.path.join(raiz, arquivo)
            itens.append(
                ImagemPasta(
                    nome=arquivo,
                    caminho=caminho,
                    extensao=extensao,
                    tamanho_kb=round(os.path.getsize(caminho) / 1024, 1),
                )
            )
    return itens


def _dimensoes(caminho: str) -> tuple[int, int]:
    try:
        from PIL import Image
        with Image.open(caminho) as imagem:
            return imagem.width, imagem.height
    except Exception:
        return 0, 0


def _e_material_de_apoio(imagem: ImagemPasta, referenciadas: set[str],
                         quebra: str) -> str:
    """
    Diz se o arquivo é a arte de conferência do e-mail inteiro, e por quê.

    Vem junto no pacote com frequência e não faz parte da peça publicada: não
    é chamada no código nem entra no Content Builder. Tratar como "imagem não
    utilizada" encheria o report de apontamento que ninguém precisa resolver.

    Só entra aqui o que NÃO é chamado no HTML — arquivo que o código usa é
    parte da peça, custe o nome que custar.
    """
    if imagem.nome.lower() in referenciadas:
        return ""

    if RE_APOIO.search(os.path.splitext(imagem.nome)[0]):
        return "nome indica arte de conferência"

    if not imagem.altura or not imagem.largura:
        imagem.largura, imagem.altura = _dimensoes(imagem.caminho)
    if imagem.largura and imagem.altura / imagem.largura >= PROPORCAO_DE_PECA_INTEIRA:
        return (f"proporção de peça inteira ({imagem.largura}x{imagem.altura})")

    # nome sem a quebra e sem numeração, e ninguém chama: não é peça de montagem
    if quebra and quebra.lower() not in imagem.nome.lower():
        base = os.path.splitext(imagem.nome)[0]
        if not RE_PADRAO.match(base):
            return "fora da taxonomia e não usado no código"
    return ""


def verificar(pasta_imagens: str, imagens_no_html: list[str],
              quebra: str | None = None) -> ResultadoImagens:
    resultado = ResultadoImagens()
    resultado.arquivos = listar_pasta(pasta_imagens)
    nomes_pasta = [i.nome for i in resultado.arquivos]

    if quebra:
        resultado.quebra = quebra.strip()
    else:
        resultado.quebra = _inferir_quebra(nomes_pasta)
        resultado.quebra_inferida = True

    referencia = resultado.quebra.lower()

    # --- material de apoio ---
    # Sai da conferência antes de tudo: não é peça publicada, então não entra
    # em taxonomia, sequência, peso nem cruzamento com o HTML.
    referenciadas = {n.lower() for n in imagens_no_html}
    for imagem in resultado.arquivos:
        motivo = _e_material_de_apoio(imagem, referenciadas, resultado.quebra)
        if motivo:
            imagem.apoio = True
            resultado.material_de_apoio.append((imagem.nome, motivo))
    resultado.arquivos = [i for i in resultado.arquivos if not i.apoio]
    nomes_pasta = [i.nome for i in resultado.arquivos]

    # --- peso dos arquivos ---
    # Vale para toda imagem da pasta, mesmo a que estiver fora da taxonomia:
    # peso é característica do arquivo, não depende de o nome estar certo.
    for imagem in resultado.arquivos:
        if imagem.tamanho_kb > regras.LIMITE_IMAGEM_KB:
            resultado.acima_do_peso.append((imagem.nome, imagem.tamanho_kb))

    # --- taxonomia e numeração ---
    numeros = []
    for imagem in resultado.arquivos:
        base = os.path.splitext(imagem.nome)[0]
        m = RE_PADRAO.match(base)
        if not m:
            resultado.fora_da_taxonomia.append(
                (imagem.nome, "não termina em número sequencial")
            )
            continue
        detectada = m.group("quebra").strip()
        imagem.quebra_detectada = detectada
        imagem.numero = int(m.group("numero"))

        if referencia and detectada.lower() != referencia:
            resultado.fora_da_taxonomia.append(
                (imagem.nome, f"prefixo '{detectada}' difere da quebra '{resultado.quebra}'")
            )
            continue

        if len(m.group("numero")) < 2:
            resultado.sem_numeracao_zero_a_esquerda.append(imagem.nome)

        if imagem.extensao not in EXTENSOES_VALIDAS:
            resultado.extensao_invalida.append(
                f"{imagem.nome} (extensão {imagem.extensao})"
            )

        numeros.append(imagem.numero)

    if numeros:
        contagem = Counter(numeros)
        resultado.numeros_duplicados = sorted(n for n, c in contagem.items() if c > 1)
        maior = max(numeros)
        presentes = set(numeros)
        resultado.numeros_faltando = [n for n in range(1, maior + 1) if n not in presentes]
        resultado.nao_comeca_em_um = 1 not in presentes

    # --- cruzamento pasta x HTML ---
    resultado.total_referencias_html = len(imagens_no_html)
    contagem_html = Counter(n.lower() for n in imagens_no_html)
    resultado.repeticoes_no_html = {
        nome: qtd for nome, qtd in contagem_html.items() if qtd > 1
    }

    mapa_pasta = {n.lower(): n for n in nomes_pasta}
    mapa_html = {}
    for nome in imagens_no_html:
        mapa_html.setdefault(nome.lower(), nome)

    for chave, nome_original in mapa_pasta.items():
        if chave not in mapa_html:
            resultado.na_pasta_fora_do_html.append(nome_original)

    for chave, nome_original in mapa_html.items():
        if chave not in mapa_pasta:
            resultado.no_html_fora_da_pasta.append(nome_original)
        elif mapa_pasta[chave] != nome_original:
            resultado.divergencia_de_caixa.append((mapa_pasta[chave], nome_original))

    return resultado
