#!/usr/bin/env python3
"""
Uso:
    python cli.py "C:\\pacotes\\CAMPANHA_X"
    python cli.py "C:\\pacotes\\CAMPANHA_X" --quebra emkt_cartoes_pf_0925
    python cli.py "C:\\pacotes" --lote
    python cli.py "C:\\pacotes\\CAMPANHA_X" --sem-ocr
"""

import argparse
import os
import sys
import webbrowser

from validador import pacote, relatorio


def resumo_terminal(r):
    marcas = {"aprovado": "[OK]", "atencao": "[!]", "reprovado": "[X]", "erro": "[ERRO]"}
    nome = r.quebra or os.path.basename(r.pasta)
    print(f"{marcas.get(r.status, '[?]'):7} {nome}")
    for e in r.erros:
        print(f"        erro: {e}")
    if r.resultado_imagens and not r.resultado_imagens.aprovado:
        ri = r.resultado_imagens
        problemas = (len(ri.fora_da_taxonomia) + len(ri.numeros_faltando)
                     + len(ri.na_pasta_fora_do_html) + len(ri.no_html_fora_da_pasta)
                     + len(ri.divergencia_de_caixa))
        print(f"        imagens: {problemas} apontamento(s)")
    if r.resultado_texto:
        rt = r.resultado_texto
        print(f"        texto: {rt.similaridade}% de aderência, "
              f"{len(rt.divergencias)} divergência(s)")


def main():
    p = argparse.ArgumentParser(description="Conferência automática de pacotes de campanha.")
    p.add_argument("pasta", help="pasta do pacote (ou pasta com vários pacotes, com --lote)")
    p.add_argument("--quebra", help="nome da quebra; se omitido, é deduzido dos arquivos")
    p.add_argument("--lote", action="store_true", help="conferir cada subpasta como um pacote")
    p.add_argument("--sem-ocr", action="store_true", help="não ler o texto dentro das imagens")
    p.add_argument("--saida", default="relatorios", help="pasta dos relatórios")
    p.add_argument("--abrir", action="store_true", help="abrir o relatório no navegador ao final")
    args = p.parse_args()

    opcoes = {"usar_ocr": not args.sem_ocr}
    if args.lote:
        resultados = pacote.validar_lote(args.pasta, **opcoes)
    else:
        resultados = [pacote.validar(args.pasta, quebra=args.quebra, **opcoes)]

    if not resultados:
        print("Nenhum pacote encontrado.")
        return 1

    print()
    caminhos = []
    for r in resultados:
        resumo_terminal(r)
        nome = (r.quebra or os.path.basename(r.pasta.rstrip("/\\")) or "pacote")
        nome = "".join(c if c.isalnum() or c in "-_" else "_" for c in nome)
        destino = os.path.join(args.saida, f"conferencia_{nome}.html")
        caminhos.append(relatorio.gerar(r, destino))

    print(f"\nRelatório(s) em: {os.path.abspath(args.saida)}")
    if args.abrir and caminhos:
        webbrowser.open(f"file://{os.path.abspath(caminhos[0])}")

    reprovados = sum(1 for r in resultados if r.status in ("reprovado", "erro"))
    return 1 if reprovados else 0


if __name__ == "__main__":
    sys.exit(main())
