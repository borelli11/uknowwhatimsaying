#!/usr/bin/env python3
"""
Suíte de regressão do validador.

Existe para responder a uma pergunta que ajuste pontual não responde: o
sistema está melhorando ou só trocando um erro por outro?

Cada caso aqui nasceu de uma falha real. Rodar isso depois de qualquer
mudança mostra, em número, se o que funcionava continua funcionando. Quando
aparecer um caso novo no dia a dia, acrescente aqui — é assim que o conjunto
para de crescer: os problemas viram teste em vez de virarem pedido.

Uso:
    python verificar_qualidade.py
"""

import os
import sys
import tempfile

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from PIL import Image, ImageDraw, ImageFont  # noqa: E402

from validador import docx_parser, excecoes, pacote, regras  # noqa: E402
from validador.normalizacao import tokenizar, tokenizar_pares  # noqa: E402
from validador.ocr import _e_ruido_de_icone, ler_imagem, ocr_disponivel  # noqa: E402

PASTA = os.path.dirname(os.path.abspath(__file__))
EXEMPLOS = os.path.join(PASTA, "_exemplo-teste")

resultados = []


def checar(grupo: str, nome: str, obtido, esperado) -> None:
    passou = obtido == esperado
    resultados.append((grupo, nome, passou, obtido, esperado))


def fonte(tamanho, negrito=True):
    caminho = "/usr/share/fonts/truetype/dejavu/DejaVuSans%s.ttf" % (
        "-Bold" if negrito else "")
    if os.path.exists(caminho):
        return ImageFont.truetype(caminho, tamanho)
    return ImageFont.load_default()


# ==========================================================================
# 1. Leitura de texto: normalização e tokenização
# ==========================================================================

def testar_texto():
    g = "texto"
    checar(g, "& é palavra, não pontuação",
           "&" in tokenizar("Credito & Financiamento"), True)
    checar(g, "colchete de botão não vira pontuação",
           [p.sensivel for p in tokenizar_pares("[Simular credito]")],
           ["simular", "credito"])
    checar(g, "sobrescrito vira dígito na comparação",
           tokenizar("CDB\u00b3"), ["cdb3"])
    checar(g, "sobrescrito preservado na exibição",
           [p.texto for p in tokenizar_pares("CDB\u00b3")], ["CDB\u00b3"])
    checar(g, "acento distingue na forma sensível",
           tokenizar_pares("Ol\u00e1")[0].sensivel != tokenizar_pares("Ola")[0].sensivel,
           True)


# ==========================================================================
# 2. Classificação de trechos
# ==========================================================================

def testar_classificacao():
    g = "classificação"
    dispensaveis = [
        "Se n\u00e3o conseguir abrir esse e-mail, clique aqui",
        "Se nao conseguiu visualizar esta mensagem, clique aqui para ver no navegador.",
        "Caso n\u00e3o visualize corretamente, acesse a vers\u00e3o online desta mensagem",
    ]
    for texto in dispensaveis:
        checar(g, f"fallback: {texto[:34]}", excecoes.classificar(texto), "dispensavel")

    checar(g, "redes sociais é tolerado",
           excecoes.classificar("Acompanhe o Bradesco nas Redes Sociais!"), "tolerado")
    checar(g, "ACOMPANHE: é tolerado", excecoes.classificar("ACOMPANHE:"), "tolerado")
    checar(g, "rodapé automático é disclaimer",
           excecoes.classificar("Essa mensagem foi gerada automaticamente e n\u00e3o pode ser respondida"),
           "obrigatorio:disclaimer")
    checar(g, "Central de Relacionamento é atendimento",
           excecoes.classificar("contate a Central de Relacionamento Cliente Pessoa Jur\u00eddica"),
           "obrigatorio:atendimento")
    checar(g, "texto comum não é classificado",
           excecoes.classificar("Simular agora"), "")


# ==========================================================================
# 3. Assunto e pré-header: formatos e grafias
# ==========================================================================

def testar_assunto():
    from docx import Document
    from docx.oxml.ns import qn

    g = "assunto"
    ASSUNTO = "Seu consignado esta liberado"
    PRE = "Simule agora e veja seu limite."

    def conferir(nome, montar):
        caminho = os.path.join(tempfile.gettempdir(), f"qa_{nome}.docx")
        documento = Document()
        montar(documento)
        documento.save(caminho)
        lido = docx_parser.ler_docx(caminho, papel="assunto")
        checar(g, nome, (lido.assunto, lido.pre_header), (ASSUNTO, PRE))

    def com_quebra(rotulo):
        def monta(d):
            p = d.add_paragraph()
            r = p.add_run("Assunto: "); r.bold = True
            p.add_run(ASSUNTO)
            q = p.add_run(); q._r.append(q._r.makeelement(qn("w:br"), {}))
            r2 = p.add_run(f"{rotulo}: "); r2.bold = True
            p.add_run(PRE)
        return monta

    for rotulo in ("Pr\u00e9-header", "Preheader", "Pr\u00e9-Heder", "Prehead",
                   "PRE HEADER", "Pr\u00e9-hedear"):
        conferir(f"Shift+Enter + '{rotulo}'", com_quebra(rotulo))

    def rotulo_sozinho(d):
        d.add_paragraph().add_run("ASSUNTO").bold = True
        d.add_paragraph(ASSUNTO)
        d.add_paragraph().add_run("PRE-HEADER").bold = True
        d.add_paragraph(PRE)
    conferir("rótulo em linha própria", rotulo_sozinho)

    def em_tabela(d):
        t = d.add_table(rows=2, cols=2)
        t.cell(0, 0).text = "Assunto"; t.cell(0, 1).text = ASSUNTO
        t.cell(1, 0).text = "Prehedear"; t.cell(1, 1).text = PRE
    conferir("dentro de tabela", em_tabela)

    def sem_rotulo(d):
        d.add_paragraph(ASSUNTO)
        d.add_paragraph(PRE)
    conferir("sem rótulo nenhum", sem_rotulo)

    def com_hifen(d):
        d.add_paragraph(f"Assunto - {ASSUNTO}")
        d.add_paragraph(f"Pr\u00e9-header - {PRE}")
    conferir("separador hífen", com_hifen)


# ==========================================================================
# 3b. Página salva de webmail
# ==========================================================================

def testar_webmail():
    from validador.html_parser import (e_ruido_de_cliente, isolar_corpo_da_mensagem,
                                       parece_pagina_de_email)
    from bs4 import BeautifulSoup

    g = "webmail"
    pagina = ('<html><body><div class="nH"><div class="a3s aiL">'
              '<p>Oferta especial para voce</p></div>'
              '<div class="gmail_quote">citada</div></body></html>')
    checar(g, "página do Gmail é reconhecida", parece_pagina_de_email(pagina), True)
    checar(g, "peça comum não é confundida",
           parece_pagina_de_email('<html><body><table><tr><td>Oferta</td></tr></table></body></html>'),
           False)

    corpo = isolar_corpo_da_mensagem(BeautifulSoup(pagina, "html.parser"))
    checar(g, "corpo da mensagem é isolado",
           "Oferta especial" in (corpo.get_text() if corpo else ""), True)

    checar(g, "botão do Gmail sai sempre",
           e_ruido_de_cliente("Fazer o download"), True)
    checar(g, "cabeçalho de encaminhamento sai",
           e_ruido_de_cliente("Enviado do meu iPhone"), True)
    checar(g, "CTA da peça não é confundido com botão",
           e_ruido_de_cliente("Baixe o app Bradesco", True), False)
    checar(g, "'Baixar' só sai em página de webmail",
           (e_ruido_de_cliente("Baixar"), e_ruido_de_cliente("Baixar", True)),
           (False, True))


# ==========================================================================
# 3c. Ordem de leitura dentro da imagem
# ==========================================================================

def testar_ordenacao():
    from validador.ordenacao import alinhar_por_referencia

    g = "ordem na imagem"
    # o motor lê por faixa horizontal e junta cartões lado a lado
    lido = ("no ingresso\n50% na poltrona D-BOX\n"
            "de desconto no combo Bradesco P ou M\n"
            "03/09: 24/09:\nMinha Melhor Amiga A Ilha Esquecida")
    docx = ["50% de desconto", "no ingresso", "na poltrona D-BOX",
            "no combo Bradesco P ou M",
            "03/09:", "Minha Melhor Amiga", "24/09:", "A Ilha Esquecida"]

    resultado = alinhar_por_referencia(lido, docx)
    checar(g, "reordena quando tudo existe no docx", resultado.reordenou, True)
    def onde(trecho):
        for i, linha in enumerate(resultado.linhas):
            if trecho.lower() in linha.lower():
                return i
        return -1

    checar(g, "cartão fica junto do seu título",
           onde("Minha Melhor Amiga") == onde("03") + 1, True)
    checar(g, "cada data fica com seu filme",
           onde("A Ilha Esquecida") == onde("24") + 1, True)
    checar(g, "pontuação preservada na reordenação",
           any("03/09" in l for l in resultado.linhas), True)

    # com divergência real, nada é reordenado
    docx_errado = [d.replace("Melhor", "Grande") for d in docx]
    checar(g, "não reordena quando há divergência",
           alinhar_por_referencia(lido, docx_errado).reordenou, False)

    checar(g, "sem docx não reordena",
           alinhar_por_referencia(lido, []).reordenou, False)


# ==========================================================================
# 4. Regras de publicação
# ==========================================================================

def testar_regras():
    from datetime import date

    g = "regras"
    protegido = ("Consulte em banco\ufeff.\ufeffbradesco\ufeff/\ufeffviagemdossonhos.")
    # hyperlink no CONTEUDO.docx
    from docx import Document
    import docx as _docx
    from docx.oxml.shared import OxmlElement, qn

    caminho = os.path.join(tempfile.gettempdir(), "qa_link.docx")
    documento = Document()
    paragrafo = documento.add_paragraph("Confira em ")
    rid = documento.part.relate_to(
        "https://banco.bradesco/x",
        _docx.opc.constants.RELATIONSHIP_TYPE.HYPERLINK, is_external=True)
    link = OxmlElement("w:hyperlink"); link.set(qn("r:id"), rid)
    run = OxmlElement("w:r"); texto = OxmlElement("w:t")
    texto.text = "banco.bradesco/x"; run.append(texto); link.append(run)
    paragrafo._p.append(link)
    documento.save(caminho)

    lido = docx_parser.ler_docx(caminho, papel="conteudo")
    checar(g, "hyperlink no docx é detectado", len(lido.links), 1)
    # o texto do link não pode sumir da comparação
    checar(g, "texto do link entra na leitura",
           "banco.bradesco/x" in " ".join(lido.paragrafos), True)

    checar(g, "endereço protegido não acusa",
           regras.enderecos_sem_protecao(protegido), [])
    checar(g, "endereço solto acusa",
           regras.enderecos_sem_protecao("Consulte em banco.bradesco/viagem."),
           ["banco.bradesco/viagem"])
    checar(g, "link com texto de frase não é endereço",
           regras.enderecos_sem_protecao("Saiba mais"), [])
    checar(g, "endereço dentro do link acusa",
           regras.enderecos_sem_protecao("banco.bradesco/cinemark"),
           ["banco.bradesco/cinemark"])
    checar(g, "pré-header com ponto passa",
           regras.pre_header_tem_ponto_final("Simule agora."), True)
    checar(g, "pré-header sem ponto reprova",
           regras.pre_header_tem_ponto_final("Simule agora"), False)
    checar(g, "reticências contam como ponto",
           regras.pre_header_tem_ponto_final("Simule agora\u2026"), True)
    checar(g, "redirect é encontrado",
           regras.contar_redirects('<a href="https://x/redirect?a=1">ir</a>') > 0, True)
    checar(g, "sem redirect",
           regras.contar_redirects('<a href="https://x/?a=1">ir</a>'), 0)

    hoje = date(2026, 9, 12)
    checar(g, "data passada vira alerta",
           regras.datas_vencidas("Valido ate 31/08/2026.", hoje), ["31/08/2026"])
    checar(g, "data futura não acusa",
           regras.datas_vencidas("Valido ate 31/12/2026.", hoje), [])
    checar(g, "ano de fundação é ignorado",
           regras.datas_vencidas("Desde 02/01/1943", hoje), [])


# ==========================================================================
# 5. Leitura de imagem
# ==========================================================================

def testar_ocr():
    g = "OCR"
    disponivel, _ = ocr_disponivel()
    if not disponivel:
        resultados.append((g, "motor indisponível — seção pulada", None, "", ""))
        return

    # ruído de ícone
    checar(g, "pictograma descartado", _e_ruido_de_icone("\u53e3", 60), True)
    checar(g, "borda de ícone descartada", _e_ruido_de_icone("0 0000 000", 75), True)
    checar(g, "dígito repetido descartado", _e_ruido_de_icone("000", 90), True)
    checar(g, "pontilhado descartado", _e_ruido_de_icone("....", 95), True)
    checar(g, "sigla com confiança alta preservada", _e_ruido_de_icone("PJ", 95), False)

    # O valor da oferta costuma vir sem letra nenhuma. Filtrar por "tem letra"
    # apagava justamente o dado mais importante da imagem.
    for valor in ("50%", "20%", "10/09:", "03/09:", "R$ 50.000,00", "36x",
                  "1,29", "3003 1000", "0800 570", "22h"):
        checar(g, f"valor preservado com confiança baixa: {valor}",
               _e_ruido_de_icone(valor, 62), False)

    # texto claro sobre fundo escuro com foto: o caso que fez o motor do
    # Windows devolver "Estreias deseeerpbro"
    escura = Image.new("RGB", (700, 300), (24, 10, 14))
    d = ImageDraw.Draw(escura)
    d.text((60, 90), "CINEMARK", fill=(255, 255, 255), font=fonte(52))
    d.text((60, 170), "Estreias de setembro", fill=(240, 240, 240), font=fonte(30))
    caminho_escura = os.path.join(tempfile.mkdtemp(prefix="qa_esc_"), "escura.jpg")
    escura.save(caminho_escura, quality=82)
    lido_escuro = ler_imagem(caminho_escura).texto.lower()
    checar(g, "texto claro sobre fundo escuro",
           "estreias de setembro" in lido_escuro, True)

    # a confiança chega como número numa versão do motor e como texto noutra
    from validador.ocr import _como_numero
    checar(g, "confiança em texto vira número", _como_numero("0.98"), 0.98)
    checar(g, "confiança com vírgula", _como_numero("0,98"), 0.98)
    checar(g, "confiança inválida não quebra", _como_numero("abc"), 0.0)
    checar(g, "ruído filtrado com confiança em texto",
           _e_ruido_de_icone("\u53e3", "0.6"), True)
    checar(g, "texto mantido com confiança em texto",
           _e_ruido_de_icone("CINEMARK", "99"), False)

    # pedir um motor ausente não pode desligar a leitura
    import validador.ocr as motor_ocr
    escolhido_antes = motor_ocr.motor_ativo().nome
    motor_ocr.forcar_motor("nao_existe")
    checar(g, "motor inexistente cai para um disponível",
           motor_ocr.motor_ativo() is not None, True)
    checar(g, "e explica o motivo", bool(motor_ocr.aviso_de_escolha()), True)
    motor_ocr.forcar_motor("")
    checar(g, "volta ao padrão", motor_ocr.motor_ativo().nome, escolhido_antes)

    pasta = tempfile.mkdtemp(prefix="qa_ocr_")

    # peça alta, como as fatias reais
    alvos = ["Programa de Fidelidade Bradesco:", "Elo Flex:", "Cinemark:",
             "Personalize seus beneficios e tenha o cartao",
             "50% OFF no Combo Bradesco", "Assistencia Mobilidade"]
    img = Image.new("RGB", (900, 2600), (250, 250, 252))
    d = ImageDraw.Draw(img)
    for i, texto in enumerate(alvos):
        d.text((50, 60 + i * 400), texto, fill=(30, 45, 110), font=fonte(24))
    caminho = os.path.join(pasta, "alta.jpg")
    img.save(caminho, quality=78)

    lido = ler_imagem(caminho).texto.lower()
    achados = sum(1 for a in alvos if a.lower() in lido)
    checar(g, "imagem alta: frases lidas inteiras", achados, len(alvos))

    # chamada de nota colada na palavra
    img2 = Image.new("RGB", (900, 200), (255, 255, 255))
    d2 = ImageDraw.Draw(img2)
    linha = "Credito com garantia de CDB"
    d2.text((60, 70), linha, fill=(20, 20, 20), font=fonte(38))
    largura = d2.textlength(linha, font=fonte(38))
    d2.text((60 + largura + 3, 62), "1", fill=(20, 20, 20), font=fonte(19))
    caminho2 = os.path.join(pasta, "nota.png")
    img2.save(caminho2)
    checar(g, "chamada de nota cola na palavra",
           "cdb1" in ler_imagem(caminho2).texto.lower().replace(" ", ""), True)

    # GIF com animação progressiva
    quadros = []
    for texto in ("COMPROMISSO", "COMPROMISSO com voce",
                  "COMPROMISSO com voce e TRANSPARENCIA"):
        q = Image.new("RGB", (900, 200), (255, 255, 255))
        ImageDraw.Draw(q).text((40, 80), texto, fill=(20, 20, 20), font=fonte(30))
        quadros.append(q)
    caminho3 = os.path.join(pasta, "animado.gif")
    quadros[0].save(caminho3, save_all=True, append_images=quadros[1:],
                    duration=700, loop=0)
    linhas = [l for l in ler_imagem(caminho3).texto.splitlines() if l.strip()]
    checar(g, "GIF: fica só a frase completa", len(linhas), 1)


# ==========================================================================
# 5b. Cache e velocidade
# ==========================================================================

def testar_cache():
    import shutil
    import time

    from validador.ocr import CacheOCR, PASTA_CACHE, _pequena_demais

    g = "velocidade"
    pasta = tempfile.mkdtemp(prefix="qa_cache_")

    icone = Image.new("RGB", (20, 20), (200, 30, 60))
    caminho_icone = os.path.join(pasta, "icone.png")
    icone.save(caminho_icone)
    pequena, _ = _pequena_demais(caminho_icone)
    checar(g, "ícone de 20x20 não passa pelo OCR", pequena, True)

    banner = Image.new("RGB", (700, 200), (255, 255, 255))
    ImageDraw.Draw(banner).text((40, 80), "Oferta especial de setembro",
                                fill=(20, 20, 20), font=fonte(30))
    caminho_banner = os.path.join(pasta, "banner.png")
    banner.save(caminho_banner)
    pequena, _ = _pequena_demais(caminho_banner)
    checar(g, "banner normal passa pelo OCR", pequena, False)

    if not ocr_disponivel()[0]:
        return

    shutil.rmtree(PASTA_CACHE, ignore_errors=True)
    primeiro = CacheOCR()
    inicio = time.time()
    texto_frio = primeiro.ler(caminho_banner).texto
    tempo_frio = time.time() - inicio

    segundo = CacheOCR()
    inicio = time.time()
    texto_quente = segundo.ler(caminho_banner).texto
    tempo_quente = time.time() - inicio

    checar(g, "cache devolve o mesmo texto", texto_quente, texto_frio)
    checar(g, "cache reaproveita entre execuções", segundo.reaproveitadas, 1)
    checar(g, "cache é mais rápido que reler", tempo_quente < tempo_frio, True)


# ==========================================================================
# 6. Pacotes de ponta a ponta
# ==========================================================================

def testar_pacotes():
    g = "pacote"
    for nome, esperado in (("PACOTE_APROVADO", "aprovado"),
                           ("PACOTE_ERROS", "reprovado")):
        caminho = os.path.join(EXEMPLOS, nome)
        if not os.path.isdir(caminho):
            resultados.append((g, f"{nome} ausente", None, "", ""))
            continue
        resultado = pacote.validar(caminho)
        checar(g, f"{nome} → {esperado}", resultado.status, esperado)
        if nome == "PACOTE_APROVADO":
            checar(g, "aprovado sem divergência",
                   len(resultado.resultado_texto.divergencias), 0)

    # estruturas de pasta
    checar(g, "pacote simples é reconhecido",
           len(pacote.localizar_pacotes(os.path.join(EXEMPLOS, "PACOTE_APROVADO"))), 1)
    checar(g, "caixa com vários pacotes", len(pacote.localizar_pacotes(EXEMPLOS)), 2)


# ==========================================================================
# Relatório
# ==========================================================================

def main():
    print("\n" + "=" * 68)
    print("  Verificação de qualidade do validador")
    print("=" * 68)

    for secao in (testar_texto, testar_classificacao, testar_assunto,
                  testar_webmail, testar_ordenacao, testar_regras, testar_ocr,
                  testar_cache, testar_pacotes):
        try:
            secao()
        except Exception as e:  # noqa: BLE001
            resultados.append((secao.__name__, f"ERRO NA SEÇÃO: {e}", False, "", ""))

    grupo_atual = None
    falhas = 0
    for grupo, nome, passou, obtido, esperado in resultados:
        if grupo != grupo_atual:
            print(f"\n{grupo.upper()}")
            grupo_atual = grupo
        if passou is None:
            print(f"   --   {nome}")
            continue
        print(f"   {'ok ' if passou else 'FALHOU'}  {nome}")
        if not passou:
            falhas += 1
            print(f"          obtido:   {obtido!r}")
            print(f"          esperado: {esperado!r}")

    total = sum(1 for r in resultados if r[2] is not None)
    print("\n" + "-" * 68)
    print(f"  {total - falhas} de {total} verificações passaram", end="")
    print("" if falhas else "  — tudo certo")
    print("-" * 68 + "\n")
    return 1 if falhas else 0


if __name__ == "__main__":
    sys.exit(main())
