' Inicia o validador sem deixar a janela preta na tela.
' O programa continua rodando em segundo plano.
' Para encerrar: Ctrl+Shift+Esc, aba Detalhes, finalizar "pythonw.exe".
Set shell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
shell.CurrentDirectory = fso.GetParentFolderName(WScript.ScriptFullName)
shell.Run "pythonw app.py", 0, False
